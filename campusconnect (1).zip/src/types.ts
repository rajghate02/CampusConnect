export type UserRole = 'student' | 'mentor' | 'club_admin' | 'university_admin' | 'system_admin';

export interface University {
  id: string;
  name: string;
  shortCode: string; // e.g. 'MUJ'
  location: string;
  region?: 'India' | 'USA' | 'Europe';
  institutionType?: 'University' | 'College';
  logo: string;
  coverImage: string;
  website: string;
  studentCount: number;
  resourceCount: number;
  projectCount: number;
  campuses: string[];
  departments: string[];
  isVerified: boolean;
}

export interface StudentProfile {
  id: string;
  name: string;
  email: string;
  registrationNumber?: string;
  password?: string;
  avatar: string;
  role: UserRole;
  universityId: string;
  universityName: string;
  universityShort?: string;
  campus: string;
  department: string;
  degree: string;
  branch: string;
  year: number;
  semester: number;
  bio: string;
  skills: string[];
  programmingLanguages: string[];
  interests: string[];
  courses: string[];
  githubUrl?: string;
  linkedinUrl?: string;
  portfolioUrl?: string;
  reputationPoints: number;
  badges: string[];
  profileCompletionPercentage: number;
  isAvailableForMentorship: boolean;
  mentorshipTopics?: string[];
  projectsCount: number;
  resourcesUploadedCount: number;
  connectionsCount: number;
}

export type ResourceType = 'PYQ' | 'Notes' | 'Lab Manual' | 'Assignment' | 'Question Bank' | 'Presentation' | 'Study Guide';

export interface AcademicResource {
  id: string;
  title: string;
  description: string;
  resourceType: ResourceType;
  universityId: string;
  universityName: string;
  department: string;
  courseCode: string;
  courseName: string; // e.g. "Data Structures & Algorithms"
  subject?: string;   // e.g. "Computer Science"
  topic?: string;     // e.g. "Trees & Graph Traversals"
  semester: number;   // e.g. Semester 1-8
  academicYear: string;
  fileUrl: string;
  fileSize: string;
  fileFormat: string;
  uploaderId: string;
  uploaderName: string;
  uploaderAvatar: string;
  uploadDate: string;
  downloadsCount: number;
  rating: number;
  ratingsCount: number;
  tags: string[];
  verifiedByFaculty: boolean;
}

export interface ProjectShowcase {
  id: string;
  title: string;
  description: string;
  problemStatement: string;
  solution: string;
  category: 'AI/ML' | 'Web' | 'Mobile' | 'Robotics' | 'IoT' | 'Cybersecurity' | 'Cloud' | 'Research' | 'Mechanical' | 'Other';
  techStack: string[];
  images: string[];
  demoUrl?: string;
  githubUrl?: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorUniversity: string;
  authorDepartment: string;
  teamMembers: { name: string; role: string; avatar: string }[];
  upvotesCount: number;
  commentsCount: number;
  createdAt: string;
  hasUpvoted?: boolean;
}

export interface TeamFinderPost {
  id: string;
  title: string;
  projectDescription: string;
  hackathonName?: string;
  requiredSkills: string[];
  currentTeamSize: number;
  targetTeamSize: number;
  deadline: string;
  universityName: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorDepartment: string;
  createdAt: string;
  applicantsCount: number;
  status: 'Open' | 'Closed' | 'In Selection';
  appliedUserIds?: string[];
}

export interface PostFeedItem {
  id: string;
  type: 'question' | 'project_announcement' | 'study_resource' | 'research_idea' | 'hackathon' | 'achievement' | 'discussion';
  title: string;
  content: string;
  tags: string[];
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorUniversity: string;
  authorDepartment: string;
  authorRole: string;
  createdAt: string;
  upvotesCount: number;
  commentsCount: number;
  hasUpvoted?: boolean;
  hasSaved?: boolean;
  attachedResourceUrl?: string;
  comments?: { id: string; authorName: string; authorAvatar: string; text: string; createdAt: string }[];
}

export interface ClubItem {
  id: string;
  name: string;
  category: 'Coding' | 'Robotics' | 'Entrepreneurship' | 'Cultural' | 'Sports' | 'Research' | 'Photography' | 'Debate' | 'Other';
  universityId: string;
  universityName: string;
  description: string;
  logo: string;
  memberCount: number;
  leadName: string;
  leadAvatar: string;
  upcomingEventsCount: number;
  isJoined?: boolean;
}

export interface EventItem {
  id: string;
  title: string;
  type: 'Hackathon' | 'Workshop' | 'Seminar' | 'Competition' | 'Conference' | 'Club Event';
  organizer: string;
  universityName: string;
  date: string;
  time: string;
  location: string;
  isOnline: boolean;
  description: string;
  eligibility: string;
  prizePool?: string;
  registrationDeadline: string;
  registrationLink?: string;
  bannerImage: string;
  attendeesCount: number;
  isRegistered?: boolean;
}

export interface ForumQuestion {
  id: string;
  title: string;
  content: string;
  courseName?: string;
  tags: string[];
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorUniversity: string;
  createdAt: string;
  upvotesCount: number;
  answersCount: number;
  hasAcceptedAnswer: boolean;
  answers: {
    id: string;
    authorName: string;
    authorAvatar: string;
    authorUniversity: string;
    content: string;
    upvotesCount: number;
    isAccepted: boolean;
    createdAt: string;
  }[];
}

export interface MentorProfile {
  id: string;
  studentId: string;
  name: string;
  avatar: string;
  universityName: string;
  department: string;
  year: number;
  skills: string[];
  topics: string[];
  bio: string;
  rating: number;
  sessionsCompleted: number;
  availableDays: string[];
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  type: 'connection' | 'resource' | 'team_application' | 'mentor' | 'event' | 'system';
  createdAt: string;
  read: boolean;
}
