import React from 'react';
import {
  GraduationCap,
  BookOpen,
  Code,
  Users,
  Calendar,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  Building2,
  FileText,
  Briefcase,
  Play
} from 'lucide-react';
import { University } from '../types';

interface LandingPageProps {
  universities: University[];
  onStartExploring: (tab: string) => void;
  onOpenDemoTour: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  universities,
  onStartExploring,
  onOpenDemoTour
}) => {
  return (
    <div className="bg-[#f8fafc] text-slate-900 dark:bg-slate-950 dark:text-slate-100 min-h-screen transition-colors duration-200">
      
      {/* HERO SECTION */}
      <section className="relative overflow-hidden py-16 lg:py-24 border-b border-slate-200 dark:border-slate-800 bg-gradient-to-b from-indigo-50/60 via-white to-[#f8fafc] dark:from-slate-900 dark:via-slate-950 dark:to-slate-950">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 bg-gradient-to-r from-indigo-500/10 via-purple-500/10 to-blue-500/10 dark:from-indigo-600/20 dark:via-purple-600/20 dark:to-blue-600/20 blur-3xl pointer-events-none rounded-full" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          
          <div className="inline-flex items-center space-x-2 bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-700/60 rounded-full px-4 py-1.5 text-xs font-semibold text-indigo-700 dark:text-indigo-300 mb-6 shadow-xs">
            <GraduationCap className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>Global Academic Network for Universities & Colleges</span>
          </div>

          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black tracking-tight text-slate-900 dark:text-white mb-6">
            Connect. Learn. <br className="hidden sm:inline" />
            <span className="bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 dark:from-indigo-400 dark:via-purple-400 dark:to-pink-400 bg-clip-text text-transparent">
              Collaborate & Build.
            </span>
          </h1>

          <p className="max-w-3xl mx-auto text-base sm:text-xl text-slate-600 dark:text-slate-300 leading-relaxed font-normal mb-8">
            A student-powered academic network connecting universities, verified PYQs, study resources, project showcases, and skill-based hackathon team matching in one unified ecosystem.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onStartExploring('resources')}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-7 py-3.5 rounded-xl shadow-md hover:shadow-lg shadow-indigo-600/25 flex items-center space-x-2 transition transform hover:-translate-y-0.5 cursor-pointer text-sm"
            >
              <span>Explore Verified PYQs & Notes</span>
              <ArrowRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => onStartExploring('teams')}
              className="bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700 text-slate-800 dark:text-slate-200 border border-slate-300 dark:border-slate-700 font-bold px-6 py-3.5 rounded-xl flex items-center space-x-2 transition shadow-xs cursor-pointer text-sm"
            >
              <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Find Hackathon Teammates</span>
            </button>

            <button
              onClick={onOpenDemoTour}
              className="bg-amber-400 hover:bg-amber-300 text-slate-950 font-extrabold px-6 py-3.5 rounded-xl flex items-center space-x-2 transition shadow-sm hover:shadow shadow-amber-400/20 cursor-pointer text-sm"
            >
              <Play className="w-4 h-4 fill-slate-950" />
              <span>5-Min Judge Demo Flow</span>
            </button>
          </div>

          {/* Key Quick Stats */}
          <div className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto text-left">
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="text-2xl lg:text-3xl font-extrabold text-indigo-600 dark:text-indigo-400">14,200+</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Verified Students</div>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="text-2xl lg:text-3xl font-extrabold text-purple-600 dark:text-purple-400">1,840+</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Solved PYQs & Notes</div>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="text-2xl lg:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400">620+</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Student Projects</div>
            </div>
            <div className="p-4 rounded-xl bg-white dark:bg-slate-900/80 border border-slate-200 dark:border-slate-800 shadow-xs">
              <div className="text-2xl lg:text-3xl font-extrabold text-amber-500 dark:text-amber-400">98%</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Team Synergy Rate</div>
            </div>
          </div>

        </div>
      </section>

      {/* 5 CORE PILLARS SECTION */}
      <section className="py-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Everything Students Need in One Ecosystem
          </h2>
          <p className="text-slate-600 dark:text-slate-400 text-sm sm:text-base mt-2 max-w-2xl mx-auto">
            Replacing fragmented WhatsApp drives, Telegram channels, and scattered drives with a structured university network.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Pillar 1: Learn */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-400 flex items-center justify-center mb-4 group-hover:bg-indigo-600 group-hover:text-white transition">
              <BookOpen className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">1. Academic Resource Library</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Access verified Previous Year Question (PYQ) papers, lab manuals, assignment solutions, and topper notes categorized by semester and subject.
            </p>
            <button
              onClick={() => onStartExploring('resources')}
              className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>Search MUJ Resources</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Pillar 2: Collaborate (Team Finder) */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-purple-400 dark:hover:border-purple-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 dark:bg-purple-950 dark:text-purple-400 flex items-center justify-center mb-4 group-hover:bg-purple-600 group-hover:text-white transition">
              <Users className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">2. Smart Teammate Finder</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Need a frontend dev, systems engineer, or hardware designer for a hackathon? Our recommendation engine calculates skill synergy and matches teammates instantly.
            </p>
            <button
              onClick={() => onStartExploring('teams')}
              className="text-xs font-bold text-purple-600 dark:text-purple-400 hover:text-purple-700 dark:hover:text-purple-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>Match Hackathon Teammates</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Pillar 3: Build & Showcase */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:bg-emerald-600 group-hover:text-white transition">
              <Code className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">3. Project & Research Showcase</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Publish your software, hardware, and research projects. Get feedback, upvotes, GitHub links, and showcase your work to university recruiters.
            </p>
            <button
              onClick={() => onStartExploring('projects')}
              className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>Explore Student Projects</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Pillar 4: Connect & Mentorship */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-400 dark:hover:border-amber-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-950 dark:text-amber-400 flex items-center justify-center mb-4 group-hover:bg-amber-600 group-hover:text-white transition">
              <GraduationCap className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">4. Senior Mentor Connect</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Connect with 3rd & 4th year seniors for 1-on-1 guidance on subject survival, off-campus internship strategy, and hackathon presentation skills.
            </p>
            <button
              onClick={() => onStartExploring('mentors')}
              className="text-xs font-bold text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>Find Senior Mentors</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Pillar 5: Discover Events & Clubs */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-pink-400 dark:hover:border-pink-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-pink-50 text-pink-600 dark:bg-pink-950 dark:text-pink-400 flex items-center justify-center mb-4 group-hover:bg-pink-600 group-hover:text-white transition">
              <Calendar className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">5. Campus Clubs & Hackathons</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Discover official coding clubs, robotics societies, inter-college hackathons, and technology workshops happening at MUJ and partner campuses.
            </p>
            <button
              onClick={() => onStartExploring('clubs-events')}
              className="text-xs font-bold text-pink-600 dark:text-pink-400 hover:text-pink-700 dark:hover:text-pink-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>View Upcoming Hackathons</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Pillar 6: Resume ATS */}
          <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-cyan-400 dark:hover:border-cyan-500/50 shadow-xs hover:shadow-md transition group">
            <div className="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-600 dark:bg-cyan-950 dark:text-cyan-400 flex items-center justify-center mb-4 group-hover:bg-cyan-600 group-hover:text-white transition">
              <Briefcase className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-2">6. Resume ATS & Portfolio</h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
              Automatically generate a recruiter-ready academic portfolio from your CampusConnect projects, badges, and PYQ contributions with ATS bullet suggestions.
            </p>
            <button
              onClick={() => onStartExploring('profile')}
              className="text-xs font-bold text-cyan-600 dark:text-cyan-400 hover:text-cyan-700 dark:hover:text-cyan-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>View My Student Portfolio</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      </section>

      {/* FEATURED UNIVERSITIES */}
      <section className="py-16 bg-slate-100/70 dark:bg-slate-900/60 border-y border-slate-200 dark:border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Cross-University Network</h2>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">Connecting students across top universities and affiliated colleges nationwide.</p>
            </div>
            <button
              onClick={() => onStartExploring('resources')}
              className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
            >
              <span>Explore All Campuses</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {universities.map(uni => (
              <div key={uni.id} className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-sm transition">
                <div className="flex items-center space-x-3 mb-3">
                  <img src={uni.logo} alt={uni.name} className="w-10 h-10 rounded-xl object-cover border border-slate-200 dark:border-slate-700" />
                  <div>
                    <h3 className="font-bold text-sm text-slate-900 dark:text-slate-100">{uni.name}</h3>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">{uni.location}</div>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[11px] bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 p-2.5 rounded-lg text-slate-600 dark:text-slate-300">
                  <div>Students: <strong className="text-indigo-600 dark:text-indigo-400">{uni.studentCount.toLocaleString()}</strong></div>
                  <div>PYQs: <strong className="text-purple-600 dark:text-purple-400">{uni.resourceCount}</strong></div>
                  <div>Projects: <strong className="text-emerald-600 dark:text-emerald-400">{uni.projectCount}</strong></div>
                  <div>Status: <span className="text-emerald-600 dark:text-emerald-400 font-bold">Verified</span></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="py-10 bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 dark:text-slate-400 text-center">
        <div className="max-w-7xl mx-auto px-4">
          <div className="font-extrabold text-slate-800 dark:text-slate-200 text-lg mb-2">CampusConnect</div>
          <p className="max-w-md mx-auto text-slate-500 dark:text-slate-400 text-xs mb-4">
            The Student-Only Academic & Professional Network for Universities across all engineering disciplines.
          </p>
          <div className="flex justify-center space-x-4 text-slate-500 dark:text-slate-400 text-xs mb-4">
            <button onClick={() => onStartExploring('resources')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Academic PYQs</button>
            <span>•</span>
            <button onClick={() => onStartExploring('teams')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Team Matcher</button>
            <span>•</span>
            <button onClick={() => onStartExploring('discussion')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Q&A Forum</button>
            <span>•</span>
            <button onClick={() => onStartExploring('admin')} className="hover:text-slate-900 dark:hover:text-white cursor-pointer">Admin Console</button>
          </div>
          <div className="text-[11px] text-slate-400 dark:text-slate-500">
            © 2026 CampusConnect. All rights reserved.
          </div>
        </div>
      </footer>

    </div>
  );
};
