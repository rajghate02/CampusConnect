import React, { useState } from 'react';
import {
  Shield,
  CheckCircle2,
  AlertTriangle,
  Users,
  BookOpen,
  Code,
  Building2,
  Trash2,
  Sparkles
} from 'lucide-react';
import { University, AcademicResource } from '../types';

interface AdminDashboardProps {
  universities: University[];
  resources: AcademicResource[];
  onVerifyResource: (resId: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  universities,
  resources,
  onVerifyResource
}) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'moderation' | 'universities'>('overview');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 space-y-8 transition-colors duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <Shield className="w-5 h-5 text-amber-500 dark:text-amber-400" />
            <span className="text-xs font-bold text-amber-800 dark:text-amber-400 bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-transparent px-2.5 py-0.5 rounded">
              University Admin Console
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
            Platform Moderation & Analytics
          </h1>
        </div>

        <div className="flex space-x-2 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeTab === 'overview'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Analytics
          </button>
          <button
            onClick={() => setActiveTab('moderation')}
            className={`px-3.5 py-2 rounded-xl font-bold transition cursor-pointer ${
              activeTab === 'moderation'
                ? 'bg-amber-500 text-slate-950 shadow-xs'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-800 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            Resource Moderation Queue
          </button>
        </div>
      </div>

      {/* METRICS GRID */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400">Total Registered Students</div>
          <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">14,200+</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400">Academic PYQs & Notes</div>
          <div className="text-2xl font-black text-purple-600 dark:text-purple-400 mt-1">{resources.length + 1800}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400">Student Projects</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">620+</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400">Partner Campuses</div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">{universities.length}</div>
        </div>
      </div>

      {/* MODERATION QUEUE */}
      {activeTab === 'moderation' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">Unverified Resource Approvals</h2>
          <div className="space-y-4">
            {resources.map(res => (
              <div key={res.id} className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl flex items-center justify-between border border-slate-200 dark:border-slate-800 text-xs">
                <div>
                  <div className="font-bold text-slate-900 dark:text-slate-200">{res.title}</div>
                  <div className="text-slate-500 dark:text-slate-400 text-[11px] mt-0.5">Course: {res.courseName} • Uploader: {res.uploaderName} ({res.universityName})</div>
                </div>

                <div className="flex items-center space-x-2">
                  {res.verifiedByFaculty ? (
                    <span className="text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-emerald-800 px-3 py-1 rounded-lg">
                      Verified
                    </span>
                  ) : (
                    <button
                      onClick={() => onVerifyResource(res.id)}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-3 py-1.5 rounded-lg transition shadow-xs cursor-pointer"
                    >
                      Approve & Verify
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* UNIVERSITIES LIST */}
      {activeTab === 'overview' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-4">University Isolation & System Status</h2>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
            {universities.map(u => (
              <div key={u.id} className="py-3 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img src={u.logo} alt={u.name} className="w-8 h-8 rounded-lg object-cover border border-slate-200 dark:border-slate-700" />
                  <div>
                    <div className="font-bold text-slate-900 dark:text-slate-200">{u.name} ({u.shortCode})</div>
                    <div className="text-slate-500 dark:text-slate-400 text-[11px]">{u.location}</div>
                  </div>
                </div>
                <div className="text-right text-slate-600 dark:text-slate-300">
                  <div><strong>{u.studentCount.toLocaleString()}</strong> Students</div>
                  <div className="text-emerald-600 dark:text-emerald-400 font-bold">Active & Isolation Enforced</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
