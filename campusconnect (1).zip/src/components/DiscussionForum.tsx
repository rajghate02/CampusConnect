import React, { useState } from 'react';
import {
  MessageSquare,
  ThumbsUp,
  CheckCircle2,
  Plus,
  HelpCircle,
  Award,
  X,
  Search
} from 'lucide-react';
import { ForumQuestion, StudentProfile, University } from '../types';
import { CollegeTag } from './CollegeTag';

interface DiscussionForumProps {
  questions: ForumQuestion[];
  student: StudentProfile;
  selectedUniversity: University;
  onCreateQuestion: (q: ForumQuestion) => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
}

export const DiscussionForum: React.FC<DiscussionForumProps> = ({
  questions,
  student,
  selectedUniversity,
  onCreateQuestion,
  searchQuery = '',
  setSearchQuery
}) => {
  const [showAskModal, setShowAskModal] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newCourse, setNewCourse] = useState('Data Structures & Algorithms');
  const [newContent, setNewContent] = useState('');

  const sQuery = (searchQuery || '').toLowerCase().trim();
  const isDsaSearch = sQuery === 'dsa' || sQuery.includes('dsa') || sQuery.includes('algo') || sQuery.includes('data structure');

  const filteredQuestions = questions.filter(q => {
    if (!sQuery) return true;
    return q.title.toLowerCase().includes(sQuery) ||
      q.courseName.toLowerCase().includes(sQuery) ||
      q.content.toLowerCase().includes(sQuery) ||
      q.tags.some(t => t.toLowerCase().includes(sQuery)) ||
      (isDsaSearch && (
        q.title.toLowerCase().includes('dsa') ||
        q.courseName.toLowerCase().includes('data structure') ||
        q.content.toLowerCase().includes('tree') ||
        q.content.toLowerCase().includes('graph')
      ));
  });

  const handleCreateQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const created: ForumQuestion = {
      id: `fq_${Date.now()}`,
      title: newTitle,
      content: newContent || 'Looking for guidance from seniors on this topic.',
      courseName: newCourse,
      tags: ['Q&A', selectedUniversity.shortCode, 'AcademicHelp'],
      authorId: student.id,
      authorName: student.name,
      authorAvatar: student.avatar,
      authorUniversity: selectedUniversity.name,
      createdAt: new Date().toISOString().split('T')[0],
      upvotesCount: 1,
      answersCount: 0,
      hasAcceptedAnswer: false,
      answers: []
    };

    onCreateQuestion(created);
    setShowAskModal(false);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-900 dark:text-indigo-300 dark:border-transparent font-bold px-2.5 py-0.5 rounded text-xs">
              Reputation & Gamified Q&A
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Earn Badges for Verified Answers</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
            Academic Discussion Forum
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
            Ask course doubts, get step-by-step exam solutions, and earn contribution points at {selectedUniversity.shortCode}.
          </p>
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto">
          {/* Forum Search Bar */}
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search doubts (DSA, AVL, PYQ)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery && setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery && setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={() => setShowAskModal(true)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2.5 rounded-xl shadow-xs hover:shadow flex items-center space-x-2 transition cursor-pointer text-xs shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Ask Question (+10 Pts)</span>
          </button>
        </div>
      </div>

      {/* Forum Questions List */}
      <div className="space-y-6">
        {filteredQuestions.length === 0 ? (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-500 dark:text-slate-400 shadow-xs">
            <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">No discussion questions matching "{searchQuery}"</p>
            <p className="mt-1 text-slate-500 dark:text-slate-400">Be the first to post a doubt on this topic!</p>
          </div>
        ) : (
          filteredQuestions.map(q => (
          <div key={q.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs hover:shadow-md transition">
            
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-bold text-indigo-700 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950 border border-indigo-200 dark:border-transparent px-2.5 py-1 rounded-lg">
                {q.courseName}
              </span>
              {q.hasAcceptedAnswer && (
                <div className="flex items-center space-x-1 text-[11px] font-bold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950 px-2.5 py-1 rounded-full border border-emerald-200 dark:border-emerald-800">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  <span>Accepted Answer</span>
                </div>
              )}
            </div>

            <h2 className="text-lg font-extrabold text-slate-900 dark:text-white mb-2">{q.title}</h2>
            <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">{q.content}</p>

            {/* Author info */}
            <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800/80 text-xs text-slate-500 dark:text-slate-400">
              <div className="flex items-center space-x-2">
                <img src={q.authorAvatar} alt={q.authorName} className="w-6 h-6 rounded-full object-cover shrink-0 border border-slate-300 dark:border-slate-700" />
                <span className="font-semibold text-slate-800 dark:text-slate-200">{q.authorName}</span>
                <CollegeTag universityName={q.authorUniversity} />
              </div>
              <div className="flex items-center space-x-3">
                <span className="text-indigo-600 dark:text-indigo-400 font-bold">▲ {q.upvotesCount} Upvotes</span>
                <span>•</span>
                <span>{q.answers.length} Answers</span>
              </div>
            </div>

            {/* Answers Box */}
            {q.answers.length > 0 && (
              <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-3">
                <div className="text-xs font-bold text-slate-700 dark:text-slate-300">Top Answer:</div>
                {q.answers.map(ans => (
                  <div key={ans.id} className="bg-slate-50 dark:bg-slate-950 p-4 rounded-xl text-xs border border-slate-200 dark:border-slate-800">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <img src={ans.authorAvatar} alt={ans.authorName} className="w-6 h-6 rounded-full object-cover shrink-0 border border-slate-300 dark:border-slate-700" />
                        <span className="font-bold text-slate-800 dark:text-slate-200">{ans.authorName}</span>
                        <CollegeTag universityName={q.authorUniversity} />
                      </div>
                      {ans.isAccepted && (
                        <span className="text-[10px] text-emerald-700 dark:text-emerald-400 font-bold bg-emerald-50 dark:bg-emerald-950 border border-emerald-200 dark:border-transparent px-2 py-0.5 rounded">
                          ✓ Verified Solution
                        </span>
                      )}
                    </div>
                    <p className="text-slate-600 dark:text-slate-300 leading-relaxed">{ans.content}</p>
                  </div>
                ))}
              </div>
            )}

          </div>
        )))
        }
      </div>

      {/* ASK QUESTION MODAL */}
      {showAskModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowAskModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
              Ask Academic Question
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Get verified answers from seniors and faculty for {selectedUniversity.shortCode} courses.
            </p>

            <form onSubmit={handleCreateQuestion} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Question Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. How do I solve LR rotations in AVL trees?"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Course / Subject</label>
                <input
                  type="text"
                  value={newCourse}
                  onChange={(e) => setNewCourse(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Detailed Explanation</label>
                <textarea
                  rows={4}
                  placeholder="Include specific question details, equations, or code snippets..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowAskModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl shadow-xs"
                >
                  Post Question
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
