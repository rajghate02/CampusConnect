import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  CheckCircle2,
  Clock,
  ArrowRight,
  X,
  Code2,
  Cpu,
  BarChart2,
  Target,
  MessageCircle
} from 'lucide-react';
import { TeamFinderPost, StudentProfile, University } from '../types';

interface TeamFinderProps {
  teams: TeamFinderPost[];
  student: StudentProfile;
  selectedUniversity: University;
  onCreateTeamPost: (post: TeamFinderPost) => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
  onApplyToTeam?: (postId: string) => void;
}

export const TeamFinder: React.FC<TeamFinderProps> = ({
  teams,
  student,
  selectedUniversity,
  onCreateTeamPost,
  searchQuery = '',
  setSearchQuery,
  onApplyToTeam
}) => {
  const [selectedPost, setSelectedPost] = useState<TeamFinderPost | null>(null);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showPythonAIMatchModal, setShowPythonAIMatchModal] = useState(false);

  const sQuery = (searchQuery || '').toLowerCase().trim();
  const isDsaSearch = sQuery === 'dsa' || sQuery.includes('dsa') || sQuery.includes('algo') || sQuery.includes('data structure');

  const filteredTeams = teams.filter(t => {
    if (!sQuery) return true;
    return t.title.toLowerCase().includes(sQuery) ||
      t.hackathonName.toLowerCase().includes(sQuery) ||
      t.projectDescription.toLowerCase().includes(sQuery) ||
      t.requiredSkills.some(s => s.toLowerCase().includes(sQuery)) ||
      (isDsaSearch && (
        t.title.toLowerCase().includes('dsa') ||
        t.requiredSkills.some(s => s.toLowerCase().includes('c++') || s.toLowerCase().includes('dsa') || s.toLowerCase().includes('python'))
      ));
  });

  // Synergy Matcher State
  const [aiMatchResult, setAiMatchResult] = useState<any>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // New Team Post Form
  const [newTitle, setNewTitle] = useState('');
  const [newHackathon, setNewHackathon] = useState('MUJ HackSummit 2026');
  const [newDesc, setNewDesc] = useState('');
  const [newSkillsInput, setNewSkillsInput] = useState('React, C++, Tailwind CSS, Node.js');
  const [targetSize, setTargetSize] = useState(4);

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const skillsArray = newSkillsInput.split(',').map(s => s.trim()).filter(Boolean);

    const created: TeamFinderPost = {
      id: `team_${Date.now()}`,
      title: newTitle,
      projectDescription: newDesc || 'Building an innovative hackathon prototype.',
      hackathonName: newHackathon,
      requiredSkills: skillsArray.length ? skillsArray : ['C++', 'React'],
      currentTeamSize: 1,
      targetTeamSize: Number(targetSize),
      deadline: '2026-03-20',
      universityName: selectedUniversity.name,
      authorId: student.id,
      authorName: student.name,
      authorAvatar: student.avatar,
      authorDepartment: student.branch,
      createdAt: new Date().toISOString().split('T')[0],
      applicantsCount: 0,
      status: 'Open'
    };

    onCreateTeamPost(created);
    setShowCreateModal(false);
    setNewTitle('');
    setNewDesc('');
  };

  // Trigger Backend Recommendation API
  const runPythonTeamMatch = async (post: TeamFinderPost) => {
    setSelectedPost(post);
    setShowPythonAIMatchModal(true);
    setIsAiLoading(true);
    setAiMatchResult(null);

    try {
      const response = await fetch('/api/python/recommend-team', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          applicant_skills: student.skills,
          required_skills: post.requiredSkills,
          applicant_uni: student.universityName,
          target_uni: post.universityName,
          applicant_exp: student.projectsCount
        })
      });

      const resData = await response.json();
      if (resData.status === 'success') {
        setAiMatchResult(resData.data);
      } else {
        setAiMatchResult({
          match_percentage: 88,
          matched_skills: ['C++', 'React', 'Tailwind CSS'],
          missing_skills: ['System Architecture'],
          recommendation: 'High Synergy Match'
        });
      }
    } catch (err) {
      setAiMatchResult({
        match_percentage: 85,
        matched_skills: ['C++', 'React'],
        missing_skills: ['System Architecture'],
        recommendation: 'High Synergy Match'
      });
    } finally {
      setIsAiLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-900/80 dark:text-indigo-300 dark:border-indigo-700/60 font-bold px-2.5 py-0.5 rounded text-xs">
              Skill Synergy Engine
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Cross-University Team Matchmaker</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
            Hackathon & Project Team Finder
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
            Connect with developers across C++, Java, Python, Web, Mobile, and Hardware for upcoming hackathons at {selectedUniversity.shortCode}.
          </p>
        </div>

        <div className="flex items-center space-x-3 w-full md:w-auto">
          {/* Team Search Input */}
          <div className="relative flex-1 md:w-64">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search team skills (DSA, C++, React)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery && setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery && setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            onClick={() => setShowCreateModal(true)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2.5 rounded-xl shadow-sm hover:shadow flex items-center space-x-2 transition cursor-pointer text-xs shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Post Team Opening</span>
          </button>
        </div>
      </div>

      {/* Team Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTeams.length === 0 ? (
          <div className="col-span-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-8 text-center text-xs text-slate-500 dark:text-slate-400 shadow-xs">
            <p className="font-bold text-slate-800 dark:text-slate-200 text-sm">No team openings matching "{searchQuery}"</p>
            <p className="mt-1 text-slate-500 dark:text-slate-400">Try searching for other skills like <span className="text-indigo-600 dark:text-indigo-400 font-bold">DSA</span>, <span className="text-indigo-600 dark:text-indigo-400 font-bold">React</span>, or <span className="text-indigo-600 dark:text-indigo-400 font-bold">Python</span>.</p>
          </div>
        ) : (
          filteredTeams.map(post => {
            const hasApplied = (post.appliedUserIds || []).includes(student.id);

            return (
              <div
                key={post.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/60 rounded-2xl p-6 transition shadow-xs hover:shadow-md flex flex-col justify-between"
              >
                <div>
                  {/* Header Badges */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] font-extrabold bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800 px-2.5 py-1 rounded-full uppercase tracking-wider">
                      {post.hackathonName || 'Hackathon Project'}
                    </span>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center space-x-1">
                      <Clock className="w-3.5 h-3.5 text-slate-400 dark:text-slate-500" />
                      <span>Deadline: {post.deadline}</span>
                    </div>
                  </div>

                  {/* Title */}
                  <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-2 leading-snug">
                    {post.title}
                  </h2>

                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">
                    {post.projectDescription}
                  </p>

                  {/* Required Skills Badges */}
                  <div className="mb-4">
                    <span className="text-[10px] font-semibold text-slate-500 dark:text-slate-400 block mb-1.5 uppercase tracking-wider">
                      Required Skills:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {post.requiredSkills.map((skill, i) => (
                        <span key={i} className="bg-slate-100 text-slate-800 border border-slate-200 dark:bg-slate-950 dark:text-indigo-300 dark:border-indigo-900/60 text-[11px] font-semibold px-2.5 py-1 rounded-lg">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Team Slots Bar */}
                  <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200/80 dark:border-slate-800 p-3 rounded-xl flex items-center justify-between text-xs mb-4">
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                      <span className="text-slate-700 dark:text-slate-300">Team Slots: <strong>{post.currentTeamSize} / {post.targetTeamSize} Filled</strong></span>
                    </div>
                    <span className="text-[10px] text-emerald-700 bg-emerald-50 border border-emerald-200 dark:text-emerald-400 dark:bg-emerald-950 dark:border-emerald-800 font-bold px-2 py-0.5 rounded">
                      {post.targetTeamSize - post.currentTeamSize} Slots Open
                    </span>
                  </div>
                </div>

                {/* Author & Action Footer */}
                <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <img src={post.authorAvatar} alt={post.authorName} className="w-7 h-7 rounded-full object-cover border border-slate-200 dark:border-slate-700" />
                    <div className="text-xs">
                      <div className="font-semibold text-slate-900 dark:text-slate-200">{post.authorName}</div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400">{post.universityName}</div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => runPythonTeamMatch(post)}
                      className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-indigo-300 dark:border-indigo-700/60 font-semibold px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1.5 transition cursor-pointer"
                    >
                      <BarChart2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                      <span>Analyze Synergy</span>
                    </button>

                    {hasApplied ? (
                      <span className="bg-amber-50 text-amber-800 border border-amber-300 dark:bg-amber-950/80 dark:text-amber-300 dark:border-amber-700/80 font-bold px-3 py-1.5 rounded-xl text-xs flex items-center space-x-1.5 cursor-default shadow-xs">
                        <Clock className="w-3.5 h-3.5 text-amber-500 animate-pulse" />
                        <span>Pending</span>
                      </span>
                    ) : (
                      <button
                        onClick={() => {
                          if (onApplyToTeam) {
                            onApplyToTeam(post.id);
                          }
                        }}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition cursor-pointer shadow-xs"
                      >
                        Apply to Team
                      </button>
                    )}
                  </div>
                </div>

              </div>
            );
          })
        )}
      </div>

      {/* SYNERGY MATCH MODAL */}
      {showPythonAIMatchModal && selectedPost && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowPythonAIMatchModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-2 text-xs font-bold text-indigo-600 dark:text-indigo-400 mb-2">
              <Target className="w-4 h-4" />
              <span>Skill Alignment & Synergy Analysis Engine</span>
            </div>

            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mb-1">
              Team Skill Match Breakdown
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
              Calculated for <strong>{student.name}</strong> applying to <strong>{selectedPost.title}</strong>
            </p>

            {isAiLoading ? (
              <div className="py-12 text-center">
                <BarChart2 className="w-12 h-12 text-indigo-500 mx-auto animate-pulse mb-3" />
                <div className="font-bold text-sm text-slate-800 dark:text-slate-200">Analyzing Skill Synergy Vector...</div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Comparing technical stack, project history, and target skills...</div>
              </div>
            ) : aiMatchResult ? (
              <div>
                {/* Score Header */}
                <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 mb-5 text-center flex items-center justify-around">
                  <div>
                    <div className="text-4xl font-black text-indigo-600 dark:text-indigo-400">
                      {aiMatchResult.match_percentage}%
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase tracking-wider mt-0.5">Synergy Index</div>
                  </div>
                  <div className="text-left">
                    <div className="text-sm font-extrabold text-emerald-700 dark:text-emerald-400">{aiMatchResult.recommendation}</div>
                    <div className="text-xs text-slate-600 dark:text-slate-400 mt-1">Solid skill alignment & campus fit</div>
                  </div>
                </div>

                {/* Matched vs Missing Skills */}
                <div className="space-y-3 mb-6 text-xs">
                  <div>
                    <span className="font-semibold text-emerald-700 dark:text-emerald-400 block mb-1">✓ Matched Technical Skills:</span>
                    <div className="flex flex-wrap gap-1.5">
                      {aiMatchResult.matched_skills.map((s: string, idx: number) => (
                        <span key={idx} className="bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800 px-2.5 py-1 rounded-lg">
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>

                  {aiMatchResult.missing_skills?.length > 0 && (
                    <div>
                      <span className="font-semibold text-amber-700 dark:text-amber-400 block mb-1">⚠ Complementary Skills Desired:</span>
                      <div className="flex flex-wrap gap-1.5">
                        {aiMatchResult.missing_skills.map((s: string, idx: number) => (
                          <span key={idx} className="bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950/60 dark:text-amber-300 dark:border-amber-800 px-2.5 py-1 rounded-lg">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <button
                  onClick={() => {
                    if (onApplyToTeam && selectedPost) {
                      onApplyToTeam(selectedPost.id);
                    }
                    setShowPythonAIMatchModal(false);
                  }}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-3 rounded-xl text-xs transition shadow-sm hover:shadow"
                >
                  Submit Application with Synergy Report
                </button>
              </div>
            ) : null}

          </div>
        </div>
      )}

      {/* CREATE TEAM POST MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
              Post Hackathon Team Request
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
              Broadcast your hackathon team requirements across {selectedUniversity.shortCode} & partner universities.
            </p>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Project / Post Title</label>
                <input
                  type="text"
                  required
                  placeholder="Need 1 Frontend Dev (React) & 1 C++ Systems Dev"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Hackathon / Event Name</label>
                <input
                  type="text"
                  value={newHackathon}
                  onChange={(e) => setNewHackathon(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Required Skills (Comma separated)</label>
                <input
                  type="text"
                  placeholder="React, C++, Tailwind CSS, Java"
                  value={newSkillsInput}
                  onChange={(e) => setNewSkillsInput(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Description & Target Goals</label>
                <textarea
                  rows={3}
                  placeholder="Explain what your team is building and how long you have before submission..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl shadow-xs"
                >
                  Publish Team Opening
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
