import React, { useState, useRef, useEffect } from 'react';
import {
  GraduationCap,
  BookOpen,
  Code,
  Users,
  Calendar,
  MessageSquare,
  Award,
  Bell,
  Search,
  Plus,
  Play,
  Shield,
  User as UserIcon,
  ChevronDown,
  BarChart2,
  Building2,
  CheckCircle2,
  LogIn,
  UserPlus,
  LogOut,
  Zap,
  Lock,
  ArrowRight,
  X,
  Sparkles,
  Sun,
  Moon
} from 'lucide-react';
import { CollegeTag } from './CollegeTag';
import { University, StudentProfile, NotificationItem, ProjectShowcase, AcademicResource, ForumQuestion, TeamFinderPost } from '../types';
import { useTheme } from '../context/ThemeContext';

interface NavbarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  selectedUniversity: University;
  setSelectedUniversity: (uni: University) => void;
  universities: University[];
  student: StudentProfile;
  notifications: NotificationItem[];
  onOpenDemoModal: () => void;
  onOpenAIResourceAssistant: () => void;
  onOpenAIResumeGrader: () => void;
  onOpenUploadResource: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  isLoggedIn?: boolean;
  onOpenAuthModal?: (mode: 'signin' | 'signup') => void;
  onLogout?: () => void;
  projects?: ProjectShowcase[];
  resources?: AcademicResource[];
  forumQuestions?: ForumQuestion[];
  teams?: TeamFinderPost[];
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  setCurrentTab,
  selectedUniversity,
  setSelectedUniversity,
  universities,
  student,
  notifications,
  onOpenDemoModal,
  onOpenAIResourceAssistant,
  onOpenAIResumeGrader,
  onOpenUploadResource,
  searchQuery,
  setSearchQuery,
  isLoggedIn = true,
  onOpenAuthModal,
  onLogout,
  projects = [],
  resources = [],
  forumQuestions = [],
  teams = []
}) => {
  const { theme, toggleTheme } = useTheme();
  const [showUniDropdown, setShowUniDropdown] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setShowSearchDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const unreadCount = notifications.filter(n => !n.read).length;

  const cleanQuery = (searchQuery || '').trim().toLowerCase();
  const isDsaSearch = cleanQuery === 'dsa' || cleanQuery.includes('dsa') || cleanQuery.includes('algo') || cleanQuery.includes('data structure');

  const matchedProjects = cleanQuery ? (projects || []).filter(p => {
    return p.title.toLowerCase().includes(cleanQuery) ||
      p.description.toLowerCase().includes(cleanQuery) ||
      p.category.toLowerCase().includes(cleanQuery) ||
      p.techStack.some(t => t.toLowerCase().includes(cleanQuery)) ||
      (isDsaSearch && (p.title.toLowerCase().includes('dsa') || p.techStack.some(t => t.toLowerCase().includes('dsa') || t.toLowerCase().includes('c++') || t.toLowerCase().includes('algo'))));
  }) : [];

  const matchedResources = cleanQuery ? (resources || []).filter(r => {
    return (r.title || '').toLowerCase().includes(cleanQuery) ||
      (r.subject || '').toLowerCase().includes(cleanQuery) ||
      (r.topic || '').toLowerCase().includes(cleanQuery) ||
      (r.courseCode || '').toLowerCase().includes(cleanQuery) ||
      (r.tags || []).some(t => (t || '').toLowerCase().includes(cleanQuery)) ||
      (isDsaSearch && ((r.title || '').toLowerCase().includes('data structure') || (r.subject || '').toLowerCase().includes('data structure')));
  }) : [];

  const matchedQuestions = cleanQuery ? (forumQuestions || []).filter(q => {
    return q.title.toLowerCase().includes(cleanQuery) ||
      q.courseName.toLowerCase().includes(cleanQuery) ||
      q.content.toLowerCase().includes(cleanQuery) ||
      q.tags.some(t => t.toLowerCase().includes(cleanQuery)) ||
      (isDsaSearch && (q.title.toLowerCase().includes('dsa') || q.courseName.toLowerCase().includes('data structure')));
  }) : [];

  const matchedTeams = cleanQuery ? (teams || []).filter(t => {
    return t.title.toLowerCase().includes(cleanQuery) ||
      t.hackathonName.toLowerCase().includes(cleanQuery) ||
      t.requiredSkills.some(s => s.toLowerCase().includes(cleanQuery)) ||
      (isDsaSearch && (t.title.toLowerCase().includes('dsa') || t.requiredSkills.some(s => s.toLowerCase().includes('c++') || s.toLowerCase().includes('dsa'))));
  }) : [];

  const totalMatches = matchedProjects.length + matchedResources.length + matchedQuestions.length + matchedTeams.length;

  const navItems = [
    { id: 'landing', label: 'Home', icon: GraduationCap },
    { id: 'university', label: 'Campus Realm', icon: Building2, badge: selectedUniversity.shortCode },
    { id: 'orbit', label: 'Synergy Orbit', icon: Zap, badge: 'Connect & Chat' },
    { id: 'feed', label: 'Feed', icon: BookOpen },
    { id: 'resources', label: 'PYQs & Notes', icon: BookOpen },
    { id: 'projects', label: 'Projects', icon: Code },
    { id: 'teams', label: 'Team Finder', icon: Users, badge: 'Synergy' },
    { id: 'discussion', label: 'Discussions', icon: MessageSquare },
    { id: 'clubs-events', label: 'Clubs & Hackathons', icon: Calendar },
    { id: 'mentors', label: 'Mentors', icon: Award },
    { id: 'admin', label: 'Admin', icon: Shield }
  ];

  return (
    <header className="sticky top-0 z-50 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 text-slate-900 dark:text-slate-100 transition-colors duration-200 shadow-xs">
      {/* Top Banner - Hackathon Demo Banner */}
      <div className="bg-gradient-to-r from-indigo-700 via-slate-800 to-blue-700 text-white text-xs py-1.5 px-4 flex items-center justify-between shadow-inner">
        <div className="flex items-center space-x-2 font-medium overflow-x-auto whitespace-nowrap">
          <span className="bg-white/20 text-white px-2 py-0.5 rounded-full font-bold uppercase tracking-wider text-[10px]">
            Live Campus Network
          </span>
          <span>CampusConnect Student Network — Viewing: <strong>{selectedUniversity.name} ({selectedUniversity.shortCode})</strong></span>
        </div>
        <div className="flex items-center space-x-3 text-xs font-semibold shrink-0">
          <button
            onClick={onOpenAIResourceAssistant}
            className="hidden md:flex items-center space-x-1 bg-white/10 hover:bg-white/20 px-2.5 py-0.5 rounded text-white transition cursor-pointer"
          >
            <BarChart2 className="w-3.5 h-3.5 text-amber-300" />
            <span>Exam Topic Matrix</span>
          </button>
          <button
            onClick={onOpenAIResumeGrader}
            className="hidden md:flex items-center space-x-1 bg-white/10 hover:bg-white/20 px-2.5 py-0.5 rounded text-white transition cursor-pointer"
          >
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
            <span>Resume & Portfolio Grader</span>
          </button>
          <button
            onClick={onOpenDemoModal}
            className="flex items-center space-x-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-bold px-3 py-0.5 rounded-full shadow transition cursor-pointer"
          >
            <Play className="w-3 h-3 fill-slate-950" />
            <span>5-Min Demo Tour</span>
          </button>
        </div>
      </div>

      {/* Main Navbar Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Logo & Brand */}
          <div className="flex items-center space-x-3 shrink-0 cursor-pointer" onClick={() => setCurrentTab('landing')}>
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-indigo-500/20 font-black text-xl tracking-tight">
              CC
            </div>
            <div>
              <span className="text-xl font-extrabold tracking-tight text-slate-900 dark:text-white">
                Campus<span className="text-indigo-600 dark:text-indigo-400">Connect</span>
              </span>
              <span className="hidden sm:inline-block ml-2 text-[10px] font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 dark:text-indigo-400 dark:bg-indigo-950/80 dark:border-indigo-800 px-2 py-0.5 rounded-full">
                Multi-Campus Network
              </span>
            </div>
          </div>

          {/* University Selector Dropdown */}
          <div className="relative shrink-0">
            <button
              onClick={() => setShowUniDropdown(!showUniDropdown)}
              className="flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200 dark:bg-slate-800/80 dark:hover:bg-slate-800 dark:border-slate-700/80 dark:text-slate-200 px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer"
            >
              <Building2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span className="max-w-[120px] sm:max-w-[160px] truncate font-semibold">
                {selectedUniversity.shortCode} - {selectedUniversity.name}
              </span>
              <ChevronDown className="w-3.5 h-3.5 text-slate-500 dark:text-slate-400" />
            </button>

            {showUniDropdown && (
              <div className="absolute left-0 mt-2 w-80 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden py-1">
                <div className="px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900/90 border-b border-slate-200 dark:border-slate-700/80">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-200">Explore Campus Realm</span>
                    <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-700 px-2 py-0.5 rounded font-extrabold flex items-center space-x-1">
                      <Lock className="w-2.5 h-2.5 text-slate-400" />
                      <span>Enrolled: {student.universityShort || 'MUJ'}</span>
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 leading-tight">
                    Switch campus views to discover friends, PYQs, and projects across universities.
                  </p>
                </div>
                <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/40">
                  {universities.map(uni => (
                    <button
                      key={uni.id}
                      onClick={() => {
                        setSelectedUniversity(uni);
                        setCurrentTab('university');
                        setShowUniDropdown(false);
                      }}
                      className={`w-full text-left px-3.5 py-2.5 flex items-center space-x-3 text-xs hover:bg-slate-50 dark:hover:bg-slate-700/60 transition cursor-pointer ${
                        selectedUniversity.id === uni.id
                          ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-bold border-l-2 border-indigo-600 dark:border-indigo-500'
                          : 'text-slate-800 dark:text-slate-200'
                      }`}
                    >
                      <img src={uni.logo} alt={uni.name} className="w-6 h-6 rounded-md object-cover shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold truncate flex items-center space-x-1">
                          <span>{uni.name}</span>
                          <span className="text-[10px] bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-indigo-700 dark:text-indigo-300 px-1 py-0.2 rounded font-mono shrink-0">
                            {uni.shortCode}
                          </span>
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">{uni.studentCount.toLocaleString()} Students • {uni.resourceCount} PYQs</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Global Search Bar */}
          <div ref={searchRef} className="hidden md:flex flex-1 max-w-sm relative">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search DSA, PYQs, projects, topics..."
              value={searchQuery}
              onFocus={() => setShowSearchDropdown(true)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchDropdown(true);
              }}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setShowSearchDropdown(false);
                  if (matchedProjects.length > 0 && matchedResources.length === 0) {
                    setCurrentTab('projects');
                  } else {
                    setCurrentTab('resources');
                  }
                }
              }}
              className="w-full bg-slate-100 dark:bg-slate-800/90 border border-slate-200 dark:border-slate-700/80 rounded-lg pl-9 pr-8 py-1.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 focus:bg-white dark:focus:bg-slate-800 transition"
            />
            {searchQuery && (
              <button
                onClick={() => {
                  setSearchQuery('');
                  setShowSearchDropdown(false);
                }}
                className="absolute right-2.5 top-2 text-slate-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Live Search Popup Overlay */}
            {showSearchDropdown && cleanQuery.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-2 bg-slate-900 border border-slate-700/90 rounded-2xl shadow-2xl z-50 overflow-hidden max-h-96 overflow-y-auto divide-y divide-slate-800">
                
                {/* Header summary */}
                <div className="px-3.5 py-2 bg-slate-950/90 flex items-center justify-between text-[11px] text-slate-400 font-medium">
                  <span className="flex items-center space-x-1 font-bold text-slate-200">
                    <Sparkles className="w-3 h-3 text-amber-400" />
                    <span>Search Results for "{searchQuery}"</span>
                  </span>
                  <span className="bg-indigo-950 text-indigo-300 font-mono px-2 py-0.5 rounded text-[10px] border border-indigo-800">
                    {totalMatches} matches
                  </span>
                </div>

                {totalMatches === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400 space-y-1">
                    <p className="font-semibold text-slate-300">No exact match for "{searchQuery}"</p>
                    <p className="text-[11px] text-slate-500">Try searching for <span className="text-indigo-400 font-bold">DSA</span>, <span className="text-indigo-400 font-bold">DBMS</span>, <span className="text-indigo-400 font-bold">PYQs</span>, or <span className="text-indigo-400 font-bold">React</span></p>
                  </div>
                ) : (
                  <>
                    {/* Projects Section */}
                    {matchedProjects.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[10px] font-extrabold text-cyan-400 uppercase tracking-wider flex items-center justify-between">
                          <span>Projects ({matchedProjects.length})</span>
                          <span className="text-slate-500 font-normal">Click to view in Projects</span>
                        </div>
                        {matchedProjects.slice(0, 3).map(p => (
                          <button
                            key={p.id}
                            onClick={() => {
                              setCurrentTab('projects');
                              setShowSearchDropdown(false);
                            }}
                            className="w-full text-left p-2 hover:bg-slate-800 rounded-xl transition flex items-start space-x-2.5 cursor-pointer group"
                          >
                            <Code className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-xs text-slate-200 group-hover:text-cyan-300 truncate">
                                {p.title}
                              </div>
                              <div className="text-[10px] text-slate-400 truncate">
                                {p.category} • {p.techStack.slice(0, 3).join(', ')}
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Resources / PYQs Section */}
                    {matchedResources.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[10px] font-extrabold text-emerald-400 uppercase tracking-wider flex items-center justify-between">
                          <span>Academic PYQs & Topics ({matchedResources.length})</span>
                          <span className="text-slate-500 font-normal">Click to view in Resources</span>
                        </div>
                        {matchedResources.slice(0, 3).map(r => (
                          <button
                            key={r.id}
                            onClick={() => {
                              setCurrentTab('resources');
                              setShowSearchDropdown(false);
                            }}
                            className="w-full text-left p-2 hover:bg-slate-800 rounded-xl transition flex items-start space-x-2.5 cursor-pointer group"
                          >
                            <BookOpen className="w-4 h-4 text-emerald-400 mt-0.5 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-xs text-slate-200 group-hover:text-emerald-300 truncate">
                                {r.title}
                              </div>
                              <div className="text-[10px] text-slate-400 truncate">
                                {r.subject || r.courseCode || 'Academic'} • {r.resourceType}
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Discussions Section */}
                    {matchedQuestions.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[10px] font-extrabold text-indigo-400 uppercase tracking-wider flex items-center justify-between">
                          <span>Discussions & Doubts ({matchedQuestions.length})</span>
                          <span className="text-slate-500 font-normal">Click to view Forum</span>
                        </div>
                        {matchedQuestions.slice(0, 2).map(q => (
                          <button
                            key={q.id}
                            onClick={() => {
                              setCurrentTab('discussion');
                              setShowSearchDropdown(false);
                            }}
                            className="w-full text-left p-2 hover:bg-slate-800 rounded-xl transition flex items-start space-x-2.5 cursor-pointer group"
                          >
                            <MessageSquare className="w-4 h-4 text-indigo-400 mt-0.5 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-xs text-slate-200 group-hover:text-indigo-300 truncate">
                                {q.title}
                              </div>
                              <div className="text-[10px] text-slate-400 truncate">
                                {q.courseName}
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Teams Section */}
                    {matchedTeams.length > 0 && (
                      <div className="p-2">
                        <div className="px-2 py-1 text-[10px] font-extrabold text-amber-400 uppercase tracking-wider flex items-center justify-between">
                          <span>Hackathon Teams ({matchedTeams.length})</span>
                          <span className="text-slate-500 font-normal">Click to view Teams</span>
                        </div>
                        {matchedTeams.slice(0, 2).map(t => (
                          <button
                            key={t.id}
                            onClick={() => {
                              setCurrentTab('teams');
                              setShowSearchDropdown(false);
                            }}
                            className="w-full text-left p-2 hover:bg-slate-800 rounded-xl transition flex items-start space-x-2.5 cursor-pointer group"
                          >
                            <Users className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
                            <div className="min-w-0 flex-1">
                              <div className="font-bold text-xs text-slate-200 group-hover:text-amber-300 truncate">
                                {t.title}
                              </div>
                              <div className="text-[10px] text-slate-400 truncate">
                                Skills: {t.requiredSkills.join(', ')}
                              </div>
                            </div>
                          </button>
                        ))}
                      </div>
                    )}

                    {/* Footer navigate button */}
                    <button
                      onClick={() => {
                        setShowSearchDropdown(false);
                        if (matchedProjects.length > 0 && matchedResources.length === 0) {
                          setCurrentTab('projects');
                        } else {
                          setCurrentTab('resources');
                        }
                      }}
                      className="w-full p-2.5 bg-slate-950 hover:bg-indigo-950 text-indigo-300 text-xs font-bold transition flex items-center justify-center space-x-1.5 cursor-pointer border-t border-slate-800"
                    >
                      <span>Explore all results for "{searchQuery}"</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </>
                )}
              </div>
            )}
          </div>

          {/* Action Buttons & Profile */}
          <div className="flex items-center space-x-2 shrink-0">
            {/* Quick Upload Resource Button */}
            <button
              onClick={onOpenUploadResource}
              className="hidden sm:flex items-center space-x-1.5 bg-indigo-600 hover:bg-indigo-500 text-white font-medium px-3 py-1.5 rounded-lg text-xs transition shadow-sm hover:shadow cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Upload PYQ/Notes</span>
            </button>

            {/* Theme Toggle Button */}
            <button
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
              title={`Switch to ${theme === 'light' ? 'Dark' : 'Light'} Mode`}
              className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800 rounded-lg relative transition cursor-pointer border border-slate-200 dark:border-slate-700/80 flex items-center justify-center"
            >
              {theme === 'light' ? (
                <Moon className="w-4 h-4 text-slate-700 hover:text-indigo-600 transition" />
              ) : (
                <Sun className="w-4 h-4 text-amber-400 hover:text-amber-300 transition" />
              )}
            </button>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 dark:text-slate-300 dark:hover:text-white dark:hover:bg-slate-800 rounded-lg relative transition cursor-pointer border border-slate-200 dark:border-slate-700/80"
              >
                <Bell className="w-4 h-4" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-indigo-500 rounded-full ring-2 ring-white dark:ring-slate-900 animate-pulse" />
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-2 w-80 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden">
                  <div className="px-4 py-3 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900 dark:text-slate-200">Campus Notifications</span>
                    <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-900 dark:text-indigo-300 px-2 py-0.5 rounded-full font-semibold">
                      {unreadCount} New
                    </span>
                  </div>
                  <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700/50">
                    {notifications.map(n => (
                      <div key={n.id} className="p-3 text-xs hover:bg-slate-50 dark:hover:bg-slate-700/40 transition">
                        <div className="font-semibold text-slate-800 dark:text-slate-200">{n.title}</div>
                        <div className="text-slate-600 dark:text-slate-400 mt-0.5">{n.message}</div>
                        <div className="text-[10px] text-indigo-600 dark:text-indigo-400 mt-1">{n.createdAt}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Profile Avatar & Menu or Sign In / Sign Up Buttons */}
            {isLoggedIn ? (
              <div className="relative">
                <button
                  onClick={() => setShowUserMenu(!showUserMenu)}
                  className="flex items-center space-x-2 p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
                >
                  <img
                    src={student.avatar}
                    alt={student.name}
                    className="w-8 h-8 rounded-full border border-indigo-500/50 object-cover"
                  />
                  <div className="hidden lg:block text-left text-xs">
                    <div className="font-semibold text-slate-800 dark:text-slate-200 truncate max-w-[140px] flex items-center space-x-1">
                      <span>{student.name}</span>
                      <CollegeTag tag={student.universityShort || 'MUJ'} universityName={student.universityName} />
                    </div>
                    <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate max-w-[120px]">{student.branch}</div>
                  </div>
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-2 w-64 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl shadow-2xl z-50 overflow-hidden py-1 text-xs">
                    <div className="px-3.5 py-2.5 bg-slate-50 dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 space-y-1">
                      <div className="font-bold text-slate-900 dark:text-slate-100 flex items-center space-x-1.5">
                        <span>{student.name}</span>
                        <CollegeTag tag={student.universityShort || 'MUJ'} universityName={student.universityName} />
                      </div>
                      <div className="text-slate-500 dark:text-slate-400 text-[11px] truncate">{student.email}</div>
                      <div className="text-[10px] text-emerald-600 dark:text-emerald-400 font-mono flex items-center space-x-1">
                        <Lock className="w-2.5 h-2.5 text-emerald-500 shrink-0" />
                        <span className="truncate">Enrolled: {student.universityName}</span>
                      </div>
                      <div className="mt-1 text-[10px] text-indigo-700 bg-indigo-50 border border-indigo-200 dark:text-indigo-300 dark:bg-indigo-950 dark:border-indigo-800 px-2 py-0.5 rounded inline-block font-semibold">
                        Reputation: {student.reputationPoints} pts
                      </div>
                    </div>
                    <button
                      onClick={() => { setCurrentTab('profile'); setShowUserMenu(false); }}
                      className="w-full text-left px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center space-x-2 transition cursor-pointer"
                    >
                      <UserIcon className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                      <span>My Student Profile ({student.profileCompletionPercentage}% Complete)</span>
                    </button>
                    <button
                      onClick={() => { onOpenAIResumeGrader(); setShowUserMenu(false); }}
                      className="w-full text-left px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center space-x-2 transition cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 dark:text-emerald-400" />
                      <span>Portfolio & ATS Resume Grader</span>
                    </button>
                    <button
                      onClick={() => { setCurrentTab('admin'); setShowUserMenu(false); }}
                      className="w-full text-left px-3 py-2 text-slate-700 dark:text-slate-200 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center space-x-2 transition cursor-pointer border-t border-slate-100 dark:border-slate-700"
                    >
                      <Shield className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400" />
                      <span>University Admin Console</span>
                    </button>
                    {onLogout && (
                      <button
                        onClick={() => {
                          setShowUserMenu(false);
                          onLogout();
                        }}
                        className="w-full text-left px-3 py-2 text-rose-600 dark:text-rose-300 hover:bg-rose-50 dark:hover:bg-rose-950/60 flex items-center space-x-2 transition cursor-pointer border-t border-slate-100 dark:border-slate-700 font-bold"
                      >
                        <LogOut className="w-3.5 h-3.5 text-rose-500 dark:text-rose-400" />
                        <span>Log Out</span>
                      </button>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => onOpenAuthModal && onOpenAuthModal('signin')}
                  className="flex items-center space-x-1 bg-slate-100 hover:bg-slate-200 text-slate-800 dark:bg-slate-800 dark:hover:bg-slate-700 dark:text-slate-200 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-200 dark:border-slate-700"
                >
                  <LogIn className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                  <span>Sign In</span>
                </button>
                <button
                  onClick={() => onOpenAuthModal && onOpenAuthModal('signup')}
                  className="flex items-center space-x-1 bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer shadow-sm"
                >
                  <UserPlus className="w-3.5 h-3.5 text-white" />
                  <span>Sign Up</span>
                </button>
              </div>
            )}

          </div>

        </div>
      </div>

      {/* Main Tab Links Bar */}
      <nav className="bg-slate-50/90 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800/80 px-4 sm:px-6 overflow-x-auto scrollbar-none transition-colors duration-200">
        <div className="max-w-7xl mx-auto flex space-x-1 sm:space-x-2 py-2">
          {navItems.map(item => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                  isActive
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 hover:bg-white dark:hover:bg-slate-800/70 border border-transparent hover:border-slate-200 dark:hover:border-slate-700'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : 'text-slate-400 dark:text-slate-500'}`} />
                <span>{item.label}</span>
                {item.badge && (
                  <span className={`text-[9px] px-1.5 py-0.2 rounded-full font-extrabold uppercase ${
                    isActive ? 'bg-indigo-700 text-white' : 'bg-slate-200 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 border border-slate-300 dark:border-indigo-800'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </header>
  );
};
