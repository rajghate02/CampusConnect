import React, { useState } from 'react';
import {
  Code,
  Plus,
  ExternalLink,
  Github,
  ThumbsUp,
  MessageSquare,
  Search,
  X,
  Sparkles,
  Layers
} from 'lucide-react';
import { ProjectShowcase, University, StudentProfile } from '../types';
import { CollegeTag } from './CollegeTag';

interface ProjectShowcaseProps {
  projects: ProjectShowcase[];
  student: StudentProfile;
  selectedUniversity: University;
  onCreateProject: (proj: ProjectShowcase) => void;
  searchQuery?: string;
  setSearchQuery?: (query: string) => void;
}

export const ProjectShowcaseView: React.FC<ProjectShowcaseProps> = ({
  projects,
  student,
  selectedUniversity,
  onCreateProject,
  searchQuery = '',
  setSearchQuery
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [showUploadModal, setShowUploadModal] = useState(false);

  // New Project Form
  const [newTitle, setNewTitle] = useState('');
  const [newCategory, setNewCategory] = useState<'AI/ML' | 'Web' | 'Robotics' | 'IoT' | 'Cybersecurity'>('AI/ML');
  const [newProblem, setNewProblem] = useState('');
  const [newSolution, setNewSolution] = useState('');
  const [newTechInput, setNewTechInput] = useState('Python, FastAPI, React, Tailwind CSS');
  const [newGithub, setNewGithub] = useState('https://github.com/my-student-project');
  const [newDemo, setNewDemo] = useState('https://demo.project.site');

  const categories = ['All', 'AI/ML', 'Web', 'Robotics', 'IoT', 'Cybersecurity', 'Research'];

  const sQuery = (searchQuery || '').toLowerCase().trim();
  const isDsaSearch = sQuery === 'dsa' || sQuery.includes('dsa') || sQuery.includes('algo') || sQuery.includes('data structure');

  const filteredProjects = projects.filter(p => {
    const matchesCategory = selectedCategory === 'All' || p.category === selectedCategory;
    const matchesUni = p.authorUniversity === selectedUniversity.name || selectedUniversity.id === 'all';

    const matchesSearch = !sQuery ||
      p.title.toLowerCase().includes(sQuery) ||
      p.description.toLowerCase().includes(sQuery) ||
      p.problemStatement.toLowerCase().includes(sQuery) ||
      p.solution.toLowerCase().includes(sQuery) ||
      p.category.toLowerCase().includes(sQuery) ||
      p.authorName.toLowerCase().includes(sQuery) ||
      p.authorUniversity.toLowerCase().includes(sQuery) ||
      p.techStack.some(t => t.toLowerCase().includes(sQuery)) ||
      (isDsaSearch && (
        p.title.toLowerCase().includes('dsa') ||
        p.title.toLowerCase().includes('data structure') ||
        p.title.toLowerCase().includes('algorithm') ||
        p.techStack.some(t => t.toLowerCase().includes('dsa') || t.toLowerCase().includes('c++') || t.toLowerCase().includes('algo'))
      ));

    return matchesCategory && matchesUni && matchesSearch;
  });

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const techStack = newTechInput.split(',').map(t => t.trim()).filter(Boolean);

    const created: ProjectShowcase = {
      id: `proj_${Date.now()}`,
      title: newTitle,
      description: newSolution.slice(0, 120) || 'Innovative student engineered project.',
      problemStatement: newProblem || 'Addressing real-world university & industry challenges.',
      solution: newSolution || 'Built scalable prototype with clean architecture.',
      category: newCategory,
      techStack: techStack.length ? techStack : ['Python', 'React'],
      images: ['https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&q=80&w=800'],
      demoUrl: newDemo,
      githubUrl: newGithub,
      authorId: student.id,
      authorName: student.name,
      authorAvatar: student.avatar,
      authorUniversity: selectedUniversity.name,
      authorDepartment: student.branch,
      teamMembers: [
        { name: student.name, role: 'Project Lead', avatar: student.avatar }
      ],
      upvotesCount: 1,
      commentsCount: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };

    onCreateProject(created);
    setShowUploadModal(false);
    setNewTitle('');
    setNewProblem('');
    setNewSolution('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-900 dark:text-emerald-300 dark:border-transparent font-bold px-2.5 py-0.5 rounded text-xs">
              Student Innovation Hub
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">Open Source & Research Projects</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
            University Project Showcase
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
            Discover software prototypes, robotics hardware, AI models, and research papers built by students at {selectedUniversity.shortCode}.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-4 py-2.5 rounded-xl shadow-xs hover:shadow flex items-center space-x-2 transition cursor-pointer text-xs shrink-0"
        >
          <Plus className="w-4 h-4" />
          <span>Publish Project</span>
        </button>
      </div>

      {/* Categories & Search Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-6">
        <div className="flex items-center space-x-2 overflow-x-auto pb-2 sm:pb-0 scrollbar-none">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition cursor-pointer ${
                selectedCategory === cat
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Project Search Bar */}
        <div className="relative max-w-md w-full">
          <Search className="w-4 h-4 absolute left-3.5 top-2.5 text-slate-400" />
          <input
            type="text"
            placeholder="Search projects (DSA, C++, React, AI, Robotics)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery && setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-8 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-emerald-500 transition shadow-xs"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery && setSearchQuery('')}
              className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredProjects.map(proj => (
          <div
            key={proj.id}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-400 dark:hover:border-emerald-500/60 rounded-2xl overflow-hidden transition shadow-xs hover:shadow-md flex flex-col justify-between"
          >
            <div className="p-6">
              
              {/* Category & Date */}
              <div className="flex items-center justify-between mb-3">
                <span className="text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800 px-2.5 py-1 rounded-full uppercase tracking-wider">
                  {proj.category}
                </span>
                <span className="text-[11px] text-slate-500 dark:text-slate-400">{proj.createdAt}</span>
              </div>

              {/* Title */}
              <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mb-2 group-hover:text-emerald-600 dark:group-hover:text-emerald-300 transition">
                {proj.title}
              </h2>

              {/* Problem & Solution */}
              <div className="space-y-2 mb-4 text-xs">
                <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-amber-600 dark:text-amber-400 font-bold block mb-0.5">Problem Statement:</span>
                  <p className="text-slate-600 dark:text-slate-300">{proj.problemStatement}</p>
                </div>
                <div className="bg-slate-50 dark:bg-slate-950/80 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
                  <span className="text-emerald-600 dark:text-emerald-400 font-bold block mb-0.5">Solution & Architecture:</span>
                  <p className="text-slate-600 dark:text-slate-300">{proj.solution}</p>
                </div>
              </div>

              {/* Tech Stack */}
              <div className="mb-4">
                <div className="flex flex-wrap gap-1.5">
                  {proj.techStack.map((tech, idx) => (
                    <span key={idx} className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 text-[10px] font-semibold px-2.5 py-1 rounded-lg">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>

            </div>

            {/* Author & External Links Footer */}
            <div className="p-4 bg-slate-50 dark:bg-slate-950/90 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
              
              <div className="flex items-center space-x-2">
                <img src={proj.authorAvatar} alt={proj.authorName} className="w-7 h-7 rounded-full object-cover border border-slate-200 dark:border-slate-700" />
                <div className="text-xs">
                  <div className="font-semibold text-slate-900 dark:text-slate-200 flex items-center space-x-1">
                    <span>{proj.authorName}</span>
                    <CollegeTag universityName={proj.authorUniversity} />
                  </div>
                  <div className="text-[10px] text-slate-500 dark:text-slate-400">{proj.authorUniversity}</div>
                </div>
              </div>

              <div className="flex items-center space-x-2">
                {proj.githubUrl && (
                  <a
                    href={proj.githubUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 rounded-lg transition border border-slate-200 dark:border-slate-700"
                    title="View GitHub Repository"
                  >
                    <Github className="w-4 h-4" />
                  </a>
                )}

                {proj.demoUrl && (
                  <a
                    href={proj.demoUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg transition flex items-center space-x-1 text-xs font-semibold shadow-xs"
                  >
                    <span>Live Demo</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                )}
              </div>

            </div>

          </div>
        ))}
      </div>

      {/* UPLOAD PROJECT MODAL */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowUploadModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
              Publish Student Project
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Add your software, AI model, or hardware build to the CampusConnect showcase.
            </p>

            <form onSubmit={handleCreateProject} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Project Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. AI-Powered Campus Quadcopter Drone"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Category</label>
                <select
                  value={newCategory}
                  onChange={(e: any) => setNewCategory(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none cursor-pointer"
                >
                  <option value="AI/ML">AI / Machine Learning</option>
                  <option value="Web">Web Application</option>
                  <option value="Robotics">Robotics & Hardware</option>
                  <option value="IoT">IoT & Embedded Systems</option>
                  <option value="Cybersecurity">Cybersecurity</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Problem Statement</label>
                <textarea
                  rows={2}
                  placeholder="What problem does your project solve for students or industry?"
                  value={newProblem}
                  onChange={(e) => setNewProblem(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Proposed Solution & Tech Architecture</label>
                <textarea
                  rows={2}
                  placeholder="Explain your approach, models used, or circuit components..."
                  value={newSolution}
                  onChange={(e) => setNewSolution(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Tech Stack (Comma separated)</label>
                <input
                  type="text"
                  value={newTechInput}
                  onChange={(e) => setNewTechInput(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-5 py-2 rounded-xl shadow-xs"
                >
                  Publish Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
