import React, { useState } from 'react';
import {
  BookOpen,
  MessageSquare,
  ThumbsUp,
  Share2,
  Plus,
  Send,
  X,
  Filter,
  CheckCircle2
} from 'lucide-react';
import { PostFeedItem, StudentProfile, University } from '../types';
import { CollegeTag } from './CollegeTag';

interface FeedProps {
  posts: PostFeedItem[];
  student: StudentProfile;
  selectedUniversity: University;
  onCreatePost: (p: PostFeedItem) => void;
}

export const FeedView: React.FC<FeedProps> = ({
  posts,
  student,
  selectedUniversity,
  onCreatePost
}) => {
  const [filterType, setFilterType] = useState<string>('All');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [commentInput, setCommentInput] = useState<{ [postId: string]: string }>({});

  // New Post State
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newType, setNewType] = useState<'question' | 'project_announcement' | 'study_resource' | 'achievement'>('question');

  const filteredPosts = posts.filter(p => {
    const matchesType = filterType === 'All' || p.type === filterType;
    const matchesUni = p.authorUniversity === selectedUniversity.name || selectedUniversity.id === 'all';
    return matchesType && matchesUni;
  });

  const handleCreatePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;

    const created: PostFeedItem = {
      id: `post_${Date.now()}`,
      type: newType,
      title: newTitle,
      content: newContent,
      tags: [newType, selectedUniversity.shortCode, 'StudentPost'],
      authorId: student.id,
      authorName: student.name,
      authorAvatar: student.avatar,
      authorUniversity: selectedUniversity.name,
      authorDepartment: student.branch,
      authorRole: `${student.year}th Year Student`,
      createdAt: new Date().toISOString().split('T')[0],
      upvotesCount: 1,
      commentsCount: 0,
      comments: []
    };

    onCreatePost(created);
    setShowCreateModal(false);
    setNewTitle('');
    setNewContent('');
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Feed Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-900 dark:text-white tracking-tight">Student Activity Feed</h1>
          <p className="text-xs text-slate-500 dark:text-slate-400">Questions, study discussions, research ideas, and project updates at {selectedUniversity.shortCode}.</p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2 rounded-xl shadow-sm hover:shadow flex items-center space-x-2 transition text-xs cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Post</span>
        </button>
      </div>

      {/* Post Type Filters */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-3 mb-6 scrollbar-none text-xs">
        {['All', 'question', 'achievement', 'project_announcement', 'study_resource'].map(type => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-3.5 py-1.5 rounded-xl font-bold whitespace-nowrap transition cursor-pointer capitalize ${
              filterType === type
                ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
            }`}
          >
            {type.replace('_', ' ')}
          </button>
        ))}
      </div>

      {/* Posts List */}
      <div className="space-y-6">
        {filteredPosts.map(post => (
          <div key={post.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs hover:shadow-sm transition">
            
            {/* Author Header */}
            <div className="flex items-center space-x-3 mb-4">
              <img src={post.authorAvatar} alt={post.authorName} className="w-10 h-10 rounded-full object-cover border border-slate-200 dark:border-slate-700" />
              <div>
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-sm text-slate-900 dark:text-slate-100">{post.authorName}</span>
                  <CollegeTag universityName={post.authorUniversity} />
                  <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-slate-950 dark:text-indigo-400 dark:border-indigo-900 px-2 py-0.5 rounded-full font-semibold">
                    {post.authorRole}
                  </span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400">{post.authorUniversity} • {post.createdAt}</div>
              </div>
            </div>

            {/* Post Title & Body */}
            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{post.title}</h2>
            <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed whitespace-pre-line mb-4">{post.content}</p>

            {/* Post Tags */}
            <div className="flex flex-wrap gap-1.5 mb-4">
              {post.tags.map((t, i) => (
                <span key={i} className="bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 text-[10px] px-2 py-0.5 rounded border border-slate-200/60 dark:border-slate-800">
                  #{t}
                </span>
              ))}
            </div>

            {/* Interactions Bar */}
            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
              <button
                onClick={() => post.upvotesCount++}
                className="flex items-center space-x-1.5 hover:text-indigo-600 dark:hover:text-indigo-400 transition cursor-pointer"
              >
                <ThumbsUp className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
                <span>{post.upvotesCount} Upvotes</span>
              </button>

              <div className="flex items-center space-x-1">
                <MessageSquare className="w-4 h-4 text-slate-400" />
                <span>{post.commentsCount || post.comments?.length || 0} Comments</span>
              </div>
            </div>

            {/* Comment Section */}
            {post.comments && post.comments.length > 0 && (
              <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800/60 space-y-3">
                {post.comments.map(c => (
                  <div key={c.id} className="bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-slate-800/80 p-3 rounded-xl text-xs flex items-start space-x-2">
                    <img src={c.authorAvatar} alt={c.authorName} className="w-6 h-6 rounded-full object-cover shrink-0" />
                    <div>
                      <div className="flex items-center space-x-1">
                        <span className="font-bold text-slate-900 dark:text-slate-200">{c.authorName}</span>
                        <CollegeTag universityName={post.authorUniversity} />
                      </div>
                      <p className="text-slate-600 dark:text-slate-300 mt-0.5">{c.text}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        ))}
      </div>

      {/* CREATE POST MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowCreateModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-1">
              Create Student Post
            </h2>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
              Ask academic questions or share project updates with {selectedUniversity.shortCode} peers.
            </p>

            <form onSubmit={handleCreatePost} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Post Type</label>
                <select
                  value={newType}
                  onChange={(e: any) => setNewType(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none"
                >
                  <option value="question">Academic Question</option>
                  <option value="achievement">Student Achievement</option>
                  <option value="project_announcement">Project Announcement</option>
                  <option value="study_resource">Study Resource Discussion</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. How should I prepare for DSA End-Sem?"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Content</label>
                <textarea
                  rows={4}
                  required
                  placeholder="Detail your question or announcement..."
                  value={newContent}
                  onChange={(e) => setNewContent(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl shadow-xs"
                >
                  Post
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
