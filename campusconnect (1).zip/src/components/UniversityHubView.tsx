import React, { useState } from 'react';
import {
  Building2,
  GraduationCap,
  Users,
  BookOpen,
  Code,
  Globe,
  MapPin,
  Search,
  Filter,
  CheckCircle2,
  ShieldCheck,
  MessageSquare,
  Zap,
  ArrowRight,
  UserPlus,
  FileText,
  ExternalLink,
  ChevronRight,
  Flame,
  Plus
} from 'lucide-react';
import { CollegeTag } from './CollegeTag';
import { University, StudentProfile, AcademicResource, ProjectShowcase } from '../types';

interface UniversityHubViewProps {
  universities: University[];
  selectedUniversity: University;
  onSelectUniversity: (uni: University) => void;
  currentUser: StudentProfile;
  resources: AcademicResource[];
  projects: ProjectShowcase[];
  onOpenChatWithPeer?: (peerId: string) => void;
}

export interface LinkedPeer {
  id: string;
  name: string;
  universityId: string;
  universityShort: string;
  department: string;
  year: number;
  semester: number;
  avatar: string;
  bio: string;
  skills: string[];
  connectionStatus: 'connected' | 'pending' | 'suggested';
  synergyScore: number;
  onlineStatus: 'online' | 'offline' | 'in_lab';
}

export const UniversityHubView: React.FC<UniversityHubViewProps> = ({
  universities,
  selectedUniversity,
  onSelectUniversity,
  currentUser,
  resources,
  projects,
  onOpenChatWithPeer
}) => {
  const [activeTab, setActiveTab] = useState<'cohort' | 'pyqs' | 'projects' | 'departments'>('cohort');
  const [searchQuery, setSearchQuery] = useState('');
  const [departmentFilter, setDepartmentFilter] = useState('all');

  // Sample list of campus peers linked with different universities
  const [linkedPeers, setLinkedPeers] = useState<LinkedPeer[]>([
    {
      id: 'peer_muj_1',
      name: 'Ananya Gupta',
      universityId: 'muj',
      universityShort: 'MUJ',
      department: 'AI & Data Science',
      year: 2,
      semester: 4,
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
      bio: 'Full-Stack Developer crafting responsive Web3 & React platforms. Passionate about UI animations.',
      skills: ['React', 'Next.js', 'Tailwind', 'Node.js'],
      connectionStatus: 'connected',
      synergyScore: 96,
      onlineStatus: 'online'
    },
    {
      id: 'peer_muj_2',
      name: 'Vikramaditya Singh',
      universityId: 'muj',
      universityShort: 'MUJ',
      department: 'Computer Science & Engg',
      year: 3,
      semester: 6,
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200',
      bio: 'Competitive programmer & backend specialist in C++ and Python microservices.',
      skills: ['C++', 'Python', 'FastAPI', 'Redis'],
      connectionStatus: 'connected',
      synergyScore: 92,
      onlineStatus: 'online'
    },
    {
      id: 'peer_iitd_1',
      name: 'Rohan Varma',
      universityId: 'iitd',
      universityShort: 'IITD',
      department: 'Computer Science & Engg',
      year: 3,
      semester: 5,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      bio: 'GenAI researcher & PyTorch enthusiast. Building agentic LLM pipelines.',
      skills: ['PyTorch', 'TypeScript', 'LangChain', 'Docker'],
      connectionStatus: 'connected',
      synergyScore: 98,
      onlineStatus: 'online'
    },
    {
      id: 'peer_iitd_2',
      name: 'Priya Sharma',
      universityId: 'iitd',
      universityShort: 'IITD',
      department: 'Electrical Engg',
      year: 2,
      semester: 4,
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
      bio: 'Circuit design & embedded signal processing. Working on smart health monitors.',
      skills: ['Verilog', 'MATLAB', 'C++', 'Arduino'],
      connectionStatus: 'suggested',
      synergyScore: 88,
      onlineStatus: 'in_lab'
    },
    {
      id: 'peer_bits_1',
      name: 'Karan Patel',
      universityId: 'bits',
      universityShort: 'BITS',
      department: 'Electrical & Electronics',
      year: 3,
      semester: 6,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      bio: 'Embedded Systems engineer & Rust programmer. Working on IoT edge sensors.',
      skills: ['C++', 'Rust', 'STM32', 'Python'],
      connectionStatus: 'connected',
      synergyScore: 94,
      onlineStatus: 'in_lab'
    },
    {
      id: 'peer_iitb_1',
      name: 'Sanya Malhotra',
      universityId: 'iitb',
      universityShort: 'IITB',
      department: 'Computer Science & Engg',
      year: 4,
      semester: 7,
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=200',
      bio: 'Candidate Master on Codeforces. Graph algorithms & dynamic programming tutor.',
      skills: ['C++', 'Algorithms', 'Math', 'Python'],
      connectionStatus: 'suggested',
      synergyScore: 90,
      onlineStatus: 'offline'
    },
    {
      id: 'peer_iisc_1',
      name: 'Devansh Roy',
      universityId: 'iisc',
      universityShort: 'IISc',
      department: 'Computer Science & Automation',
      year: 1,
      semester: 2,
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      bio: 'Quantum computing enthusiast. Building simulator interfaces in WebGL.',
      skills: ['Python', 'Qiskit', 'Three.js', 'Linear Algebra'],
      connectionStatus: 'pending',
      synergyScore: 93,
      onlineStatus: 'online'
    }
  ]);

  // Filter peers for the selected university
  const currentCampusPeers = linkedPeers.filter(p => {
    const pUniId = (p.universityId || '').toLowerCase();
    const pUniShort = (p.universityShort || '').toLowerCase();
    const selUniId = (selectedUniversity?.id || '').toLowerCase();
    const selUniShort = (selectedUniversity?.shortCode || '').toLowerCase();

    const matchesUni = (pUniId && pUniId === selUniId) || (pUniShort && pUniShort === selUniShort);

    const pName = (p.name || '').toLowerCase();
    const pDept = (p.department || '').toLowerCase();
    const sQuery = (searchQuery || '').toLowerCase();

    const matchesSearch = pName.includes(sQuery) ||
      pDept.includes(sQuery) ||
      (p.skills || []).some(s => (s || '').toLowerCase().includes(sQuery));

    const matchesDept = departmentFilter === 'all' || pDept.includes((departmentFilter || '').toLowerCase());

    return matchesUni && matchesSearch && matchesDept;
  });

  // Filter PYQs / resources for selected university
  const campusResources = resources.filter(r => {
    const rUniId = (r.universityId || '').toLowerCase();
    const rUniName = (r.universityName || '').toLowerCase();
    const selUniId = (selectedUniversity?.id || '').toLowerCase();
    const selUniName = (selectedUniversity?.name || '').toLowerCase();
    const selUniShort = (selectedUniversity?.shortCode || '').toLowerCase();

    if (rUniId && selUniId && rUniId === selUniId) return true;
    if (selUniShort && rUniName.includes(selUniShort)) return true;
    if (rUniName && selUniName && (selUniName.includes(rUniName) || rUniName.includes(selUniName))) return true;
    return false;
  });

  // Filter projects for selected university
  const campusProjects = projects.filter(pr => {
    const authorUni = (pr.authorUniversity || '').toLowerCase();
    const selUniName = (selectedUniversity?.name || '').toLowerCase();
    const selUniShort = (selectedUniversity?.shortCode || '').toLowerCase();

    if (!authorUni) return false;
    if (selUniShort && authorUni.includes(selUniShort)) return true;
    if (selUniName && (authorUni.includes(selUniName) || selUniName.includes(authorUni))) return true;
    return false;
  });

  const handleToggleConnection = (peerId: string) => {
    setLinkedPeers(prev =>
      prev.map(p => {
        if (p.id === peerId) {
          if (p.connectionStatus === 'connected') return p;
          return { ...p, connectionStatus: p.connectionStatus === 'pending' ? 'suggested' : 'pending' };
        }
        return p;
      })
    );
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 dark:bg-slate-950 dark:text-slate-100 py-8 px-4 sm:px-6 lg:px-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-8">

        {/* TOP UNIVERSITY SELECTOR STRIP */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-3 flex items-center space-x-2 overflow-x-auto shadow-xs">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-400 shrink-0 px-2 flex items-center space-x-1">
            <Building2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
            <span>Select Campus Realm:</span>
          </span>
          {universities.map(uni => {
            const isSelected = uni.id === selectedUniversity.id;
            return (
              <button
                key={uni.id}
                onClick={() => onSelectUniversity(uni)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition shrink-0 flex items-center space-x-2 cursor-pointer ${
                  isSelected
                    ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-600/30'
                    : 'bg-slate-50 dark:bg-slate-950 text-slate-700 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                }`}
              >
                <img src={uni.logo} alt={uni.name} className="w-4 h-4 rounded-md object-cover" />
                <span>{uni.shortCode}</span>
                {isSelected && <CheckCircle2 className="w-3.5 h-3.5 text-white" />}
              </button>
            );
          })}
        </div>

        {/* HERO CAMPUS BANNER */}
        <div className="relative overflow-hidden rounded-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm">
          {/* Cover Image Header */}
          <div className="h-48 sm:h-64 relative overflow-hidden">
            <img
              src={selectedUniversity.coverImage}
              alt={selectedUniversity.name}
              className="w-full h-full object-cover opacity-80 dark:opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-white via-white/50 to-transparent dark:from-slate-900 dark:via-slate-900/40 dark:to-transparent" />
            
            <a
              href={selectedUniversity.website}
              target="_blank"
              rel="noopener noreferrer"
              className="absolute top-4 right-4 bg-white/90 hover:bg-white text-slate-800 dark:bg-slate-950/80 dark:hover:bg-slate-900 border border-slate-300 dark:border-slate-700 dark:text-slate-200 text-xs font-bold px-3 py-1.5 rounded-xl backdrop-blur-xs flex items-center space-x-1.5 transition shadow-xs"
            >
              <Globe className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Official Website</span>
              <ExternalLink className="w-3 h-3 text-slate-500 dark:text-slate-400" />
            </a>
          </div>

          {/* Campus Details Header Content */}
          <div className="p-6 sm:p-8 relative z-10 -mt-16 sm:-mt-20 flex flex-col md:flex-row md:items-end justify-between gap-6 border-b border-slate-200 dark:border-slate-800/80">
            <div className="flex items-start space-x-4">
              <img
                src={selectedUniversity.logo}
                alt={selectedUniversity.name}
                className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-4 border-white dark:border-slate-900 shadow-md bg-white dark:bg-slate-950 shrink-0"
              />
              <div className="space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-700 px-2.5 py-0.5 rounded-full text-[10px] font-extrabold uppercase tracking-wider">
                    {selectedUniversity.institutionType || 'University'}
                  </span>
                  <span className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center space-x-1">
                    <MapPin className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
                    <span>{selectedUniversity.location}</span>
                  </span>
                </div>

                <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white flex items-center space-x-2">
                  <span>{selectedUniversity.name}</span>
                  <ShieldCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                </h1>

                <p className="text-xs text-slate-600 dark:text-slate-300 font-medium max-w-xl">
                  Official student network for <strong>{selectedUniversity.shortCode}</strong>. Access verified exam PYQs, lab research, student clubs, and your campus peer cohort.
                </p>
              </div>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-3 bg-slate-50 dark:bg-slate-950/80 border border-slate-200 dark:border-slate-800 p-3 rounded-2xl shrink-0 shadow-xs">
              <div className="text-center px-2">
                <div className="text-lg font-black text-indigo-600 dark:text-indigo-400">{selectedUniversity.studentCount.toLocaleString()}</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase">Peers</div>
              </div>
              <div className="text-center border-x border-slate-200 dark:border-slate-800 px-2">
                <div className="text-lg font-black text-emerald-600 dark:text-emerald-400">{selectedUniversity.resourceCount}</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase">PYQs & Notes</div>
              </div>
              <div className="text-center px-2">
                <div className="text-lg font-black text-cyan-600 dark:text-cyan-400">{selectedUniversity.projectCount}</div>
                <div className="text-[10px] text-slate-500 dark:text-slate-400 font-semibold uppercase">Lab Projects</div>
              </div>
            </div>
          </div>

          {/* CAMPUS REALM TABS */}
          <div className="px-6 py-3 bg-white dark:bg-slate-900 flex items-center space-x-2 overflow-x-auto">
            <button
              onClick={() => setActiveTab('cohort')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'cohort'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Users className="w-4 h-4 text-indigo-500 dark:text-indigo-300" />
              <span>Campus Cohort & Friends ({currentCampusPeers.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('pyqs')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'pyqs'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <BookOpen className="w-4 h-4 text-emerald-500 dark:text-emerald-300" />
              <span>Academic PYQs & Notes ({campusResources.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('projects')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'projects'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Code className="w-4 h-4 text-cyan-500 dark:text-cyan-300" />
              <span>Campus Projects ({campusProjects.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('departments')}
              className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                activeTab === 'departments'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-purple-500 dark:text-purple-300" />
              <span>Departments ({selectedUniversity.departments.length})</span>
            </button>
          </div>
        </div>

        {/* TAB 1: CAMPUS COHORT & FRIENDS LINKED */}
        {activeTab === 'cohort' && (
          <div className="space-y-6">
            
            {/* Search and Department Filter */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder={`Search friends at ${selectedUniversity.shortCode}...`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition"
                />
              </div>

              <div className="flex items-center space-x-2 overflow-x-auto w-full md:w-auto">
                <span className="text-xs text-slate-500 dark:text-slate-400 font-semibold shrink-0">Filter Branch:</span>
                <button
                  onClick={() => setDepartmentFilter('all')}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold cursor-pointer transition ${
                    departmentFilter === 'all'
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  All Branches
                </button>
                {selectedUniversity.departments.map(dept => (
                  <button
                    key={dept}
                    onClick={() => setDepartmentFilter(dept)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 cursor-pointer transition ${
                      departmentFilter === dept
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {dept.split(' ')[0]}
                  </button>
                ))}
              </div>
            </div>

            {/* Peer Cards Grid */}
            {currentCampusPeers.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center text-slate-500 dark:text-slate-400 text-xs space-y-2 shadow-xs">
                <Users className="w-10 h-10 text-slate-400 dark:text-slate-600 mx-auto mb-2" />
                <div className="font-bold text-slate-800 dark:text-slate-200 text-sm">No connected peers matched your filter</div>
                <div>Try selecting "All Branches" or search for a different student name at {selectedUniversity.name}.</div>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentCampusPeers.map(peer => (
                  <div
                    key={peer.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 hover:border-indigo-400 dark:hover:border-indigo-500/50 shadow-xs hover:shadow-md transition duration-300 flex flex-col justify-between"
                  >
                    <div>
                      {/* Top Synergy Header */}
                      <div className="flex items-center justify-between mb-4">
                        <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:border-indigo-700/80 rounded-full px-2.5 py-0.5 text-[10px] font-extrabold dark:text-indigo-300 flex items-center space-x-1">
                          <Zap className="w-3 h-3 text-amber-500 dark:text-amber-400" />
                          <span>{peer.synergyScore}% Skill Match</span>
                        </span>

                        <span className="text-[10px] font-mono text-slate-500 dark:text-slate-400 flex items-center space-x-1">
                          <span className={`w-2 h-2 rounded-full ${
                            peer.onlineStatus === 'online' ? 'bg-emerald-500' : peer.onlineStatus === 'in_lab' ? 'bg-amber-500' : 'bg-slate-400'
                          }`} />
                          <span className="uppercase">{peer.onlineStatus}</span>
                        </span>
                      </div>

                      {/* Profile info */}
                      <div className="flex items-start space-x-3 mb-3">
                        <img
                          src={peer.avatar}
                          alt={peer.name}
                          className="w-12 h-12 rounded-2xl object-cover border-2 border-indigo-400/40 dark:border-indigo-500/40 shrink-0"
                        />
                        <div className="min-w-0 flex-1">
                          <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm truncate flex items-center space-x-1.5">
                            <span>{peer.name}</span>
                            <CollegeTag tag={peer.universityShort} universityName={peer.universityName} />
                            <ShieldCheck className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                          </h3>
                          <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                            {peer.department}
                          </div>
                          <div className="text-[10px] text-indigo-600 dark:text-indigo-400 font-mono">
                            Year {peer.year} (Sem {peer.semester})
                          </div>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed mb-4">
                        "{peer.bio}"
                      </p>

                      <div className="flex flex-wrap gap-1.5 mb-4">
                        {peer.skills.map((s, idx) => (
                          <span key={idx} className="bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-950 dark:text-slate-300 dark:border-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded-lg">
                            {s}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Connection Button Actions */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center space-x-2">
                      {peer.connectionStatus === 'connected' ? (
                        <>
                          <button
                            disabled
                            className="flex-1 bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-700 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1 cursor-default"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                            <span>Campus Friend</span>
                          </button>
                          {onOpenChatWithPeer && (
                            <button
                              onClick={() => onOpenChatWithPeer(peer.id)}
                              className="bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1 cursor-pointer shadow-xs"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Chat</span>
                            </button>
                          )}
                        </>
                      ) : peer.connectionStatus === 'pending' ? (
                        <button
                          onClick={() => handleToggleConnection(peer.id)}
                          className="w-full bg-amber-50 text-amber-700 border border-amber-200 dark:bg-slate-800 dark:text-amber-300 dark:border-amber-500/40 py-2 rounded-xl text-xs font-bold transition cursor-pointer"
                        >
                          Request Pending... (Tap to Cancel)
                        </button>
                      ) : (
                        <button
                          onClick={() => handleToggleConnection(peer.id)}
                          className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-2 rounded-xl text-xs font-extrabold transition shadow-sm hover:shadow flex items-center justify-center space-x-1.5 cursor-pointer"
                        >
                          <UserPlus className="w-3.5 h-3.5" />
                          <span>Link Campus Friend</span>
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}

          </div>
        )}

        {/* TAB 2: ACADEMIC PYQS & NOTES */}
        {activeTab === 'pyqs' && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center space-x-2">
              <BookOpen className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>Verified PYQs & Exam Solutions for {selectedUniversity.name}</span>
            </h3>

            {campusResources.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center text-slate-500 dark:text-slate-400 text-xs shadow-xs">
                No custom PYQ uploads found for {selectedUniversity.shortCode} yet.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {campusResources.map(res => (
                  <div key={res.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 hover:border-slate-300 dark:hover:border-slate-700 shadow-xs hover:shadow-sm transition space-y-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-700 px-2 py-0.5 rounded-full text-[10px] font-bold">
                          {res.subject} ({res.academicYear})
                        </span>
                        <h4 className="font-bold text-slate-900 dark:text-slate-100 text-sm mt-1.5">{res.title}</h4>
                      </div>
                      <span className="text-[10px] font-mono bg-slate-50 dark:bg-slate-950 px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-800 text-slate-500 dark:text-slate-400">
                        Semester {res.semester}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{res.description}</p>

                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                      <span className="text-slate-500 dark:text-slate-400 font-mono text-[11px]">
                        Uploaded by {res.uploadedBy}
                      </span>
                      <button
                        onClick={() => alert(`Downloading ${res.title} PDF`)}
                        className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-3 py-1.5 rounded-xl text-xs transition flex items-center space-x-1 cursor-pointer shadow-xs"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>Download PDF</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 3: CAMPUS PROJECTS */}
        {activeTab === 'projects' && (
          <div className="space-y-4">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center space-x-2">
              <Code className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
              <span>Lab Projects & Research at {selectedUniversity.shortCode}</span>
            </h3>

            {campusProjects.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-10 text-center text-slate-500 dark:text-slate-400 text-xs shadow-xs">
                No active public projects listed for {selectedUniversity.name} currently.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {campusProjects.map(proj => (
                  <div key={proj.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 space-y-3 shadow-xs">
                    <h4 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm">{proj.title}</h4>
                    <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{proj.description}</p>
                    <div className="flex flex-wrap gap-1.5">
                      {proj.techStack.map((tech, idx) => (
                        <span key={idx} className="bg-slate-100 text-slate-700 border border-slate-200 dark:bg-slate-950 dark:text-indigo-300 dark:border-slate-800 text-[10px] px-2 py-0.5 rounded-lg">
                          {tech}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* TAB 4: DEPARTMENTS */}
        {activeTab === 'departments' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 space-y-4 shadow-xs">
            <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center space-x-2">
              <GraduationCap className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>Academic Departments & Faculties at {selectedUniversity.name}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {selectedUniversity.departments.map((dept, idx) => (
                <div key={idx} className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:border-indigo-800 flex items-center justify-center dark:text-indigo-300 font-bold text-xs shrink-0">
                    #{idx + 1}
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-800 dark:text-slate-200 text-xs">{dept}</h4>
                    <span className="text-[10px] text-slate-500 dark:text-slate-400">Undergraduate & Postgraduate Labs</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
