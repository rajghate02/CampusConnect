import React, { useState, useEffect } from 'react';
import { BarChart2, BookOpen, X, CheckCircle2, ArrowRight } from 'lucide-react';
import { University } from '../types';

interface AIResourceAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedUniversity: University;
  initialSubject?: string;
}

export const AIResourceAssistantModal: React.FC<AIResourceAssistantModalProps> = ({
  isOpen,
  onClose,
  selectedUniversity,
  initialSubject = 'Data Structures'
}) => {
  const [subject, setSubject] = useState(initialSubject);
  const [query, setQuery] = useState('Find me important topics for Data Structures based on previous papers');
  const [isLoading, setIsLoading] = useState(false);
  const [pythonAnalysis, setPythonAnalysis] = useState<any>(null);
  const [aiAnswer, setAiAnswer] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      handleRunAnalysis();
    }
  }, [isOpen, initialSubject]);

  const handleRunAnalysis = async () => {
    setIsLoading(true);
    setPythonAnalysis(null);
    setAiAnswer('');

    try {
      // 1. Execute Resource & Topic Frequency Matrix
      const pyRes = await fetch('/api/python/analyze-resources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, query })
      });
      const pyData = await pyRes.json();
      if (pyData.status === 'success') {
        setPythonAnalysis(pyData.data);
      }

      // 2. Execute Academic Analysis Endpoint
      const gemRes = await fetch('/api/gemini/academic-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Analyze past year exam papers for subject '${subject}' at ${selectedUniversity.name}. Identify top 3 high-yield topics, past question trends, and a 3-step preparation order.`,
          subject,
          university: selectedUniversity.name
        })
      });
      const gemData = await gemRes.json();
      setAiAnswer(gemData.answer || 'Analysis complete based on CampusConnect repository.');
    } catch (err) {
      setAiAnswer('Analysis complete based on CampusConnect PYQ bank.');
    } finally {
      setIsLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-2xl w-full p-6 sm:p-8 text-slate-900 dark:text-slate-100 relative shadow-2xl overflow-hidden max-h-[90vh] overflow-y-auto">
        
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-2 rounded-xl bg-slate-100 dark:bg-slate-800 cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center space-x-2 text-xs font-bold text-amber-600 dark:text-amber-400 mb-2">
          <BarChart2 className="w-4 h-4 text-amber-600 dark:text-amber-400" />
          <span>Academic PYQ & Subject Topic Frequency Matrix</span>
        </div>

        <h2 className="text-2xl font-extrabold text-slate-900 dark:text-white mb-1 tracking-tight">
          Exam Topic & PYQ Frequency Analyzer
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
          Grounded in {selectedUniversity.shortCode} previous year question papers & handcrafted study notes.
        </p>

        {/* Input Subject Selector */}
        <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 mb-6 space-y-3">
          <div>
            <label className="block text-xs font-bold text-slate-700 dark:text-slate-300 mb-1">Target Subject / Course</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-xs text-slate-900 dark:text-white focus:outline-none focus:border-amber-500"
            />
          </div>

          <button
            onClick={handleRunAnalysis}
            disabled={isLoading}
            className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold py-2.5 rounded-xl text-xs transition shadow-sm hover:shadow cursor-pointer"
          >
            {isLoading ? "Analyzing Subject PYQs & Frequency..." : "Re-Analyze Subject PYQs"}
          </button>
        </div>

        {/* Loading State */}
        {isLoading ? (
          <div className="py-12 text-center">
            <BarChart2 className="w-12 h-12 text-amber-500 mx-auto animate-pulse mb-3" />
            <div className="font-bold text-sm text-slate-800 dark:text-slate-200">Parsing Solved End-Sem & Mid-Sem Papers...</div>
            <div className="text-xs text-slate-500 dark:text-slate-400 mt-1">Calculating topic frequency matrix & syllabus distribution...</div>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Topic Matrix Result */}
            {pythonAnalysis && (
              <div>
                <h3 className="text-xs font-extrabold text-amber-600 dark:text-amber-400 uppercase tracking-wider mb-3">
                  1. High-Yield Subject Topic Distribution
                </h3>
                <div className="space-y-2">
                  {pythonAnalysis.key_topics?.map((top: any, idx: number) => (
                    <div key={idx} className="bg-slate-50 dark:bg-slate-950 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-slate-900 dark:text-slate-100">{top.topic}</div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5">{top.freq}</div>
                      </div>
                      <span className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full ${
                        top.priority === 'High' ? 'bg-red-50 text-red-700 border border-red-200 dark:bg-red-950 dark:text-red-300 dark:border-red-800' : 'bg-amber-50 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      }`}>
                        {top.priority} Priority ({top.weight}% Yield)
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Detailed Advice */}
            {aiAnswer && (
              <div>
                <h3 className="text-xs font-extrabold text-indigo-600 dark:text-indigo-400 uppercase tracking-wider mb-2">
                  2. Recommended Academic Preparation Strategy
                </h3>
                <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-800 text-xs text-slate-800 dark:text-slate-200 leading-relaxed whitespace-pre-line">
                  {aiAnswer}
                </div>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
};
