import React, { useState, useMemo } from 'react';
import {
  BookOpen,
  Download,
  Filter,
  Search,
  Plus,
  BarChart2,
  CheckCircle2,
  FileText,
  Eye,
  X,
  Upload,
  Globe,
  GraduationCap,
  Layers,
  Check,
  RotateCcw,
  Building2,
  Bookmark,
  Calendar,
  Sparkles
} from 'lucide-react';
import { AcademicResource, University } from '../types';
import { CollegeTag } from './CollegeTag';

interface ResourceLibraryProps {
  resources: AcademicResource[];
  selectedUniversity: University;
  universities?: University[];
  onSelectUniversity?: (uni: University) => void;
  onUploadResource: (newRes: AcademicResource) => void;
  onOpenAIResourceAssistant: (subject?: string) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const ResourceLibrary: React.FC<ResourceLibraryProps> = ({
  resources,
  selectedUniversity,
  universities = [],
  onSelectUniversity,
  onUploadResource,
  onOpenAIResourceAssistant,
  searchQuery,
  setSearchQuery
}) => {
  // Cascading Filter States
  const [selectedInstType, setSelectedInstType] = useState<string>('All'); // 'All' | 'University' | 'College'
  const [selectedRegion, setSelectedRegion] = useState<string>('All'); // 'All' | 'India' | 'USA' | 'Europe'
  const [selectedUniId, setSelectedUniId] = useState<string>('All');
  const [selectedBranch, setSelectedBranch] = useState<string>('All');
  const [selectedSem, setSelectedSem] = useState<string>('All');
  const [selectedCourse, setSelectedCourse] = useState<string>('All');
  const [selectedSubject, setSelectedSubject] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All'); // 'PYQ' | 'Notes' | 'Lab Manual' | 'Assignment'

  const [previewResource, setPreviewResource] = useState<AcademicResource | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Upload Form State
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<'PYQ' | 'Notes' | 'Lab Manual' | 'Assignment'>('PYQ');
  const [newCourseCode, setNewCourseCode] = useState('CS2101');
  const [newCourseName, setNewCourseName] = useState('Data Structures & Algorithms');
  const [newSubject, setNewSubject] = useState('Trees & Graph Traversals');
  const [newTopic, setNewTopic] = useState('Binary Search Trees & Heaps');
  const [newSem, setNewSem] = useState(4);
  const [newDesc, setNewDesc] = useState('');

  // 1. Filter Institutions by Type (University vs College) & Region
  const filteredUniversities = useMemo(() => {
    return universities.filter(u => {
      const matchesType = selectedInstType === 'All' || 
        (selectedInstType === 'University' && (u.institutionType === 'University' || !u.institutionType)) ||
        (selectedInstType === 'College' && u.institutionType === 'College');
      
      const matchesRegion = selectedRegion === 'All' || u.region === selectedRegion;
      
      return matchesType && matchesRegion;
    });
  }, [universities, selectedInstType, selectedRegion]);

  // Currently selected Institution object
  const activeInstitutionObj = useMemo(() => {
    if (selectedUniId === 'All') return null;
    return universities.find(u => u.id === selectedUniId) || selectedUniversity;
  }, [universities, selectedUniId, selectedUniversity]);

  // 2. Dynamic Available Branches for Selected Institution
  const availableBranches = useMemo(() => {
    if (activeInstitutionObj) {
      return activeInstitutionObj.departments;
    }
    const deptSet = new Set<string>();
    filteredUniversities.forEach(u => u.departments.forEach(d => deptSet.add(d)));
    return Array.from(deptSet);
  }, [activeInstitutionObj, filteredUniversities]);

  // 3. Dynamic Available Courses for Selected Institution, Branch & Semester
  const availableCourses = useMemo(() => {
    const courseSet = new Set<string>();
    resources.forEach(res => {
      const matchesUni = selectedUniId === 'All' || res.universityId === selectedUniId;
      const dept = (res.department || '').toLowerCase();
      const matchesBranch = selectedBranch === 'All' || dept.includes((selectedBranch || '').toLowerCase());
      const matchesSem = selectedSem === 'All' || (res.semester && res.semester.toString() === selectedSem);
      
      if (matchesUni && matchesBranch && matchesSem) {
        if (res.courseName) courseSet.add(res.courseName);
      }
    });

    if (courseSet.size === 0) {
      return [
        'Data Structures & Algorithms',
        'Database Management Systems',
        'Operating Systems',
        'Discrete Mathematical Structures',
        'Machine Learning',
        'Computer Systems & Assembly',
        'Engineering Physics'
      ];
    }
    return Array.from(courseSet);
  }, [resources, selectedUniId, selectedBranch, selectedSem]);

  // 4. Dynamic Available Subjects / Topics for Selected Course
  const availableSubjects = useMemo(() => {
    const subjectSet = new Set<string>();
    resources.forEach(res => {
      const matchesUni = selectedUniId === 'All' || res.universityId === selectedUniId;
      const dept = (res.department || '').toLowerCase();
      const courseName = (res.courseName || '').toLowerCase();
      const selBranch = (selectedBranch || '').toLowerCase();
      const selCourse = (selectedCourse || '').toLowerCase();

      const matchesBranch = selectedBranch === 'All' || dept.includes(selBranch);
      const matchesSem = selectedSem === 'All' || (res.semester && res.semester.toString() === selectedSem);
      const matchesCourse = selectedCourse === 'All' || courseName === selCourse;

      if (matchesUni && matchesBranch && matchesSem && matchesCourse) {
        if (res.subject) subjectSet.add(res.subject);
        if (res.topic) subjectSet.add(res.topic);
      }
    });

    if (subjectSet.size === 0) {
      return [
        'Trees & Graph Traversals',
        'Normalization & BCNF',
        'Process Scheduling & Memory Management',
        'Graph Theory & Combinatorics',
        'Dynamic Programming',
        'Virtual Memory & x86 Assembly',
        'Semiconductors & Optics'
      ];
    }

    return Array.from(subjectSet);
  }, [resources, selectedUniId, selectedBranch, selectedSem, selectedCourse]);

  // Master Filtered Resources List
  const filteredResources = useMemo(() => {
    return resources.filter(res => {
      // Inst Type Filter
      const targetUniObj = universities.find(u => u.id === res.universityId);
      const matchesInstType = selectedInstType === 'All' ||
        (selectedInstType === 'University' && (!targetUniObj || targetUniObj.institutionType === 'University' || !targetUniObj.institutionType)) ||
        (selectedInstType === 'College' && targetUniObj && targetUniObj.institutionType === 'College');

      // Region Filter
      const matchesRegion = selectedRegion === 'All' || (targetUniObj && targetUniObj.region === selectedRegion);

      // University / College Filter
      const matchesUni = selectedUniId === 'All' || res.universityId === selectedUniId;

      const dept = (res.department || '').toLowerCase();
      const courseName = (res.courseName || '').toLowerCase();
      const courseCode = (res.courseCode || '').toLowerCase();
      const title = (res.title || '').toLowerCase();
      const subject = (res.subject || '').toLowerCase();
      const topic = (res.topic || '').toLowerCase();
      const tags = res.tags || [];

      const selBranch = (selectedBranch || '').toLowerCase();
      const selCourse = (selectedCourse || '').toLowerCase();
      const selSubject = (selectedSubject || '').toLowerCase();
      const sQuery = (searchQuery || '').toLowerCase();

      // Branch Filter
      const matchesBranch = selectedBranch === 'All' || dept.includes(selBranch);

      // Semester Filter
      const matchesSem = selectedSem === 'All' || (res.semester && res.semester.toString() === selectedSem);

      // Course Filter
      const matchesCourse = selectedCourse === 'All' || 
        courseName === selCourse ||
        courseCode === selCourse;

      // Subject / Topic Filter
      const matchesSubject = selectedSubject === 'All' ||
        (res.subject && subject === selSubject) ||
        (res.topic && topic === selSubject) ||
        courseName.includes(selSubject);

      // Resource Type Filter (PYQ, Notes, etc.)
      const matchesFormatType = selectedType === 'All' || res.resourceType === selectedType;

      // Search Query
      const matchesSearch = !sQuery ||
        title.includes(sQuery) ||
        courseName.includes(sQuery) ||
        courseCode.includes(sQuery) ||
        (res.topic && topic.includes(sQuery)) ||
        (res.subject && subject.includes(sQuery)) ||
        tags.some(t => (t || '').toLowerCase().includes(sQuery));

      return matchesInstType && matchesRegion && matchesUni && matchesBranch && matchesSem && matchesCourse && matchesSubject && matchesFormatType && matchesSearch;
    });
  }, [resources, universities, selectedInstType, selectedRegion, selectedUniId, selectedBranch, selectedSem, selectedCourse, selectedSubject, selectedType, searchQuery]);

  // Reset all filters
  const handleResetFilters = () => {
    setSelectedInstType('All');
    setSelectedRegion('All');
    setSelectedUniId('All');
    setSelectedBranch('All');
    setSelectedSem('All');
    setSelectedCourse('All');
    setSelectedSubject('All');
    setSelectedType('All');
    setSearchQuery('');
  };

  const handleCreateResource = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    const currentUniObj = activeInstitutionObj || selectedUniversity;

    const created: AcademicResource = {
      id: `res_${Date.now()}`,
      title: newTitle,
      description: newDesc || 'Verified academic resource uploaded by student.',
      resourceType: newType,
      universityId: currentUniObj.id,
      universityName: currentUniObj.name,
      department: selectedBranch !== 'All' ? selectedBranch : currentUniObj.departments[0] || 'Computer Science & Engineering',
      courseCode: newCourseCode,
      courseName: newCourseName,
      subject: newSubject,
      topic: newTopic,
      semester: Number(newSem),
      academicYear: '2025-2026',
      fileUrl: '#',
      fileSize: '3.8 MB',
      fileFormat: 'PDF',
      uploaderId: 'user_101',
      uploaderName: 'Aarav Sharma',
      uploaderAvatar: selectedUniversity.logo || 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6',
      uploadDate: new Date().toISOString().split('T')[0],
      downloadsCount: 1,
      rating: 5.0,
      ratingsCount: 1,
      tags: [newType, currentUniObj.shortCode, newCourseCode, newSubject],
      verifiedByFaculty: false
    };

    onUploadResource(created);
    setShowUploadModal(false);
    setNewTitle('');
    setNewDesc('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800/80 font-bold px-2.5 py-0.5 rounded text-xs flex items-center space-x-1">
              <Globe className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>PYQs & Notes Library</span>
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400 font-medium flex items-center space-x-1">
              <span>Classified by University & College • Branch • Semester • Course • Subject</span>
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 flex items-center space-x-2 tracking-tight">
            <span>Academic PYQs, Notes & Study Material</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-3xl">
            Effortlessly search past year papers, lab manuals, and faculty-verified notes by selecting your University or College, Branch, Semester, Course, and Subject.
          </p>
        </div>

        <div className="flex items-center space-x-3 shrink-0">
          <button
            onClick={() => onOpenAIResourceAssistant(selectedCourse !== 'All' ? selectedCourse : selectedSubject !== 'All' ? selectedSubject : undefined)}
            className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-extrabold px-4 py-2.5 rounded-xl shadow-sm hover:shadow flex items-center space-x-2 transition cursor-pointer text-xs"
          >
            <BarChart2 className="w-4 h-4 text-slate-950" />
            <span>AI Exam Topic Frequency Analyzer</span>
          </button>

          <button
            onClick={() => setShowUploadModal(true)}
            className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2.5 rounded-xl shadow-sm hover:shadow flex items-center space-x-2 transition cursor-pointer text-xs"
          >
            <Plus className="w-4 h-4" />
            <span>Upload PYQ / Notes</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* STRUCTURED ACADEMIC NAVIGATOR & FILTER PANEL */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-5 sm:p-6 mb-8 shadow-xs relative overflow-hidden">
        
        {/* Glow accent */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-600/5 dark:bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Panel Title & Clear Action */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-5 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center space-x-3">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 dark:bg-indigo-600/20 border border-indigo-200 dark:border-indigo-500/40 flex items-center justify-center text-indigo-600 dark:text-indigo-400">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-sm font-extrabold text-slate-900 dark:text-white tracking-wide uppercase flex items-center space-x-2">
                <span>PYQ & Notes Resource Finder</span>
                <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800 px-2 py-0.5 rounded-md font-bold">
                  Hierarchical Filter
                </span>
              </h2>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5">
                Filter by Institution Type → University / College → Branch → Semester → Course → Subject / Topic
              </p>
            </div>
          </div>

          {(selectedInstType !== 'All' || selectedRegion !== 'All' || selectedUniId !== 'All' || selectedBranch !== 'All' || selectedSem !== 'All' || selectedCourse !== 'All' || selectedSubject !== 'All' || selectedType !== 'All') && (
            <button
              onClick={handleResetFilters}
              className="self-start sm:self-auto flex items-center space-x-1.5 bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-700 dark:text-indigo-300 font-semibold px-3 py-1.5 rounded-xl text-xs transition border border-slate-200 dark:border-slate-700 cursor-pointer shadow-xs"
            >
              <RotateCcw className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400" />
              <span>Reset Selection</span>
            </button>
          )}
        </div>

        {/* ========================================================= */}
        {/* TOP LEVEL CLASSIFICATION: INSTITUTION TYPE & REGION */}
        {/* ========================================================= */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-5 p-3.5 bg-slate-50 dark:bg-slate-950/80 rounded-2xl border border-slate-200 dark:border-slate-800/80">
          
          {/* Classification 1: Institution Type (University vs College) */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
              <Building2 className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <span>Institution Type:</span>
            </span>

            <div className="flex items-center gap-1.5">
              {[
                { id: 'All', label: 'All Institutions' },
                { id: 'University', label: '🏛️ Universities' },
                { id: 'College', label: '🏫 Colleges' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedInstType(item.id);
                    setSelectedUniId('All');
                  }}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                    selectedInstType === item.id
                      ? 'bg-indigo-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {/* Classification 2: Region Filter */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t sm:border-t-0 sm:border-l border-slate-200 dark:border-slate-800/80 pt-2 sm:pt-0 sm:pl-4">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center space-x-1.5">
              <Globe className="w-4 h-4 text-purple-600 dark:text-purple-400" />
              <span>Region:</span>
            </span>

            <div className="flex items-center gap-1.5 overflow-x-auto">
              {[
                { id: 'All', label: 'Global' },
                { id: 'India', label: '🇮🇳 India' },
                { id: 'USA', label: '🇺🇸 USA' },
                { id: 'Europe', label: '🇪🇺 Europe' }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setSelectedRegion(item.id);
                    setSelectedUniId('All');
                  }}
                  className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                    selectedRegion === item.id
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* ========================================================= */}
        {/* 5-STEP CASCADING DRILL DOWN SELECTION GRID */}
        {/* ========================================================= */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3.5">

          {/* STEP 1: UNIVERSITY / COLLEGE */}
          <div className="bg-slate-50/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 hover:border-indigo-400 dark:hover:border-indigo-500/50 transition shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-indigo-600 dark:text-indigo-400 flex items-center space-x-1">
                <GraduationCap className="w-3.5 h-3.5" />
                <span>1. Institution</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {filteredUniversities.length} Available
              </span>
            </div>

            <select
              value={selectedUniId}
              onChange={(e) => {
                const val = e.target.value;
                setSelectedUniId(val);
                setSelectedBranch('All');
                setSelectedCourse('All');
                setSelectedSubject('All');

                if (val !== 'All' && onSelectUniversity) {
                  const target = universities.find(u => u.id === val);
                  if (target) onSelectUniversity(target);
                }
              }}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:border-indigo-500 transition cursor-pointer"
            >
              <option value="All">
                🌐 All {selectedInstType === 'University' ? 'Universities' : selectedInstType === 'College' ? 'Colleges' : 'Institutions'}
              </option>
              {filteredUniversities.map(u => (
                <option key={u.id} value={u.id}>
                  {u.institutionType === 'College' ? '🏫' : '🏛️'} {u.name} ({u.shortCode})
                </option>
              ))}
            </select>

            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {activeInstitutionObj ? (
                <span className="text-indigo-600 dark:text-indigo-300 font-bold flex items-center space-x-1">
                  <Check className="w-3 h-3 text-emerald-500 dark:text-emerald-400 inline" />
                  <span className="truncate">{activeInstitutionObj.institutionType === 'College' ? 'College' : 'University'}: {activeInstitutionObj.shortCode}</span>
                </span>
              ) : (
                <span>All Institutions</span>
              )}
            </div>
          </div>

          {/* STEP 2: BRANCH / DEPARTMENT */}
          <div className="bg-slate-50/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 hover:border-purple-400 dark:hover:border-purple-500/50 transition shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-purple-600 dark:text-purple-400 flex items-center space-x-1">
                <BookOpen className="w-3.5 h-3.5" />
                <span>2. Branch</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {availableBranches.length} Depts
              </span>
            </div>

            <select
              value={selectedBranch}
              onChange={(e) => {
                setSelectedBranch(e.target.value);
                setSelectedCourse('All');
                setSelectedSubject('All');
              }}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:border-purple-500 transition cursor-pointer"
            >
              <option value="All">📚 All Branches</option>
              {availableBranches.map((dept, idx) => (
                <option key={idx} value={dept}>
                  {dept}
                </option>
              ))}
            </select>

            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {selectedBranch !== 'All' ? (
                <span className="text-purple-600 dark:text-purple-300 font-bold truncate">{selectedBranch}</span>
              ) : (
                <span>All Branches</span>
              )}
            </div>
          </div>

          {/* STEP 3: SEMESTER */}
          <div className="bg-slate-50/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 hover:border-amber-400 dark:hover:border-amber-500/50 transition shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-amber-600 dark:text-amber-400 flex items-center space-x-1">
                <Calendar className="w-3.5 h-3.5" />
                <span>3. Semester</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">Sem 1 - 8</span>
            </div>

            <select
              value={selectedSem}
              onChange={(e) => {
                setSelectedSem(e.target.value);
                setSelectedCourse('All');
                setSelectedSubject('All');
              }}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:border-amber-500 transition cursor-pointer"
            >
              <option value="All">🗓️ All Semesters</option>
              {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                <option key={s} value={s.toString()}>
                  Semester {s} {s <= 2 ? '(First Year)' : s <= 4 ? '(Second Year)' : s <= 6 ? '(Third Year)' : '(Final Year)'}
                </option>
              ))}
            </select>

            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {selectedSem !== 'All' ? (
                <span className="text-amber-600 dark:text-amber-300 font-bold">Semester {selectedSem}</span>
              ) : (
                <span>All Semesters</span>
              )}
            </div>
          </div>

          {/* STEP 4: COURSE */}
          <div className="bg-slate-50/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 hover:border-emerald-400 dark:hover:border-emerald-500/50 transition shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-600 dark:text-emerald-400 flex items-center space-x-1">
                <Bookmark className="w-3.5 h-3.5" />
                <span>4. Course</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {availableCourses.length} Courses
              </span>
            </div>

            <select
              value={selectedCourse}
              onChange={(e) => {
                setSelectedCourse(e.target.value);
                setSelectedSubject('All');
              }}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:border-emerald-500 transition cursor-pointer"
            >
              <option value="All">📖 All Courses</option>
              {availableCourses.map((crs, idx) => (
                <option key={idx} value={crs}>
                  {crs}
                </option>
              ))}
            </select>

            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {selectedCourse !== 'All' ? (
                <span className="text-emerald-600 dark:text-emerald-300 font-bold truncate">{selectedCourse}</span>
              ) : (
                <span>All Courses</span>
              )}
            </div>
          </div>

          {/* STEP 5: SUBJECT / TOPIC */}
          <div className="bg-slate-50/70 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-2xl p-3.5 hover:border-cyan-400 dark:hover:border-cyan-500/50 transition shadow-xs">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-cyan-600 dark:text-cyan-400 flex items-center space-x-1">
                <Sparkles className="w-3.5 h-3.5" />
                <span>5. Subject / Topic</span>
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                {availableSubjects.length} Topics
              </span>
            </div>

            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-800 rounded-xl px-2.5 py-2 text-xs text-slate-800 dark:text-slate-100 font-medium focus:outline-none focus:border-cyan-500 transition cursor-pointer"
            >
              <option value="All">🎯 All Subjects / Topics</option>
              {availableSubjects.map((sub, idx) => (
                <option key={idx} value={sub}>
                  {sub}
                </option>
              ))}
            </select>

            <div className="mt-2 text-[10px] text-slate-500 truncate">
              {selectedSubject !== 'All' ? (
                <span className="text-cyan-600 dark:text-cyan-300 font-bold truncate">{selectedSubject}</span>
              ) : (
                <span>All Subjects</span>
              )}
            </div>
          </div>

        </div>

        {/* QUICK SEMESTER PILL STRIP FOR USER-FRIENDLY ACCESSIBILITY */}
        <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-xs">
          <div className="flex items-center space-x-2 overflow-x-auto pb-1 max-w-full">
            <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 shrink-0">Quick Semester:</span>
            <button
              onClick={() => setSelectedSem('All')}
              className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                selectedSem === 'All'
                  ? 'bg-amber-500 text-slate-950 font-extrabold'
                  : 'bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
              }`}
            >
              All Semesters
            </button>
            {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
              <button
                key={s}
                onClick={() => {
                  setSelectedSem(s.toString());
                  setSelectedCourse('All');
                  setSelectedSubject('All');
                }}
                className={`px-2.5 py-1 rounded-lg text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedSem === s.toString()
                    ? 'bg-amber-500 text-slate-950 shadow-xs'
                    : 'bg-white dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200 border border-slate-200 dark:border-slate-800'
                }`}
              >
                Sem {s}
              </button>
            ))}
          </div>

          <div className="flex items-center space-x-2 text-[11px] font-bold text-slate-500 dark:text-slate-400">
            <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-400 dark:border-emerald-800/80 px-3 py-1 rounded-lg font-extrabold">
              {filteredResources.length} Items Found
            </span>
          </div>
        </div>

        {/* ACTIVE PATH BREADCRUMB TRAIL */}
        <div className="mt-3 pt-3 border-t border-slate-200 dark:border-slate-800/60 flex flex-wrap items-center gap-1.5 text-xs text-slate-600 dark:text-slate-300">
          <span className="text-slate-500 font-medium text-[11px]">Selected Filter Trail:</span>
          
          <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {selectedInstType === 'University' ? '🏛️ Universities' : selectedInstType === 'College' ? '🏫 Colleges' : 'All Institutions'}
          </span>
          <span className="text-slate-400 dark:text-slate-600">→</span>

          <span className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {activeInstitutionObj ? activeInstitutionObj.name : 'All Institutions'}
          </span>
          <span className="text-slate-400 dark:text-slate-600">→</span>

          <span className="bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {selectedBranch}
          </span>
          <span className="text-slate-400 dark:text-slate-600">→</span>

          <span className="bg-amber-50 text-amber-700 border border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {selectedSem !== 'All' ? `Semester ${selectedSem}` : 'All Semesters'}
          </span>
          <span className="text-slate-400 dark:text-slate-600">→</span>

          <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {selectedCourse}
          </span>
          <span className="text-slate-400 dark:text-slate-600">→</span>

          <span className="bg-cyan-50 text-cyan-700 border border-cyan-200 dark:bg-cyan-950 dark:text-cyan-300 dark:border-cyan-800/60 px-2 py-0.5 rounded text-[11px] font-bold">
            {selectedSubject}
          </span>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* SECONDARY CONTROLS & RESOURCE FORMAT PILLS */}
      {/* ========================================================================= */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 mb-8 shadow-xs">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          
          {/* Format Type Filters: PYQs, Notes, Lab Manuals, Assignments */}
          <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400 shrink-0">Format:</span>
            {[
              { id: 'All', label: 'All Formats' },
              { id: 'PYQ', label: '📄 Past Year PYQs' },
              { id: 'Notes', label: '📝 Lecture Notes' },
              { id: 'Lab Manual', label: '🧪 Lab Manuals' },
              { id: 'Assignment', label: '📋 Solved Assignments' }
            ].map(fmt => (
              <button
                key={fmt.id}
                onClick={() => setSelectedType(fmt.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer whitespace-nowrap ${
                  selectedType === fmt.id
                    ? 'bg-indigo-600 text-white shadow-xs'
                    : 'bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                }`}
              >
                {fmt.label}
              </button>
            ))}
          </div>

          {/* Search Box */}
          <div className="relative w-full md:w-72 shrink-0">
            <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
            <input
              type="text"
              placeholder="Search code, subject, title..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
            />
          </div>

        </div>
      </div>

      {/* ========================================================================= */}
      {/* RESOURCE CARDS DISPLAY GRID */}
      {/* ========================================================================= */}
      {filteredResources.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-12 text-center shadow-xs">
          <BookOpen className="w-12 h-12 text-slate-400 dark:text-slate-600 mx-auto mb-3" />
          <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">No resources or PYQs match your filter criteria</h3>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-md mx-auto">
            Try resetting your branch, semester, or course selections to explore available study material across institutions.
          </p>
          <div className="flex items-center justify-center space-x-3 mt-5">
            <button
              onClick={handleResetFilters}
              className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer shadow-xs"
            >
              Reset All Filters
            </button>
            <button
              onClick={() => setShowUploadModal(true)}
              className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 px-4 py-2 rounded-xl text-xs font-bold transition cursor-pointer border border-slate-300 dark:border-slate-700"
            >
              Upload Material for this Subject
            </button>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredResources.map(res => {
            const resUni = universities.find(u => u.id === res.universityId);
            const instTypeLabel = resUni?.institutionType === 'College' ? 'College' : 'University';

            return (
              <div
                key={res.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-indigo-400 dark:hover:border-indigo-500/60 rounded-2xl p-5 flex flex-col justify-between transition shadow-xs hover:shadow-md group relative"
              >
                <div>
                  {/* Top Badges: Explicit Institution Type (University vs College) & Resource Format */}
                  <div className="flex items-center justify-between mb-3 gap-2">
                    <div className="flex items-center space-x-1.5 overflow-hidden">
                      {/* Separate Format Badge */}
                      <span className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                        res.resourceType === 'PYQ'
                          ? 'bg-purple-50 text-purple-700 border border-purple-200 dark:bg-purple-950 dark:text-purple-300 dark:border-purple-800'
                          : 'bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800'
                      }`}>
                        {res.resourceType}
                      </span>

                      {/* Explicit Classification: University or College */}
                      <span className={`text-[10px] font-extrabold px-2 py-0.5 rounded-full border truncate ${
                        instTypeLabel === 'College'
                          ? 'bg-emerald-50 text-emerald-700 border-emerald-200 dark:bg-emerald-950 dark:text-emerald-300 dark:border-emerald-800'
                          : 'bg-slate-100 text-slate-700 border-slate-200 dark:bg-slate-950 dark:text-slate-300 dark:border-slate-800'
                      }`}>
                        {instTypeLabel === 'College' ? '🏫 College' : '🏛️ University'}
                      </span>
                    </div>

                    {/* Semester Pill */}
                    <span className="bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-800/80 text-[10px] font-extrabold px-2 py-0.5 rounded-full shrink-0">
                      Sem {res.semester}
                    </span>
                  </div>

                  {/* University / College Name */}
                  <div className="text-[11px] font-bold text-slate-500 dark:text-slate-400 mb-1 truncate">
                    {res.universityName}
                  </div>

                  {/* Resource Title */}
                  <h3 className="font-bold text-slate-900 dark:text-slate-100 text-sm leading-snug group-hover:text-indigo-600 dark:group-hover:text-indigo-300 transition line-clamp-2">
                    {res.title}
                  </h3>

                  {/* Course Name & Subject / Topic Section */}
                  <div className="mt-2.5 p-2.5 bg-slate-50 dark:bg-slate-950 rounded-xl border border-slate-200 dark:border-slate-800/80 text-xs">
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-indigo-600 dark:text-indigo-400">{res.courseCode}</span>
                      <span className="text-[10px] text-slate-500 dark:text-slate-400 font-medium">{res.department}</span>
                    </div>
                    <div className="font-semibold text-slate-800 dark:text-slate-200 mt-0.5 truncate">{res.courseName}</div>
                    
                    {(res.subject || res.topic) && (
                      <div className="mt-1.5 pt-1.5 border-t border-slate-200 dark:border-slate-900 text-[11px] flex items-center space-x-1">
                        <span className="text-slate-500">Subject/Topic:</span>
                        <span className="text-cyan-700 dark:text-cyan-300 font-bold truncate">{res.subject || res.topic}</span>
                      </div>
                    )}
                  </div>

                  <p className="text-xs text-slate-600 dark:text-slate-400 mt-2.5 line-clamp-2 leading-relaxed">
                    {res.description}
                  </p>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {res.tags.map((tag, idx) => (
                      <span key={idx} className="bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 text-[10px] px-2 py-0.5 rounded border border-slate-200 dark:border-slate-800/80">
                        #{tag}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Footer Info & Actions */}
                <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                  
                  {/* Uploader avatar */}
                  <div className="flex items-center space-x-1.5 min-w-0">
                    <img src={res.uploaderAvatar} alt={res.uploaderName} className="w-6 h-6 rounded-full object-cover border border-slate-300 dark:border-slate-700 shrink-0" />
                    <span className="text-[11px] text-slate-700 dark:text-slate-300 font-medium truncate max-w-[90px]">{res.uploaderName}</span>
                    <CollegeTag universityName={res.universityName} />
                  </div>

                  {/* Actions */}
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => onOpenAIResourceAssistant(res.courseName)}
                      title="Analyze Exam Topic Frequency with Gemini AI"
                      className="p-1.5 bg-slate-100 hover:bg-amber-400 hover:text-slate-950 text-amber-600 dark:bg-slate-800 dark:text-amber-400 dark:hover:bg-amber-400 dark:hover:text-slate-950 rounded-lg transition cursor-pointer"
                    >
                      <BarChart2 className="w-3.5 h-3.5" />
                    </button>

                    <button
                      onClick={() => setPreviewResource(res)}
                      className="flex items-center space-x-1 bg-indigo-600 hover:bg-indigo-500 text-white font-semibold px-3 py-1.5 rounded-lg text-xs transition cursor-pointer shadow-xs"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View PDF ({res.downloadsCount})</span>
                    </button>
                  </div>

                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* ========================================================================= */}
      {/* PREVIEW & DOWNLOAD MODAL */}
      {/* ========================================================================= */}
      {previewResource && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full overflow-hidden shadow-2xl p-6 text-slate-900 dark:text-slate-100 relative">
            <button
              onClick={() => setPreviewResource(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-wrap items-center gap-2 text-xs text-indigo-600 dark:text-indigo-400 font-bold mb-2">
              <span className="bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 px-2 py-0.5 rounded">
                {previewResource.universityName}
              </span>
              <span>•</span>
              <span>Branch: {previewResource.department}</span>
              <span>•</span>
              <span className="text-amber-600 dark:text-amber-400">Semester {previewResource.semester}</span>
            </div>

            <h2 className="text-xl font-extrabold text-slate-900 dark:text-white mb-2">
              {previewResource.title}
            </h2>

            <p className="text-xs text-slate-600 dark:text-slate-300 mb-4 leading-relaxed">
              {previewResource.description}
            </p>

            {/* Document Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 dark:bg-slate-950 p-3.5 rounded-xl text-xs mb-6 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800">
              <div><span className="text-slate-500 dark:text-slate-400 block text-[10px]">Course Code</span> <strong>{previewResource.courseCode}</strong></div>
              <div><span className="text-slate-500 dark:text-slate-400 block text-[10px]">Course Name</span> <strong>{previewResource.courseName}</strong></div>
              <div><span className="text-slate-500 dark:text-slate-400 block text-[10px]">Subject / Topic</span> <strong className="text-cyan-600 dark:text-cyan-400">{previewResource.subject || previewResource.topic || 'General Module'}</strong></div>
              <div><span className="text-slate-500 dark:text-slate-400 block text-[10px]">Format / Size</span> <strong>{previewResource.fileFormat} ({previewResource.fileSize})</strong></div>
            </div>

            {/* Mock Reader Preview Box */}
            <div className="bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-8 text-center mb-6 relative overflow-hidden">
              <FileText className="w-16 h-16 text-indigo-500 mx-auto mb-3 animate-pulse" />
              <div className="font-bold text-sm text-slate-800 dark:text-slate-200">{previewResource.title}</div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
                Official verified document from {previewResource.universityName} academic repository.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <button
                onClick={() => {
                  const subject = previewResource.courseName;
                  setPreviewResource(null);
                  onOpenAIResourceAssistant(subject);
                }}
                className="flex items-center space-x-2 text-xs text-amber-600 dark:text-amber-400 hover:text-amber-700 dark:hover:text-amber-300 font-bold cursor-pointer"
              >
                <BarChart2 className="w-4 h-4" />
                <span>Analyze exam topic frequency for {previewResource.courseCode}</span>
              </button>

              <button
                onClick={() => {
                  alert(`Downloading ${previewResource.title}... File saved!`);
                  setPreviewResource(null);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2.5 rounded-xl shadow-sm hover:shadow flex items-center space-x-2 text-xs transition cursor-pointer w-full sm:w-auto justify-center"
              >
                <Download className="w-4 h-4" />
                <span>Download PDF Paper</span>
              </button>
            </div>

          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* UPLOAD MATERIAL MODAL */}
      {/* ========================================================================= */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-lg w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl">
            <button
              onClick={() => setShowUploadModal(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-1 flex items-center space-x-2">
              <Upload className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
              <span>Upload PYQ or Study Material</span>
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              Upload past year papers, solved worksheets, or class notes to help fellow engineering students.
            </p>

            <form onSubmit={handleCreateResource} className="space-y-3.5 text-xs">
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Title</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. 2025 DBMS End-Sem Solved PYQ Paper"
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Format</label>
                  <select
                    value={newType}
                    onChange={(e: any) => setNewType(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none cursor-pointer"
                  >
                    <option value="PYQ">PYQ Paper</option>
                    <option value="Notes">Lecture Notes</option>
                    <option value="Lab Manual">Lab Manual</option>
                    <option value="Assignment">Assignment</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Semester</label>
                  <select
                    value={newSem}
                    onChange={(e) => setNewSem(Number(e.target.value))}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none cursor-pointer"
                  >
                    {[1, 2, 3, 4, 5, 6, 7, 8].map(s => (
                      <option key={s} value={s}>Semester {s}</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Course Code</label>
                  <input
                    type="text"
                    value={newCourseCode}
                    onChange={(e) => setNewCourseCode(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Course Name</label>
                  <input
                    type="text"
                    value={newCourseName}
                    onChange={(e) => setNewCourseName(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Subject / Topic Section</label>
                <input
                  type="text"
                  placeholder="e.g. Normalization & BCNF"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">Description</label>
                <textarea
                  rows={2}
                  placeholder="Includes step-by-step solutions for Mid-Sem and End-Sem exams..."
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl p-2.5 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-2 flex justify-end space-x-3">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-4 py-2 rounded-xl text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-5 py-2 rounded-xl cursor-pointer shadow-xs"
                >
                  Publish Resource (+50 Rep)
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
