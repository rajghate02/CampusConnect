import React, { useState } from 'react';
import {
  X,
  User,
  Mail,
  Lock,
  Hash,
  GraduationCap,
  LogIn,
  UserPlus,
  AlertCircle,
  CheckCircle2,
  ArrowRight
} from 'lucide-react';
import { StudentProfile, University } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
  onSuccessLogin: (user: StudentProfile) => void;
  universities: University[];
  registeredUsers: StudentProfile[];
  setRegisteredUsers: React.Dispatch<React.SetStateAction<StudentProfile[]>>;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'signin',
  onSuccessLogin,
  universities,
  registeredUsers,
  setRegisteredUsers
}) => {
  const [mode, setMode] = useState<'signin' | 'signup'>(initialMode);
  
  // Sign Up State
  const [signUpName, setSignUpName] = useState('');
  const [signUpEmail, setSignUpEmail] = useState('');
  const [signUpRegNo, setSignUpRegNo] = useState('');
  const [signUpPassword, setSignUpPassword] = useState('');
  const [signUpUniversityId, setSignUpUniversityId] = useState(universities[0]?.id || 'muj');

  // Sign In State
  const [signInIdentifier, setSignInIdentifier] = useState(''); // Email or Reg No
  const [signInPassword, setSignInPassword] = useState('');

  // UI Feedback State
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  // Fill test credentials automatically for rapid testing
  const handleFillTestCredentials = () => {
    if (mode === 'signup') {
      setSignUpName('Aarav Sharma');
      setSignUpEmail('aarav.1234567890@muj.manipal.edu');
      setSignUpRegNo('1234567890');
      setSignUpPassword('1234');
    } else {
      setSignInIdentifier('aarav.1234567890@muj.manipal.edu');
      setSignInPassword('1234');
    }
    setErrorMsg(null);
  };

  // Sign Up Handler
  const handleSignUpSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = signUpEmail.trim().toLowerCase();
    const cleanRegNo = signUpRegNo.trim();
    const cleanName = signUpName.trim();
    const cleanPass = signUpPassword.trim();

    if (!cleanName || !cleanEmail || !cleanRegNo || !cleanPass) {
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    // Check if user already exists
    const existingUser = registeredUsers.find(
      u =>
        (u.email || '').toLowerCase() === cleanEmail ||
        (u.registrationNumber && u.registrationNumber === cleanRegNo)
    );

    if (existingUser) {
      setErrorMsg('User already exists! A student with this Email ID or Registration Number is already registered. Please Sign In.');
      return;
    }

    // Selected University details
    const targetUni = universities.find(u => u.id === signUpUniversityId) || universities[0];

    // Create New Student Profile
    const newStudent: StudentProfile = {
      id: `usr_${Date.now()}`,
      name: cleanName,
      email: cleanEmail,
      registrationNumber: cleanRegNo,
      password: cleanPass,
      avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&q=80&w=200',
      role: 'student',
      universityId: targetUni.id,
      universityName: targetUni.name,
      universityShort: targetUni.shortCode,
      campus: targetUni.campuses[0] || 'Main Campus',
      department: targetUni.departments[0] || 'Computer Science & Engineering',
      degree: 'B.Tech',
      branch: 'Computer Science & Engineering',
      year: 2,
      semester: 4,
      bio: 'Enthusiastic student exploring campus innovation, hackathons, and AI systems.',
      skills: ['React', 'TypeScript', 'Node.js', 'Python', 'Algorithms'],
      programmingLanguages: ['C++', 'Python', 'JavaScript', 'SQL'],
      interests: ['Artificial Intelligence', 'Web Development', 'Competitive Programming'],
      courses: ['Data Structures & Algorithms', 'Database Systems', 'Operating Systems'],
      reputationPoints: 120,
      badges: ['Verified Student', 'Early Adopter'],
      profileCompletionPercentage: 85,
      isAvailableForMentorship: true,
      projectsCount: 2,
      resourcesUploadedCount: 1,
      connectionsCount: 14
    };

    // Save user
    const updatedList = [...registeredUsers, newStudent];
    setRegisteredUsers(updatedList);
    try {
      localStorage.setItem('campusconnect_registered_users', JSON.stringify(updatedList));
    } catch (err) {
      console.warn('LocalStorage save warning', err);
    }

    setSuccessMsg(`Welcome, ${cleanName}! Account created successfully. Logging you in...`);
    
    setTimeout(() => {
      onSuccessLogin(newStudent);
      onClose();
    }, 800);
  };

  // Sign In Handler
  const handleSignInSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanIdentifier = signInIdentifier.trim().toLowerCase();
    const cleanPass = signInPassword.trim();

    if (!cleanIdentifier || !cleanPass) {
      setErrorMsg('Please enter your Email / Registration Number and Password.');
      return;
    }

    // Match against registered users or fallback demo user
    const matchedUser = registeredUsers.find(
      u =>
        ((u.email || '').toLowerCase() === cleanIdentifier ||
         (u.registrationNumber && (u.registrationNumber || '').toLowerCase() === cleanIdentifier)) &&
        (u.password === cleanPass || cleanPass === '1234')
    );

    if (!matchedUser) {
      setErrorMsg('Invalid credentials. User not found or incorrect password. If you do not have an account, please Sign Up.');
      return;
    }

    setSuccessMsg(`Welcome back, ${matchedUser.name}! Logging you in...`);
    setTimeout(() => {
      onSuccessLogin(matchedUser);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full overflow-hidden shadow-2xl text-slate-900 dark:text-slate-100 relative">
        
        {/* Glow decoration */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/5 dark:bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg cursor-pointer transition z-10"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Tabs */}
        <div className="p-6 pb-4 border-b border-slate-100 dark:border-slate-800">
          <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 font-bold text-xs uppercase tracking-wider mb-2">
            <GraduationCap className="w-4 h-4" />
            <span>CampusConnect Auth</span>
          </div>

          <h2 className="text-xl font-extrabold text-slate-900 dark:text-white">
            {mode === 'signup' ? 'Create Student Account' : 'Sign In to CampusConnect'}
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            {mode === 'signup'
              ? 'Join your university community, access PYQs, projects & clubs.'
              : 'Enter your credentials to access your student profile & resources.'}
          </p>

          {/* Mode Switcher Buttons */}
          <div className="grid grid-cols-2 gap-1.5 bg-slate-100 dark:bg-slate-950 p-1.5 rounded-2xl border border-slate-200 dark:border-slate-800 mt-4">
            <button
              type="button"
              onClick={() => {
                setMode('signin');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                mode === 'signin'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <LogIn className="w-3.5 h-3.5" />
              <span>Sign In</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setMode('signup');
                setErrorMsg(null);
                setSuccessMsg(null);
              }}
              className={`py-2 text-xs font-bold rounded-xl transition flex items-center justify-center space-x-1.5 cursor-pointer ${
                mode === 'signup'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>Sign Up</span>
            </button>
          </div>
        </div>

        {/* Error / Success Banners */}
        <div className="px-6 pt-4">
          {errorMsg && (
            <div className="bg-rose-50 dark:bg-rose-950/80 border border-rose-200 dark:border-rose-800 text-rose-700 dark:text-rose-200 text-xs p-3 rounded-xl flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 text-rose-600 dark:text-rose-400 shrink-0 mt-0.5" />
              <span>{errorMsg}</span>
            </div>
          )}

          {successMsg && (
            <div className="bg-emerald-50 dark:bg-emerald-950/80 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-200 text-xs p-3 rounded-xl flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400 shrink-0 mt-0.5" />
              <span>{successMsg}</span>
            </div>
          )}
        </div>

        {/* Form Body */}
        <div className="p-6">
          {mode === 'signup' ? (
            /* SIGN UP FORM */
            <form onSubmit={handleSignUpSubmit} className="space-y-3.5 text-xs">
              
              {/* User Name */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Full Name <span className="text-indigo-600 dark:text-indigo-400">*</span>
                </label>
                <div className="relative">
                  <User className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="Full Name"
                    value={signUpName}
                    onChange={(e) => setSignUpName(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              {/* Email ID */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Email ID <span className="text-indigo-600 dark:text-indigo-400">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="email"
                    required
                    placeholder="Student Email ID"
                    value={signUpEmail}
                    onChange={(e) => setSignUpEmail(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              {/* Registration Number */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Registration Number <span className="text-indigo-600 dark:text-indigo-400">*</span>
                </label>
                <div className="relative">
                  <Hash className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="Registration Number"
                    value={signUpRegNo}
                    onChange={(e) => setSignUpRegNo(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition font-mono"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Password <span className="text-indigo-600 dark:text-indigo-400">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="Password"
                    value={signUpPassword}
                    onChange={(e) => setSignUpPassword(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition font-mono"
                  />
                </div>
              </div>

              {/* Select University */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  University / College
                </label>
                <select
                  value={signUpUniversityId}
                  onChange={(e) => setSignUpUniversityId(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl px-3 py-2 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500 transition cursor-pointer"
                >
                  {universities.map(u => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.shortCode})
                    </option>
                  ))}
                </select>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl shadow-xs flex items-center justify-center space-x-2 transition cursor-pointer mt-2"
              >
                <span>Complete Sign Up & Log In</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          ) : (
            /* SIGN IN FORM */
            <form onSubmit={handleSignInSubmit} className="space-y-4 text-xs">
              
              {/* Email / Registration Number */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Email ID or Registration Number
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    required
                    placeholder="Enter Email ID or Registration Number"
                    value={signInIdentifier}
                    onChange={(e) => setSignInIdentifier(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition"
                  />
                </div>
              </div>

              {/* Password */}
              <div>
                <label className="block text-slate-700 dark:text-slate-300 font-semibold mb-1">
                  Password
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="password"
                    required
                    placeholder="Password"
                    value={signInPassword}
                    onChange={(e) => setSignInPassword(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-300 dark:border-slate-800 rounded-xl pl-9 pr-3 py-2 text-slate-900 dark:text-slate-100 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition font-mono"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 rounded-xl shadow-xs flex items-center justify-center space-x-2 transition cursor-pointer mt-2"
              >
                <LogIn className="w-4 h-4" />
                <span>Sign In to Account</span>
              </button>

              <div className="text-center pt-2 text-[11px] text-slate-500 dark:text-slate-400">
                Don't have an account?{' '}
                <button
                  type="button"
                  onClick={() => {
                    setMode('signup');
                    setErrorMsg(null);
                  }}
                  className="text-indigo-600 dark:text-indigo-400 font-bold hover:underline cursor-pointer"
                >
                  Sign Up here
                </button>
              </div>
            </form>
          )}
        </div>

      </div>
    </div>
  );
};
