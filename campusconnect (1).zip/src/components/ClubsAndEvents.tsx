import React from 'react';
import {
  Calendar,
  Users,
  MapPin,
  Trophy,
  ExternalLink,
  Plus,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import { ClubItem, EventItem, University } from '../types';

interface ClubsAndEventsProps {
  clubs: ClubItem[];
  events: EventItem[];
  selectedUniversity: University;
}

export const ClubsAndEvents: React.FC<ClubsAndEventsProps> = ({
  clubs,
  events,
  selectedUniversity
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 space-y-12 transition-colors duration-200">
      
      {/* SECTION 1: HACKATHONS & EVENTS */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="flex items-center space-x-2">
              <span className="bg-pink-50 text-pink-700 border border-pink-200 dark:bg-pink-900 dark:text-pink-300 dark:border-transparent font-bold px-2.5 py-0.5 rounded text-xs">
                Flagship Competitions
              </span>
              <span className="text-xs text-slate-500 dark:text-slate-400">{selectedUniversity.shortCode} Campus</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
              Hackathons & Campus Events
            </h1>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {events.map(ev => (
            <div key={ev.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition flex flex-col justify-between">
              <div>
                <img src={ev.bannerImage} alt={ev.title} className="w-full h-40 object-cover" />
                <div className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold bg-pink-50 text-pink-700 border border-pink-200 dark:bg-pink-950 dark:text-pink-300 dark:border-pink-800 px-2.5 py-1 rounded-full uppercase">
                      {ev.type}
                    </span>
                    <span className="text-xs text-amber-600 dark:text-amber-400 font-bold">Prize Pool: {ev.prizePool}</span>
                  </div>

                  <h2 className="text-lg font-bold text-slate-900 dark:text-white mb-2">{ev.title}</h2>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mb-4">{ev.description}</p>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 dark:bg-slate-950 p-3 rounded-xl text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800/80 mb-4">
                    <div>Date: <strong>{ev.date}</strong></div>
                    <div>Location: <strong>{ev.location}</strong></div>
                    <div>Attendees: <strong>{ev.attendeesCount} Registered</strong></div>
                    <div>Deadline: <strong>{ev.registrationDeadline}</strong></div>
                  </div>
                </div>
              </div>

              <div className="p-4 bg-slate-50 dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between">
                <span className="text-xs text-slate-500 dark:text-slate-400">Organized by {ev.organizer}</span>
                <button
                  onClick={() => alert(`Registered for ${ev.title}! Confirmation sent to your university email.`)}
                  className="bg-pink-600 hover:bg-pink-500 text-white font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer shadow-xs"
                >
                  Register Now
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* SECTION 2: CLUBS */}
      <div>
        <div className="mb-6">
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white tracking-tight">
            Official University Clubs
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Coding, Robotics, Entrepreneurship, and Research societies at {selectedUniversity.name}.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {clubs.map(club => (
            <div key={club.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs hover:shadow-md transition flex items-start space-x-4">
              <img src={club.logo} alt={club.name} className="w-14 h-14 rounded-2xl object-cover shrink-0 border border-slate-200 dark:border-slate-800" />
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 dark:text-white text-base">{club.name}</h3>
                  <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-transparent font-bold px-2.5 py-0.5 rounded-full">
                    {club.category}
                  </span>
                </div>
                <p className="text-xs text-slate-600 dark:text-slate-300 mt-1 mb-3">{club.description}</p>

                <div className="flex items-center justify-between text-xs pt-3 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500 dark:text-slate-400">{club.memberCount} Members • Lead: {club.leadName}</span>
                  <button
                    onClick={() => alert(`Joined ${club.name}! You are now on the official member roster.`)}
                    className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-indigo-700 dark:text-indigo-300 font-bold px-3 py-1.5 rounded-lg text-xs transition border border-slate-200 dark:border-slate-700"
                  >
                    Join Club
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
