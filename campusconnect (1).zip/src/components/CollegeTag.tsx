import React from 'react';

interface CollegeTagProps {
  tag?: string;
  universityName?: string;
  className?: string;
}

export const CollegeTag: React.FC<CollegeTagProps> = ({ tag, universityName, className = '' }) => {
  let displayTag = tag;
  if (!displayTag && universityName) {
    const lower = universityName.toLowerCase();
    if (lower.includes('jaipur') || lower.includes('manipal')) displayTag = 'MUJ';
    else if (lower.includes('delhi')) displayTag = 'IITD';
    else if (lower.includes('bombay')) displayTag = 'IITB';
    else if (lower.includes('pilani') || lower.includes('bits')) displayTag = 'BITS';
    else if (lower.includes('science') || lower.includes('iisc')) displayTag = 'IISc';
    else if (lower.includes('delft')) displayTag = 'TUD';
    else displayTag = universityName.substring(0, 4).toUpperCase();
  }
  if (!displayTag) displayTag = 'MUJ';

  return (
    <span
      className={`inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-extrabold uppercase bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-700/80 shrink-0 select-none ${className}`}
      title={`Student of ${universityName || displayTag}`}
    >
      {displayTag}
    </span>
  );
};
