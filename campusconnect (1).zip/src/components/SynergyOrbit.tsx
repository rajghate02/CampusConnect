import React, { useState } from 'react';
import {
  Zap,
  MessageSquare,
  Search,
  Filter,
  UserPlus,
  CheckCircle2,
  Send,
  Building2,
  GraduationCap,
  Code,
  Globe,
  Share2,
  Paperclip,
  Radio,
  FileText,
  Award,
  Plus,
  X,
  Volume2,
  ArrowRight,
  ShieldCheck,
  Check,
  Flame
} from 'lucide-react';
import { CollegeTag } from './CollegeTag';
import { StudentProfile, University } from '../types';

interface SynergyOrbitProps {
  currentUser: StudentProfile;
  universities: University[];
  onOpenProfile: () => void;
}

export interface OrbitPeer {
  id: string;
  name: string;
  email: string;
  registrationNumber?: string;
  avatar: string;
  universityName: string;
  universityShort: string;
  department: string;
  year: number;
  semester: number;
  synergyScore: number; // e.g. 98%
  bio: string;
  skills: string[];
  interests: string[];
  badges: string[];
  isAvailableForProject: boolean;
  connectionStatus: 'none' | 'pending' | 'connected';
  onlineStatus: 'online' | 'offline' | 'in_lab';
}

export interface ChatMessage {
  id: string;
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  timestamp: string;
  type?: 'text' | 'code' | 'resource' | 'voice' | 'project';
  meta?: string;
}

export interface OrbitPulsePost {
  id: string;
  authorId: string;
  authorName: string;
  authorAvatar: string;
  authorUniversity: string;
  authorBranch: string;
  timestamp: string;
  content: string;
  tags: string[];
  sparksCount: number;
  hasSparked: boolean;
}

export const SynergyOrbit: React.FC<SynergyOrbitProps> = ({
  currentUser,
  universities,
  onOpenProfile
}) => {
  // Tab within Orbit: 'discover' | 'chat' | 'pulse'
  const [activeOrbitTab, setActiveOrbitTab] = useState<'discover' | 'chat' | 'pulse'>('discover');

  // Search & Filter State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDomain, setSelectedDomain] = useState<string>('all');
  const [selectedUniversityFilter, setSelectedUniversityFilter] = useState<string>('all');

  // Sample Peers list
  const [peers, setPeers] = useState<OrbitPeer[]>([
    {
      id: 'peer_1',
      name: 'Rohan Varma',
      email: 'rohan.varma@iitd.ac.in',
      registrationNumber: '2024CS1092',
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      universityName: 'Indian Institute of Technology Delhi',
      universityShort: 'IITD',
      department: 'Computer Science & Engineering',
      year: 3,
      semester: 5,
      synergyScore: 98,
      bio: 'GenAI researcher & PyTorch enthusiast. Building distributed agentic workflows for autonomous code debugging.',
      skills: ['PyTorch', 'TypeScript', 'FastAPI', 'LangChain', 'Docker'],
      interests: ['Artificial Intelligence', 'LLM Alignment', 'Hackathons'],
      badges: ['Hackathon Champion', 'Top Contributor'],
      isAvailableForProject: true,
      connectionStatus: 'connected',
      onlineStatus: 'online'
    },
    {
      id: 'peer_2',
      name: 'Ananya Gupta',
      email: 'ananya.gupta@muj.manipal.edu',
      registrationNumber: '2293010421',
      avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
      universityName: 'Manipal University Jaipur',
      universityShort: 'MUJ',
      department: 'AI & Data Science',
      year: 2,
      semester: 4,
      synergyScore: 95,
      bio: 'Full-Stack Developer crafting responsive Web3 & React platforms. Passionate about UI animations & clean APIs.',
      skills: ['React', 'Next.js', 'Tailwind CSS', 'Solidity', 'Node.js'],
      interests: ['Web Development', 'UI/UX Design', 'Open Source'],
      badges: ['PYQ Hero', 'Verified Student'],
      isAvailableForProject: true,
      connectionStatus: 'connected',
      onlineStatus: 'online'
    },
    {
      id: 'peer_3',
      name: 'Karan Patel',
      email: 'karan.patel@bits-pilani.ac.in',
      registrationNumber: '2023A7PS089P',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      universityName: 'BITS Pilani',
      universityShort: 'BITS',
      department: 'Electrical & Electronics',
      year: 3,
      semester: 6,
      synergyScore: 92,
      bio: 'Embedded Systems engineer & Rust programmer. Working on IoT edge sensors and low-latency Bluetooth stacks.',
      skills: ['C++', 'Rust', 'Embedded C', 'STM32', 'Python'],
      interests: ['Robotics', 'Hardware Hacking', 'Competitive Coding'],
      badges: ['Robotics Lead', 'Hardware Guru'],
      isAvailableForProject: true,
      connectionStatus: 'none',
      onlineStatus: 'in_lab'
    },
    {
      id: 'peer_4',
      name: 'Sanya Malhotra',
      email: 'sanya.m@iitb.ac.in',
      registrationNumber: '210050122',
      avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&q=80&w=200',
      universityName: 'Indian Institute of Technology Bombay',
      universityShort: 'IITB',
      department: 'Computer Science & Engg',
      year: 4,
      semester: 7,
      synergyScore: 89,
      bio: 'Competitive Programmer (Candidate Master on Codeforces). Specialist in graph algorithms and dynamic programming.',
      skills: ['C++', 'Algorithms', 'Data Structures', 'Python', 'Math'],
      interests: ['Competitive Programming', 'Algorithms', 'Research'],
      badges: ['CP Specialist', 'Academic Mentor'],
      isAvailableForProject: false,
      connectionStatus: 'none',
      onlineStatus: 'offline'
    },
    {
      id: 'peer_5',
      name: 'Devansh Roy',
      email: 'devansh.roy@iisc.ac.in',
      registrationNumber: '2025IISC008',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=200',
      universityName: 'Indian Institute of Science Bangalore',
      universityShort: 'IISc',
      department: 'Computer Science & Automation',
      year: 1,
      semester: 2,
      synergyScore: 94,
      bio: 'Quantum computing enthusiast & linear algebra solver. Building simulator interfaces in WebGL.',
      skills: ['Python', 'Qiskit', 'Three.js', 'C++', 'Linear Algebra'],
      interests: ['Quantum Physics', 'Computer Graphics', 'AI Research'],
      badges: ['Quantum Scholar', 'Early Adopter'],
      isAvailableForProject: true,
      connectionStatus: 'pending',
      onlineStatus: 'online'
    }
  ]);

  // Selected Active Chat Peer
  const [activeChatPeerId, setActiveChatPeerId] = useState<string>('peer_1');
  const [messagesMap, setMessagesMap] = useState<Record<string, ChatMessage[]>>({
    peer_1: [
      {
        id: 'msg_1',
        senderId: 'peer_1',
        senderName: 'Rohan Varma',
        senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
        text: 'Hey Aarav! I saw your project on CampusConnect for the AI Resume Grader. The ATS keyword algorithm is super smooth!',
        timestamp: '10:14 AM'
      },
      {
        id: 'msg_2',
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        text: 'Thanks Rohan! We built it using Gemini 2.5 Flash and Tailwind. Are you participating in the upcoming National HackSummit?',
        timestamp: '10:16 AM'
      },
      {
        id: 'msg_3',
        senderId: 'peer_1',
        senderName: 'Rohan Varma',
        senderAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
        text: 'Yes! Our team needs a solid React/TypeScript frontend developer with state management experience. Let us collaborate!',
        timestamp: '10:18 AM',
        type: 'project',
        meta: 'Hackathon Synergy Proposal: AI Agent Workspace'
      }
    ],
    peer_2: [
      {
        id: 'msg_4',
        senderId: 'peer_2',
        senderName: 'Ananya Gupta',
        senderAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
        text: 'Hi Aarav, do you have the solved PYQ solutions for 2025 Data Structures Mid-Sems?',
        timestamp: 'Yesterday'
      },
      {
        id: 'msg_5',
        senderId: currentUser.id,
        senderName: currentUser.name,
        senderAvatar: currentUser.avatar,
        text: 'Just uploaded them to the PYQs & Notes tab! Check out the PDF download link.',
        timestamp: 'Yesterday',
        type: 'resource',
        meta: 'Verified PYQ: Data Structures 2025 Solutions.pdf'
      }
    ]
  });

  const [inputMessage, setInputMessage] = useState('');

  // Custom Spark Transmit Modal State
  const [sparkModalPeer, setSparkModalPeer] = useState<OrbitPeer | null>(null);
  const [sparkNoteText, setSparkNoteText] = useState('');

  // Orbit Pulse Posts State
  const [pulsePosts, setPulsePosts] = useState<OrbitPulsePost[]>([
    {
      id: 'post_1',
      authorId: 'peer_1',
      authorName: 'Rohan Varma',
      authorAvatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=200',
      authorUniversity: 'IIT Delhi',
      authorBranch: 'CSE (B.Tech Year 3)',
      timestamp: '25 mins ago',
      content: '🚀 Looking for 1 Full-Stack developer & 1 UI Designer to complete our team for National AI Hackathon 2026! We have the PyTorch agent backend ready. Transmit a Synergy Spark if interested!',
      tags: ['Hackathon', 'GenAI', 'React', 'FastAPI'],
      sparksCount: 14,
      hasSparked: false
    },
    {
      id: 'post_2',
      authorId: 'peer_2',
      authorName: 'Ananya Gupta',
      authorAvatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&q=80&w=200',
      authorUniversity: 'Manipal University Jaipur',
      authorBranch: 'AI & DS (B.Tech Year 2)',
      timestamp: '1 hour ago',
      content: '📚 Just uploaded 12 new verified PYQs for Operating Systems and Database Systems with step-by-step solutions on CampusConnect. Check them out in the PYQs tab!',
      tags: ['PYQs', 'ExamPrep', 'Database', 'OperatingSystems'],
      sparksCount: 29,
      hasSparked: true
    },
    {
      id: 'post_3',
      authorId: 'peer_3',
      authorName: 'Karan Patel',
      authorAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=200',
      authorUniversity: 'BITS Pilani',
      authorBranch: 'ECE (B.Tech Year 3)',
      timestamp: '3 hours ago',
      content: '⚡ Anyone interested in building an open-source Rust wrapper for Bluetooth Edge Sensors? We are holding an online weekend sprint!',
      tags: ['Rust', 'Embedded', 'OpenSource', 'Hardware'],
      sparksCount: 18,
      hasSparked: false
    }
  ]);

  const [newPulseContent, setNewPulseContent] = useState('');

  // Handle Spark Transmit Trigger
  const handleInitiateSpark = (peer: OrbitPeer) => {
    setSparkModalPeer(peer);
    setSparkNoteText(`Hi ${peer.name}! I noticed your work in ${peer.skills[0] || 'engineering'} and would love to connect on Synergy Orbit!`);
  };

  const handleConfirmSparkTransmit = () => {
    if (!sparkModalPeer) return;

    setPeers(prev =>
      prev.map(p => (p.id === sparkModalPeer.id ? { ...p, connectionStatus: 'pending' } : p))
    );

    setSparkModalPeer(null);
  };

  // Handle Send Message
  const handleSendMessage = (type: 'text' | 'code' | 'resource' | 'project' = 'text', customMeta?: string) => {
    if (!inputMessage.trim() && !customMeta) return;

    const newMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      text: inputMessage.trim() || (type === 'project' ? 'Shared a project synergy invite' : 'Shared resource link'),
      timestamp: 'Just now',
      type,
      meta: customMeta
    };

    setMessagesMap(prev => ({
      ...prev,
      [activeChatPeerId]: [...(prev[activeChatPeerId] || []), newMsg]
    }));

    setInputMessage('');

    // Simulate realistic peer reply after short delay
    setTimeout(() => {
      const activePeer = peers.find(p => p.id === activeChatPeerId);
      if (!activePeer) return;

      const autoReply: ChatMessage = {
        id: `msg_${Date.now() + 1}`,
        senderId: activePeer.id,
        senderName: activePeer.name,
        senderAvatar: activePeer.avatar,
        text: `Got your message, ${currentUser.name.split(' ')[0]}! Let's schedule a quick call or link our project repositories on CampusConnect.`,
        timestamp: 'Just now'
      };

      setMessagesMap(prev => ({
        ...prev,
        [activeChatPeerId]: [...(prev[activeChatPeerId] || []), autoReply]
      }));
    }, 1200);
  };

  // Handle New Orbit Broadcast
  const handleCreatePulsePost = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPulseContent.trim()) return;

    const newPost: OrbitPulsePost = {
      id: `post_${Date.now()}`,
      authorId: currentUser.id,
      authorName: currentUser.name,
      authorAvatar: currentUser.avatar,
      authorUniversity: currentUser.universityName,
      authorBranch: `${currentUser.branch} (Year ${currentUser.year})`,
      timestamp: 'Just now',
      content: newPulseContent.trim(),
      tags: ['StudentOrbit', 'Collaboration', 'CampusConnect'],
      sparksCount: 1,
      hasSparked: true
    };

    setPulsePosts([newPost, ...pulsePosts]);
    setNewPulseContent('');
  };

  // Toggle spark on post
  const handleTogglePostSpark = (postId: string) => {
    setPulsePosts(prev =>
      prev.map(p => {
        if (p.id === postId) {
          return {
            ...p,
            sparksCount: p.hasSparked ? p.sparksCount - 1 : p.sparksCount + 1,
            hasSparked: !p.hasSparked
          };
        }
        return p;
      })
    );
  };

  // Filter peers
  const filteredPeers = peers.filter(peer => {
    const sQuery = (searchQuery || '').toLowerCase();
    const selDomain = (selectedDomain || '').toLowerCase();
    const selUniFilter = (selectedUniversityFilter || '').toLowerCase();

    const pName = (peer.name || '').toLowerCase();
    const pUniName = (peer.universityName || '').toLowerCase();
    const pUniShort = (peer.universityShort || '').toLowerCase();
    const pSkills = peer.skills || [];
    const pInterests = peer.interests || [];

    const matchesSearch =
      pName.includes(sQuery) ||
      pUniName.includes(sQuery) ||
      pSkills.some(s => (s || '').toLowerCase().includes(sQuery)) ||
      pInterests.some(i => (i || '').toLowerCase().includes(sQuery));

    const matchesDomain =
      selectedDomain === 'all' ||
      pSkills.some(s => (s || '').toLowerCase().includes(selDomain)) ||
      pInterests.some(i => (i || '').toLowerCase().includes(selDomain));

    const matchesUni =
      selectedUniversityFilter === 'all' || (pUniShort && pUniShort === selUniFilter);

    return matchesSearch && matchesDomain && matchesUni;
  });

  const activeChatPeer = peers.find(p => p.id === activeChatPeerId) || peers[0];
  const activeChatMessages = messagesMap[activeChatPeerId] || [];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 py-8 px-4 sm:px-6 lg:px-8 transition-colors duration-200">
      <div className="max-w-7xl mx-auto space-y-6">

        {/* TOP HERO BANNER */}
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-indigo-900 via-slate-900 to-purple-950 p-6 lg:p-8 border border-indigo-800/50 shadow-2xl">
          <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div className="space-y-2 max-w-2xl">
              <div className="inline-flex items-center space-x-2 bg-indigo-950 border border-indigo-700/80 rounded-full px-3 py-1 text-xs font-bold text-indigo-300">
                <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                <span>Next-Gen Student Connection Engine</span>
              </div>
              <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white">
                Synergy Orbit & Peer Chat
              </h1>
              <p className="text-slate-300 text-xs sm:text-sm leading-relaxed">
                Connect with verified students across universities based on skill synergy score. Transmit custom <strong className="text-amber-400">Synergy Sparks</strong> to build your academic team and launch direct 1-on-1 chats.
              </p>
            </div>

            {/* Orbit Navigation Tabs */}
            <div className="flex bg-slate-950/80 p-1.5 rounded-2xl border border-slate-800 shrink-0 self-start lg:self-center">
              <button
                onClick={() => setActiveOrbitTab('discover')}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                  activeOrbitTab === 'discover'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-400" />
                <span>Peer Orbit ({filteredPeers.length})</span>
              </button>

              <button
                onClick={() => setActiveOrbitTab('chat')}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                  activeOrbitTab === 'chat'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span>Direct Peer Chat</span>
                <span className="bg-cyan-500 text-slate-950 px-1.5 py-0.2 text-[10px] rounded-full font-extrabold">Live</span>
              </button>

              <button
                onClick={() => setActiveOrbitTab('pulse')}
                className={`px-4 py-2 text-xs font-bold rounded-xl transition flex items-center space-x-2 cursor-pointer ${
                  activeOrbitTab === 'pulse'
                    ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Radio className="w-4 h-4 text-rose-400 animate-pulse" />
                <span>Orbit Pulse Feed</span>
              </button>
            </div>
          </div>
        </div>

        {/* TAB 1: DISCOVER PEERS */}
        {activeOrbitTab === 'discover' && (
          <div className="space-y-6">
            
            {/* Search & Domain Filter Bar */}
            <div className="bg-white dark:bg-slate-900/90 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 flex flex-col md:flex-row gap-3 items-center justify-between shadow-xs">
              
              {/* Search Bar */}
              <div className="relative w-full md:w-96">
                <Search className="w-4 h-4 absolute left-3.5 top-3 text-slate-400" />
                <input
                  type="text"
                  placeholder="Search students by name, skill (PyTorch, React), or branch..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl pl-10 pr-4 py-2 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
                />
              </div>

              {/* Filter Dropdowns */}
              <div className="flex items-center space-x-2 w-full md:w-auto overflow-x-auto pb-1 md:pb-0">
                <div className="flex items-center space-x-1.5 text-xs text-slate-500 dark:text-slate-400 font-medium shrink-0">
                  <Filter className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                  <span>Domain:</span>
                </div>
                
                {['all', 'AI/ML', 'React', 'Python', 'Web3', 'C++', 'Embedded'].map(domain => (
                  <button
                    key={domain}
                    onClick={() => setSelectedDomain(domain)}
                    className={`px-3 py-1.5 text-xs font-bold rounded-xl transition whitespace-nowrap cursor-pointer ${
                      selectedDomain === domain
                        ? 'bg-indigo-600 text-white'
                        : 'bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                    }`}
                  >
                    {domain === 'all' ? 'All Skills' : domain}
                  </button>
                ))}
              </div>
            </div>

            {/* Peer Cards Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredPeers.map(peer => (
                <div
                  key={peer.id}
                  className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 hover:border-indigo-500/50 transition duration-300 relative group flex flex-col justify-between shadow-xs"
                >
                  {/* Top Badge & Synergy Rating */}
                  <div>
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-1.5 bg-indigo-50 dark:bg-gradient-to-r dark:from-indigo-950 dark:to-purple-950 border border-indigo-200 dark:border-indigo-700/60 rounded-full px-3 py-1 text-[11px] font-extrabold text-indigo-700 dark:text-indigo-300 shadow-xs">
                        <Flame className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
                        <span>{peer.synergyScore}% Synergy Match</span>
                      </div>

                      <div className="flex items-center space-x-1 text-[11px] font-semibold">
                        <span className={`w-2 h-2 rounded-full ${
                          peer.onlineStatus === 'online'
                            ? 'bg-emerald-500 shadow-xs shadow-emerald-400/50'
                            : peer.onlineStatus === 'in_lab'
                            ? 'bg-amber-400'
                            : 'bg-slate-400'
                        }`} />
                        <span className="text-slate-500 dark:text-slate-400 uppercase tracking-wider text-[10px]">
                          {peer.onlineStatus === 'in_lab' ? 'In Lab' : peer.onlineStatus}
                        </span>
                      </div>
                    </div>

                    {/* Profile Header */}
                    <div className="flex items-start space-x-3 mb-3">
                      <img
                        src={peer.avatar}
                        alt={peer.name}
                        className="w-12 h-12 rounded-2xl object-cover border-2 border-indigo-500/40 shrink-0"
                      />
                      <div className="min-w-0 flex-1">
                        <h3 className="font-extrabold text-slate-900 dark:text-slate-100 text-sm truncate flex items-center space-x-1.5">
                          <span>{peer.name}</span>
                          <CollegeTag tag={peer.universityShort} universityName={peer.universityName} />
                          <ShieldCheck className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400 shrink-0" />
                        </h3>
                        <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate flex items-center space-x-1">
                          <GraduationCap className="w-3 h-3 text-indigo-500 dark:text-indigo-400 shrink-0" />
                          <span>{peer.universityShort} • {peer.department}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 dark:text-slate-400 font-mono">
                          Year {peer.year} (Sem {peer.semester})
                        </div>
                      </div>
                    </div>

                    {/* Bio */}
                    <p className="text-xs text-slate-600 dark:text-slate-300 line-clamp-2 leading-relaxed mb-4">
                      "{peer.bio}"
                    </p>

                    {/* Skills Tags */}
                    <div className="flex flex-wrap gap-1.5 mb-4">
                      {peer.skills.map((sk, idx) => (
                        <span
                          key={idx}
                          className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 text-[10px] font-semibold px-2 py-0.5 rounded-lg"
                        >
                          {sk}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Connection Action Buttons */}
                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center space-x-2">
                    {peer.connectionStatus === 'connected' ? (
                      <>
                        <button
                          disabled
                          className="flex-1 bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-700/60 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 cursor-default"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                          <span>Synergy Linked</span>
                        </button>
                        <button
                          onClick={() => {
                            setActiveChatPeerId(peer.id);
                            setActiveOrbitTab('chat');
                          }}
                          className="bg-indigo-600 hover:bg-indigo-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition cursor-pointer shadow-xs"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>Chat</span>
                        </button>
                      </>
                    ) : peer.connectionStatus === 'pending' ? (
                      <button
                        disabled
                        className="w-full bg-slate-100 dark:bg-slate-800 text-amber-700 dark:text-amber-300 border border-amber-300 dark:border-amber-500/40 py-2 rounded-xl text-xs font-bold flex items-center justify-center space-x-1.5 cursor-default"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 animate-pulse" />
                        <span>Spark Transmitted...</span>
                      </button>
                    ) : (
                      <button
                        onClick={() => handleInitiateSpark(peer)}
                        className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-2 rounded-xl text-xs font-extrabold flex items-center justify-center space-x-1.5 transition shadow-xs cursor-pointer"
                      >
                        <Zap className="w-3.5 h-3.5 text-amber-300 fill-amber-300" />
                        <span>Transmit Synergy Spark</span>
                      </button>
                    )}
                  </div>

                </div>
              ))}
            </div>

          </div>
        )}

        {/* TAB 2: DIRECT PEER CHAT STATION */}
        {activeOrbitTab === 'chat' && (
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl overflow-hidden shadow-xl grid grid-cols-1 md:grid-cols-3 min-h-[600px]">
            
            {/* Left Sidebar: Connected Peer Conversations */}
            <div className="border-b md:border-b-0 md:border-r border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 p-4 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center space-x-2">
                  <MessageSquare className="w-4 h-4 text-cyan-600 dark:text-cyan-400" />
                  <span>Synergy Conversations</span>
                </h3>
                <span className="text-[10px] bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 px-2 py-0.5 rounded-full font-bold">
                  {peers.filter(p => p.connectionStatus === 'connected').length} Active
                </span>
              </div>

              {/* Chat Peer List */}
              <div className="space-y-1.5">
                {peers.map(p => (
                  <button
                    key={p.id}
                    onClick={() => setActiveChatPeerId(p.id)}
                    className={`w-full text-left p-3 rounded-2xl transition flex items-start space-x-3 cursor-pointer ${
                      activeChatPeerId === p.id
                        ? 'bg-indigo-50 dark:bg-indigo-950/80 border border-indigo-200 dark:border-indigo-700/60'
                        : 'hover:bg-slate-100 dark:hover:bg-slate-900 border border-transparent'
                    }`}
                  >
                    <div className="relative shrink-0">
                      <img src={p.avatar} alt={p.name} className="w-10 h-10 rounded-xl object-cover" />
                      <span className={`absolute -bottom-1 -right-1 w-3 h-3 rounded-full border-2 border-white dark:border-slate-950 ${
                        p.onlineStatus === 'online' ? 'bg-emerald-500' : 'bg-slate-400'
                      }`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-xs text-slate-900 dark:text-slate-100 truncate">{p.name}</span>
                        <span className="text-[10px] text-slate-400 font-mono">{p.universityShort}</span>
                      </div>
                      <div className="text-[10px] text-slate-500 dark:text-slate-400 truncate mt-0.5">
                        {p.connectionStatus === 'connected' ? 'Connected • Tap to chat' : 'Tap to send Spark message'}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Right Chat Area */}
            <div className="md:col-span-2 flex flex-col bg-white dark:bg-slate-900">
              
              {/* Chat Header */}
              <div className="p-4 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-900/80 backdrop-blur flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <img
                    src={activeChatPeer.avatar}
                    alt={activeChatPeer.name}
                    className="w-10 h-10 rounded-xl object-cover border border-indigo-500/40"
                  />
                  <div>
                    <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 flex items-center space-x-1.5">
                      <span>{activeChatPeer.name}</span>
                      <CollegeTag tag={activeChatPeer.universityShort} universityName={activeChatPeer.universityName} />
                      <ShieldCheck className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                    </h3>
                    <div className="text-[11px] text-slate-500 dark:text-slate-400">
                      {activeChatPeer.universityName} ({activeChatPeer.universityShort}) • {activeChatPeer.department}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <span className="bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 px-2.5 py-1 rounded-full text-[10px] font-bold">
                    {activeChatPeer.synergyScore}% Synergy
                  </span>
                </div>
              </div>

              {/* Chat Messages Feed */}
              <div className="flex-1 p-4 space-y-3 overflow-y-auto max-h-[420px] bg-slate-50/30 dark:bg-slate-950/40">
                {activeChatMessages.length === 0 ? (
                  <div className="text-center py-12 text-slate-400 text-xs">
                    No prior messages. Send a message to initiate collaboration with {activeChatPeer.name}!
                  </div>
                ) : (
                  activeChatMessages.map(msg => {
                    const isMe = msg.senderId === currentUser.id;
                    return (
                      <div
                        key={msg.id}
                        className={`flex items-start space-x-2 ${isMe ? 'flex-row-reverse space-x-reverse' : ''}`}
                      >
                        <img
                          src={msg.senderAvatar}
                          alt={msg.senderName}
                          className="w-7 h-7 rounded-lg object-cover shrink-0 mt-0.5"
                        />
                        <div className={`max-w-md p-3 rounded-2xl text-xs ${
                          isMe
                            ? 'bg-indigo-600 text-white rounded-tr-none'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-tl-none'
                        }`}>
                          <div className="text-[10px] opacity-75 font-semibold mb-1 flex items-center justify-between gap-2">
                            <span>{msg.senderName}</span>
                            <span className="font-mono">{msg.timestamp}</span>
                          </div>

                          <p className="leading-relaxed">{msg.text}</p>

                          {msg.meta && (
                            <div className="mt-2 pt-2 border-t border-white/20 text-[10px] font-mono flex items-center space-x-1.5 bg-black/10 dark:bg-black/20 p-1.5 rounded-lg">
                              <Zap className="w-3 h-3 text-amber-400" />
                              <span>{msg.meta}</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Quick Action Badges above input */}
              <div className="px-4 pt-2 flex items-center space-x-2 overflow-x-auto text-[11px] bg-white dark:bg-slate-900">
                <button
                  type="button"
                  onClick={() => handleSendMessage('project', 'Project Synergy Invite')}
                  className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-indigo-700 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-500/30 px-2.5 py-1 rounded-xl font-semibold shrink-0 cursor-pointer flex items-center space-x-1 transition"
                >
                  <Code className="w-3 h-3 text-indigo-500 dark:text-indigo-400" />
                  <span>Share Project Invite</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleSendMessage('resource', 'PYQ Notes Attachment')}
                  className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-500/30 px-2.5 py-1 rounded-xl font-semibold shrink-0 cursor-pointer flex items-center space-x-1 transition"
                >
                  <FileText className="w-3 h-3 text-emerald-600 dark:text-emerald-400" />
                  <span>Attach PYQ Solution</span>
                </button>
              </div>

              {/* Chat Input Bar */}
              <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
                <form
                  onSubmit={(e) => {
                    e.preventDefault();
                    handleSendMessage('text');
                  }}
                  className="flex items-center space-x-2"
                >
                  <input
                    type="text"
                    placeholder={`Message ${activeChatPeer.name}...`}
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    className="flex-1 bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl px-4 py-2.5 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
                  />
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-500 text-white p-2.5 rounded-xl transition cursor-pointer shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                  </button>
                </form>
              </div>

            </div>

          </div>
        )}

        {/* TAB 3: ORBIT PULSE BROADCAST FEED */}
        {activeOrbitTab === 'pulse' && (
          <div className="space-y-6 max-w-3xl mx-auto">
            
            {/* Broadcast Form */}
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 shadow-xs">
              <h3 className="font-extrabold text-sm text-slate-900 dark:text-slate-100 mb-3 flex items-center space-x-2">
                <Radio className="w-4 h-4 text-rose-500 animate-pulse" />
                <span>Broadcast an Orbit Pulse</span>
              </h3>
              
              <form onSubmit={handleCreatePulsePost} className="space-y-3">
                <textarea
                  rows={3}
                  required
                  placeholder="Broadcast a project callout, hackathon request, or PYQ note query to all connected peers..."
                  value={newPulseContent}
                  onChange={(e) => setNewPulseContent(e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-xs text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-500 focus:outline-none focus:border-indigo-500 transition"
                />

                <div className="flex items-center justify-between">
                  <span className="text-[10px] text-slate-400">
                    Visible to verified students across all campuses
                  </span>
                  <button
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-xl text-xs font-bold transition flex items-center space-x-1.5 cursor-pointer shadow-xs"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Transmit Pulse</span>
                  </button>
                </div>
              </form>
            </div>

            {/* Orbit Broadcast Posts */}
            <div className="space-y-4">
              {pulsePosts.map(post => (
                <div key={post.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-5 hover:border-slate-300 dark:hover:border-slate-700 transition shadow-xs">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <img
                        src={post.authorAvatar}
                        alt={post.authorName}
                        className="w-10 h-10 rounded-xl object-cover border border-indigo-500/40"
                      />
                      <div>
                        <div className="font-extrabold text-xs text-slate-900 dark:text-slate-100 flex items-center space-x-1.5">
                          <span>{post.authorName}</span>
                          <CollegeTag universityName={post.authorUniversity} />
                          <ShieldCheck className="w-3.5 h-3.5 text-indigo-500 dark:text-indigo-400" />
                        </div>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400">
                          {post.authorUniversity} • {post.authorBranch}
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] text-slate-400 font-mono">{post.timestamp}</span>
                  </div>

                  <p className="text-xs text-slate-700 dark:text-slate-200 leading-relaxed mb-4">
                    {post.content}
                  </p>

                  <div className="flex flex-wrap gap-1.5 mb-4">
                    {post.tags.map((t, idx) => (
                      <span key={idx} className="bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 text-[10px] font-semibold px-2 py-0.5 rounded-lg border border-indigo-200 dark:border-indigo-800">
                        #{t}
                      </span>
                    ))}
                  </div>

                  <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                    <button
                      onClick={() => handleTogglePostSpark(post.id)}
                      className={`flex items-center space-x-1.5 text-xs font-bold px-3 py-1.5 rounded-xl transition cursor-pointer ${
                        post.hasSparked
                          ? 'bg-amber-50 text-amber-700 border border-amber-300 dark:bg-amber-950 dark:text-amber-300 dark:border-amber-600/50'
                          : 'bg-slate-100 dark:bg-slate-950 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white border border-slate-200 dark:border-slate-800'
                      }`}
                    >
                      <Zap className={`w-3.5 h-3.5 ${post.hasSparked ? 'fill-amber-500 text-amber-500' : ''}`} />
                      <span>{post.sparksCount} Synergy Sparks</span>
                    </button>

                    <button
                      onClick={() => {
                        setActiveOrbitTab('chat');
                        const peer = peers.find(p => p.id === post.authorId);
                        if (peer) setActiveChatPeerId(peer.id);
                      }}
                      className="text-xs font-bold text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 flex items-center space-x-1 cursor-pointer"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                      <span>Direct Chat</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>

          </div>
        )}

      </div>

      {/* TRANSMIT SPARK MODAL */}
      {sparkModalPeer && (
        <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 text-slate-900 dark:text-slate-100 relative shadow-2xl transition-colors duration-200">
            <button
              onClick={() => setSparkModalPeer(null)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-1 rounded-lg transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 font-bold text-xs uppercase tracking-wider mb-2">
              <Zap className="w-4 h-4 text-amber-500 fill-amber-500" />
              <span>Synergy Spark Transmission</span>
            </div>

            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white mb-1">
              Connect with {sparkModalPeer.name}
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-4">
              {sparkModalPeer.universityName} • {sparkModalPeer.synergyScore}% Skill Synergy Match
            </p>

            <div className="space-y-3 text-xs mb-6">
              <label className="block text-slate-700 dark:text-slate-300 font-semibold">
                Personalized Synergy Message
              </label>
              <textarea
                rows={3}
                value={sparkNoteText}
                onChange={(e) => setSparkNoteText(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-xl p-3 text-slate-900 dark:text-slate-100 focus:outline-none focus:border-indigo-500 transition"
              />
            </div>

            <div className="flex items-center space-x-3">
              <button
                type="button"
                onClick={() => setSparkModalPeer(null)}
                className="flex-1 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 py-2.5 rounded-xl font-bold transition cursor-pointer border border-slate-200 dark:border-slate-700"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSparkTransmit}
                className="flex-1 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white py-2.5 rounded-xl font-extrabold transition shadow-xs flex items-center justify-center space-x-2 cursor-pointer"
              >
                <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
                <span>Transmit Spark</span>
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};
