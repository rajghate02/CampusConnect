import React, { useState } from 'react';
import {
  Play,
  CheckCircle2,
  ChevronRight,
  ChevronLeft,
  X,
  Sparkles,
  Award,
  BookOpen,
  Users,
  Code,
  Shield
} from 'lucide-react';

interface HackathonDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: string) => void;
}

export const HackathonDemoModal: React.FC<HackathonDemoModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab
}) => {
  const [currentStep, setCurrentStep] = useState(0);

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      title: "Step 1: Student Onboarding & University Email Verification",
      tab: "landing",
      description: "Aarav Sharma signs up using aarav.sharma@muj.manipal.edu. System validates university domain isolation for Manipal University Jaipur (MUJ).",
      actionLabel: "View Landing Page"
    },
    {
      step: 2,
      title: "Step 2: Department & Program Selection",
      tab: "profile",
      description: "Student specifies CSE (AI & ML), B.Tech Year 2, Semester 4 at MUJ Main Campus.",
      actionLabel: "Inspect Profile Metadata"
    },
    {
      step: 3,
      title: "Step 3: Rich Student Profile & Skills Setup",
      tab: "profile",
      description: "Profile auto-calculates 85% completion, displaying Python, React, PyTorch skills, badges, and reputation points.",
      actionLabel: "View Profile Stats"
    },
    {
      step: 4,
      title: "Step 4: Search Academic Resources ('Data Structures PYQ')",
      tab: "resources",
      description: "Student filters for CS2101 Data Structures 2025 Solved End-Sem Question Paper with faculty verification badge.",
      actionLabel: "Go to Resource Bank"
    },
    {
      step: 5,
      title: "Step 5: Preview & Download Solved PYQ Paper",
      tab: "resources",
      description: "Opens document reader modal, increments download counter, and triggers PYQ exam topic frequency analysis.",
      actionLabel: "Preview Document Reader"
    },
    {
      step: 6,
      title: "Step 6: Discover Student Project Showcase",
      tab: "projects",
      description: "Explores open-source projects including Quadcopter Drone and CampusConnect Academic Search Engine with GitHub & Live Demo links.",
      actionLabel: "View Projects"
    },
    {
      step: 7,
      title: "Step 7: Hackathon Team Finder",
      tab: "teams",
      description: "Browses active hackathon postings for the upcoming 24-Hour MUJ HackSummit 2026.",
      actionLabel: "View Team Finder"
    },
    {
      step: 8,
      title: "Step 8: Team Synergy & Skill Alignment Matching",
      tab: "teams",
      description: "Executes backend recommendation script calculating 92% skill synergy score between Aarav and the hackathon team.",
      actionLabel: "Test Skill Synergy"
    },
    {
      step: 9,
      title: "Step 9: Post Question & Discussion on Q&A Forum",
      tab: "discussion",
      description: "Student posts question on AVL tree rotations and earns reputation points upon verified answers.",
      actionLabel: "Go to Q&A Forum"
    },
    {
      step: 10,
      title: "Step 10: Explore University Clubs & Hackathons",
      tab: "clubs-events",
      description: "Discovers AICC Coding Club MUJ and registers for National Student Conclave 2026.",
      actionLabel: "View Clubs & Hackathons"
    },
    {
      step: 11,
      title: "Step 11: University Admin Moderation & Multi-Campus Analytics",
      tab: "admin",
      description: "University faculty approves new PYQs, reviews analytics, and maintains campus data isolation.",
      actionLabel: "Open Admin Console"
    }
  ];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      const nextIdx = currentStep + 1;
      setCurrentStep(nextIdx);
      onNavigateTab(steps[nextIdx].tab);
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) {
      const prevIdx = currentStep - 1;
      setCurrentStep(prevIdx);
      onNavigateTab(steps[prevIdx].tab);
    }
  };

  const activeStep = steps[currentStep];

  return (
    <div className="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-white dark:bg-slate-900 border-2 border-indigo-500/80 rounded-3xl max-w-2xl w-full p-6 sm:p-8 text-slate-900 dark:text-slate-100 relative shadow-2xl overflow-hidden transition-colors duration-200">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-slate-400 hover:text-slate-700 dark:hover:text-white p-2 rounded-xl bg-slate-100 dark:bg-slate-800 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center space-x-2 text-xs font-bold text-amber-600 dark:text-amber-400 mb-2">
          <Sparkles className="w-4 h-4 fill-amber-500 text-amber-500" />
          <span>Interactive 5-Minute Hackathon Demo Tour</span>
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mb-2">
          {activeStep.title}
        </h2>

        <p className="text-xs sm:text-sm text-slate-700 dark:text-slate-300 leading-relaxed mb-6 bg-slate-50 dark:bg-slate-950 p-4 rounded-xl border border-slate-200 dark:border-slate-800">
          {activeStep.description}
        </p>

        {/* Progress Bar */}
        <div className="mb-6">
          <div className="flex items-center justify-between text-xs font-bold text-slate-500 dark:text-slate-400 mb-1">
            <span>Progress: Step {currentStep + 1} of {steps.length}</span>
            <span className="text-indigo-600 dark:text-indigo-400">{Math.round(((currentStep + 1) / steps.length) * 100)}% Complete</span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 via-purple-500 to-amber-400 transition-all duration-300"
              style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Controls Footer */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-slate-800">
          <button
            onClick={handlePrev}
            disabled={currentStep === 0}
            className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 transition cursor-pointer ${
              currentStep === 0 ? 'opacity-30 cursor-not-allowed text-slate-400 dark:text-slate-500' : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous Step</span>
          </button>

          <button
            onClick={() => onNavigateTab(activeStep.tab)}
            className="bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800 hover:bg-indigo-100 dark:hover:bg-indigo-900 font-bold px-4 py-2 rounded-xl text-xs transition cursor-pointer"
          >
            Jump to Section
          </button>

          <button
            onClick={handleNext}
            disabled={currentStep === steps.length - 1}
            className={`px-5 py-2 rounded-xl text-xs font-bold flex items-center space-x-1 shadow-xs transition cursor-pointer ${
              currentStep === steps.length - 1
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-amber-400 hover:bg-amber-300 text-slate-950'
            }`}
          >
            <span>{currentStep === steps.length - 1 ? "Tour Completed!" : "Next Step"}</span>
            {currentStep < steps.length - 1 && <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

      </div>
    </div>
  );
};
