import React from 'react';
import {
  Award,
  Star,
  Clock,
  CheckCircle2,
  Calendar,
  MessageCircle
} from 'lucide-react';
import { MentorProfile, StudentProfile, University } from '../types';
import { CollegeTag } from './CollegeTag';

interface MentorConnectProps {
  mentors: MentorProfile[];
  student: StudentProfile;
  selectedUniversity: University;
}

export const MentorConnect: React.FC<MentorConnectProps> = ({
  mentors,
  student,
  selectedUniversity
}) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-slate-900 dark:text-slate-100 transition-colors duration-200">
      
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center space-x-2">
            <span className="bg-amber-50 text-amber-800 border border-amber-200 dark:bg-amber-900 dark:text-amber-300 dark:border-transparent font-bold px-2.5 py-0.5 rounded text-xs">
              Senior Peer Mentorship
            </span>
            <span className="text-xs text-slate-500 dark:text-slate-400">1-on-1 Exam & Hackathon Guidance</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white mt-1 tracking-tight">
            Senior Mentor Connect
          </h1>
          <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-0.5">
            Book guidance sessions with 3rd & 4th year toppers at {selectedUniversity.shortCode} for exam strategy and hackathon preparation.
          </p>
        </div>
      </div>

      {/* Mentors Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mentors.map(m => (
          <div key={m.id} className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs hover:shadow-md transition flex flex-col justify-between">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img src={m.avatar} alt={m.name} className="w-12 h-12 rounded-full object-cover border border-amber-500/50 shadow-xs" />
                <div>
                  <h3 className="font-bold text-slate-900 dark:text-white text-base flex items-center space-x-1.5">
                    <span>{m.name}</span>
                    <CollegeTag universityName={selectedUniversity.name} />
                  </h3>
                  <div className="text-xs text-slate-500 dark:text-slate-400">{m.department} • Year {m.year}</div>
                  <div className="text-amber-600 dark:text-amber-400 text-xs font-bold mt-0.5">★ {m.rating} ({m.sessionsCompleted} Sessions)</div>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mb-4">{m.bio}</p>

              {/* Mentorship Topics */}
              <div className="mb-4">
                <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 uppercase tracking-wider block mb-1">Topics Guidance:</span>
                <div className="space-y-1 text-xs text-slate-700 dark:text-slate-200">
                  {m.topics.map((top, idx) => (
                    <div key={idx} className="flex items-center space-x-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 shrink-0" />
                      <span>{top}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800/80 p-2.5 rounded-xl text-[11px] text-slate-600 dark:text-slate-400 mb-4">
                <Calendar className="w-3.5 h-3.5 text-amber-500 dark:text-amber-400 inline mr-1" />
                Slots: {m.availableDays.join(' • ')}
              </div>
            </div>

            <button
              onClick={() => alert(`Mentorship request sent to ${m.name}! You will receive a calendar invite on your university email.`)}
              className="w-full bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold py-2.5 rounded-xl text-xs transition shadow-xs hover:shadow cursor-pointer"
            >
              Request 1-on-1 Mentorship Session
            </button>
          </div>
        ))}
      </div>

    </div>
  );
};
