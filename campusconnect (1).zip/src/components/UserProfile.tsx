import React, { useState } from 'react';
import {
  User as UserIcon,
  GraduationCap,
  Briefcase,
  Award,
  CheckCircle2,
  Github,
  Linkedin,
  Globe,
  BookOpen,
  Code,
  Users,
  FileText,
  X,
  Lock
} from 'lucide-react';
import { CollegeTag } from './CollegeTag';
import { StudentProfile, University } from '../types';

interface UserProfileProps {
  student: StudentProfile;
  selectedUniversity: University;
  onOpenAIResumeGrader: () => void;
}

export const UserProfileView: React.FC<UserProfileProps> = ({
  student,
  selectedUniversity,
  onOpenAIResumeGrader
}) => {
  const [showPortfolioToast, setShowPortfolioToast] = useState(false);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 text-slate-900 dark:text-slate-100 space-y-8 transition-colors duration-200">
      
      {showPortfolioToast && (
        <div className="bg-white dark:bg-slate-900 border border-emerald-500/50 p-4 rounded-2xl flex items-center justify-between text-xs text-slate-800 dark:text-slate-200 shadow-xl">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <div>
              <span className="font-bold text-slate-900 dark:text-white">Academic Portfolio Exported!</span>
              <span className="ml-2 text-slate-600 dark:text-slate-300">Downloaded PDF summary for {student.name}.</span>
            </div>
          </div>
          <button
            onClick={() => setShowPortfolioToast(false)}
            className="bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 px-3 py-1.5 rounded-xl font-bold transition flex items-center space-x-1 cursor-pointer border border-slate-200 dark:border-slate-700"
          >
            <X className="w-3.5 h-3.5" />
            <span>Dismiss & Explore</span>
          </button>
        </div>
      )}

      {/* PROFILE HEADER CARD */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xs relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/5 dark:bg-indigo-600/10 blur-3xl rounded-full pointer-events-none" />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6 relative z-10">
          
          <div className="flex items-center space-x-4">
            <img
              src={student.avatar}
              alt={student.name}
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-indigo-500 shadow-md"
            />
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-2xl font-black text-slate-900 dark:text-white">{student.name}</h1>
                <CollegeTag tag={student.universityShort || 'MUJ'} universityName={student.universityName} className="text-xs px-2 py-0.5" />
                <span className="text-[10px] bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800 px-2.5 py-0.5 rounded-full font-bold">
                  Verified Student
                </span>
              </div>
              <div className="text-xs text-slate-600 dark:text-slate-300 font-medium mt-0.5">
                {student.degree} {student.branch} • Year {student.year} (Semester {student.semester})
              </div>
              <div className="text-xs text-indigo-600 dark:text-indigo-400 mt-1 flex items-center space-x-1.5">
                <GraduationCap className="w-4 h-4 text-indigo-500 dark:text-indigo-300" />
                <span className="font-semibold">{student.universityName}</span>
                <span className="inline-flex items-center space-x-1 bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-[10px] text-slate-600 dark:text-slate-400 px-2 py-0.5 rounded-full font-mono">
                  <Lock className="w-3 h-3 text-emerald-500 dark:text-emerald-400" />
                  <span>Enrolled (Locked)</span>
                </span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenAIResumeGrader}
              className="bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold px-4 py-2.5 rounded-xl text-xs flex items-center space-x-2 transition shadow-xs hover:shadow cursor-pointer"
            >
              <Briefcase className="w-4 h-4 text-emerald-100" />
              <span>ATS Resume Grader</span>
            </button>

            <button
              onClick={() => setShowPortfolioToast(true)}
              className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs transition cursor-pointer shadow-xs"
            >
              Export Academic Portfolio
            </button>
          </div>

        </div>

        {/* Profile Completion Bar */}
        <div className="mt-6 pt-6 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center justify-between text-xs mb-1.5">
            <span className="font-semibold text-slate-600 dark:text-slate-300">Profile Completion</span>
            <span className="font-bold text-indigo-600 dark:text-indigo-400">{student.profileCompletionPercentage}%</span>
          </div>
          <div className="w-full h-2 bg-slate-100 dark:bg-slate-950 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-emerald-400 rounded-full transition-all duration-500"
              style={{ width: `${student.profileCompletionPercentage}%` }}
            />
          </div>
        </div>

      </div>

      {/* METRICS ROW */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Reputation Points</div>
          <div className="text-2xl font-black text-indigo-600 dark:text-indigo-400 mt-1">{student.reputationPoints} pts</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Projects Built</div>
          <div className="text-2xl font-black text-emerald-600 dark:text-emerald-400 mt-1">{student.projectsCount}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">PYQs Uploaded</div>
          <div className="text-2xl font-black text-purple-600 dark:text-purple-400 mt-1">{student.resourcesUploadedCount}</div>
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-4 rounded-2xl shadow-xs">
          <div className="text-xs text-slate-500 dark:text-slate-400 font-medium">Connections</div>
          <div className="text-2xl font-black text-amber-600 dark:text-amber-400 mt-1">{student.connectionsCount}</div>
        </div>
      </div>

      {/* SKILLS & BADGES */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-3">Technical Skills & Languages</h2>
          <div className="flex flex-wrap gap-2 mb-4">
            {student.skills.map((s, i) => (
              <span key={i} className="bg-indigo-50 text-indigo-700 border border-indigo-200 dark:bg-indigo-950 dark:text-indigo-300 dark:border-indigo-800 text-xs font-semibold px-3 py-1 rounded-lg">
                {s}
              </span>
            ))}
          </div>

          <div className="text-xs text-slate-500 dark:text-slate-400 font-semibold mb-1">Languages:</div>
          <div className="flex flex-wrap gap-1.5">
            {student.programmingLanguages.map((l, i) => (
              <span key={i} className="bg-slate-100 dark:bg-slate-950 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-800 text-xs px-2.5 py-1 rounded">
                {l}
              </span>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 shadow-xs">
          <h2 className="text-base font-bold text-slate-900 dark:text-white mb-3">Badges & Contributions</h2>
          <div className="space-y-2">
            {student.badges.map((b, i) => (
              <div key={i} className="flex items-center space-x-2 bg-slate-50 dark:bg-slate-950 p-2.5 rounded-xl text-xs text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-800">
                <Award className="w-4 h-4 text-amber-500 dark:text-amber-400 shrink-0" />
                <span className="font-semibold">{b}</span>
              </div>
            ))}
          </div>
        </div>

      </div>

    </div>
  );
};
