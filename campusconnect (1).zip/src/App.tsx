/**
 * CampusConnect - Student-Only Academic & Professional Network
 * Global Cross-University Network
 */

import React, { useState } from 'react';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { ResourceLibrary } from './components/ResourceLibrary';
import { ProjectShowcaseView } from './components/ProjectShowcase';
import { TeamFinder } from './components/TeamFinder';
import { FeedView } from './components/Feed';
import { DiscussionForum } from './components/DiscussionForum';
import { ClubsAndEvents } from './components/ClubsAndEvents';
import { MentorConnect } from './components/MentorConnect';
import { UserProfileView } from './components/UserProfile';
import { AdminDashboard } from './components/AdminDashboard';
import { HackathonDemoModal } from './components/HackathonDemoModal';
import { AIResourceAssistantModal } from './components/AIResourceAssistantModal';
import { AIResumeAssistantModal } from './components/AIResumeAssistantModal';
import { AuthModal } from './components/AuthModal';
import { SynergyOrbit } from './components/SynergyOrbit';
import { UniversityHubView } from './components/UniversityHubView';

import {
  INITIAL_UNIVERSITIES,
  CURRENT_STUDENT,
  INITIAL_RESOURCES,
  INITIAL_PROJECTS,
  INITIAL_TEAM_POSTS,
  INITIAL_POSTS,
  INITIAL_CLUBS,
  INITIAL_EVENTS,
  INITIAL_FORUM,
  INITIAL_MENTORS,
  INITIAL_NOTIFICATIONS
} from './data/seedData';

import {
  University,
  StudentProfile,
  AcademicResource,
  ProjectShowcase,
  TeamFinderPost,
  PostFeedItem,
  ForumQuestion,
  NotificationItem
} from './types';

export default function App() {
  // Navigation & Active State
  const [currentTab, setCurrentTab] = useState<string>('landing');
  const [universities, setUniversities] = useState<University[]>(INITIAL_UNIVERSITIES);
  const [selectedUniversity, setSelectedUniversity] = useState<University>(INITIAL_UNIVERSITIES[0]); // Default: MUJ
  const [student, setStudent] = useState<StudentProfile>(CURRENT_STUDENT);
  const [searchQuery, setSearchQuery] = useState<string>('');

  // Collections State
  const [resources, setResources] = useState<AcademicResource[]>(INITIAL_RESOURCES);
  const [projects, setProjects] = useState<ProjectShowcase[]>(INITIAL_PROJECTS);
  const [teams, setTeams] = useState<TeamFinderPost[]>(INITIAL_TEAM_POSTS);
  const [feedPosts, setFeedPosts] = useState<PostFeedItem[]>(INITIAL_POSTS);
  const [forumQuestions, setForumQuestions] = useState<ForumQuestion[]>(INITIAL_FORUM);
  const [notifications, setNotifications] = useState<NotificationItem[]>(INITIAL_NOTIFICATIONS);

  // Modals State
  const [isDemoModalOpen, setIsDemoModalOpen] = useState(false);
  const [isAIResourceAssistantOpen, setIsAIResourceAssistantOpen] = useState(false);
  const [aiResourceSubject, setAiResourceSubject] = useState('Data Structures');
  const [isAIResumeGraderOpen, setIsAIResumeGraderOpen] = useState(false);

  // Auth & Account Management State
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(true);
  const [registeredUsers, setRegisteredUsers] = useState<StudentProfile[]>(() => {
    try {
      const saved = localStorage.getItem('campusconnect_registered_users');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('Failed to load registered users', e);
    }
    return [CURRENT_STUDENT];
  });

  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);
  const [authModalMode, setAuthModalMode] = useState<'signin' | 'signup'>('signin');

  const handleOpenAuthModal = (mode: 'signin' | 'signup') => {
    setAuthModalMode(mode);
    setIsAuthModalOpen(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  const handleSuccessLogin = (user: StudentProfile) => {
    setStudent(user);
    setIsLoggedIn(true);
    const matchUni = universities.find(u => u.id === user.universityId);
    if (matchUni) {
      setSelectedUniversity(matchUni);
    }
  };

  // Handlers for adding items
  const handleUploadResource = (newRes: AcademicResource) => {
    setResources([newRes, ...resources]);
    setStudent(prev => ({
      ...prev,
      resourcesUploadedCount: prev.resourcesUploadedCount + 1,
      reputationPoints: prev.reputationPoints + 50
    }));
  };

  const handleCreateProject = (newProj: ProjectShowcase) => {
    setProjects([newProj, ...projects]);
    setStudent(prev => ({
      ...prev,
      projectsCount: prev.projectsCount + 1,
      reputationPoints: prev.reputationPoints + 75
    }));
  };

  const handleCreateTeamPost = (newPost: TeamFinderPost) => {
    setTeams([newPost, ...teams]);
  };

  const handleApplyToTeam = (postId: string) => {
    setTeams(prevTeams =>
      prevTeams.map(t => {
        if (t.id === postId) {
          const applied = t.appliedUserIds || [];
          if (!applied.includes(student.id)) {
            return {
              ...t,
              appliedUserIds: [...applied, student.id],
              applicantsCount: t.applicantsCount + 1
            };
          }
        }
        return t;
      })
    );

    const targetTeam = teams.find(t => t.id === postId);
    const newNotif: NotificationItem = {
      id: `notif_apply_${Date.now()}`,
      title: 'Hackathon Application Status: Pending',
      message: `Your application to "${targetTeam?.title || 'Hackathon Team'}" was submitted to ${targetTeam?.authorName || 'Team Lead'}. Status is currently Pending.`,
      createdAt: 'Just now',
      read: false,
      type: 'team_application'
    };
    setNotifications(prev => [newNotif, ...prev]);
  };

  const handleCreateFeedPost = (newFeedItem: PostFeedItem) => {
    setFeedPosts([newFeedItem, ...feedPosts]);
  };

  const handleCreateForumQuestion = (newQuestion: ForumQuestion) => {
    setForumQuestions([newQuestion, ...forumQuestions]);
    setStudent(prev => ({
      ...prev,
      reputationPoints: prev.reputationPoints + 10
    }));
  };

  const handleVerifyResource = (resId: string) => {
    setResources(prev => prev.map(r => r.id === resId ? { ...r, verifiedByFaculty: true } : r));
  };

  const handleOpenAIResourceAssistant = (subject?: string) => {
    if (subject) setAiResourceSubject(subject);
    setIsAIResourceAssistantOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-indigo-500 selection:text-white transition-colors duration-200">
      
      {/* Top Header & Navigation */}
      <Navbar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        selectedUniversity={selectedUniversity}
        setSelectedUniversity={setSelectedUniversity}
        universities={universities}
        student={student}
        notifications={notifications}
        onOpenDemoModal={() => setIsDemoModalOpen(true)}
        onOpenAIResourceAssistant={() => handleOpenAIResourceAssistant()}
        onOpenAIResumeGrader={() => setIsAIResumeGraderOpen(true)}
        onOpenUploadResource={() => setCurrentTab('resources')}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        isLoggedIn={isLoggedIn}
        onOpenAuthModal={handleOpenAuthModal}
        onLogout={handleLogout}
        projects={projects}
        resources={resources}
        forumQuestions={forumQuestions}
        teams={teams}
      />

      {/* Main View Router */}
      <main className="flex-1">
        {currentTab === 'landing' && (
          <LandingPage
            universities={universities}
            onStartExploring={(tab) => setCurrentTab(tab)}
            onOpenDemoTour={() => setIsDemoModalOpen(true)}
          />
        )}

        {currentTab === 'university' && (
          <UniversityHubView
            universities={universities}
            selectedUniversity={selectedUniversity}
            onSelectUniversity={setSelectedUniversity}
            currentUser={student}
            resources={resources}
            projects={projects}
            onOpenChatWithPeer={() => setCurrentTab('orbit')}
          />
        )}

        {currentTab === 'orbit' && (
          <SynergyOrbit
            currentUser={student}
            universities={universities}
            onOpenProfile={() => setCurrentTab('profile')}
          />
        )}

        {currentTab === 'feed' && (
          <FeedView
            posts={feedPosts}
            student={student}
            selectedUniversity={selectedUniversity}
            onCreatePost={handleCreateFeedPost}
          />
        )}

        {currentTab === 'resources' && (
          <ResourceLibrary
            resources={resources}
            selectedUniversity={selectedUniversity}
            universities={universities}
            onSelectUniversity={setSelectedUniversity}
            onUploadResource={handleUploadResource}
            onOpenAIResourceAssistant={(subj) => handleOpenAIResourceAssistant(subj)}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {currentTab === 'projects' && (
          <ProjectShowcaseView
            projects={projects}
            student={student}
            selectedUniversity={selectedUniversity}
            onCreateProject={handleCreateProject}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {currentTab === 'teams' && (
          <TeamFinder
            teams={teams}
            student={student}
            selectedUniversity={selectedUniversity}
            onCreateTeamPost={handleCreateTeamPost}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onApplyToTeam={handleApplyToTeam}
          />
        )}

        {currentTab === 'discussion' && (
          <DiscussionForum
            questions={forumQuestions}
            student={student}
            selectedUniversity={selectedUniversity}
            onCreateQuestion={handleCreateForumQuestion}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}

        {currentTab === 'clubs-events' && (
          <ClubsAndEvents
            clubs={INITIAL_CLUBS}
            events={INITIAL_EVENTS}
            selectedUniversity={selectedUniversity}
          />
        )}

        {currentTab === 'mentors' && (
          <MentorConnect
            mentors={INITIAL_MENTORS}
            student={student}
            selectedUniversity={selectedUniversity}
          />
        )}

        {currentTab === 'profile' && (
          <UserProfileView
            student={student}
            selectedUniversity={selectedUniversity}
            onOpenAIResumeGrader={() => setIsAIResumeGraderOpen(true)}
          />
        )}

        {currentTab === 'admin' && (
          <AdminDashboard
            universities={universities}
            resources={resources}
            onVerifyResource={handleVerifyResource}
          />
        )}
      </main>

      {/* MODALS */}
      <HackathonDemoModal
        isOpen={isDemoModalOpen}
        onClose={() => setIsDemoModalOpen(false)}
        onNavigateTab={(tab) => setCurrentTab(tab)}
      />

      <AIResourceAssistantModal
        isOpen={isAIResourceAssistantOpen}
        onClose={() => setIsAIResourceAssistantOpen(false)}
        selectedUniversity={selectedUniversity}
        initialSubject={aiResourceSubject}
      />

      <AIResumeAssistantModal
        isOpen={isAIResumeGraderOpen}
        onClose={() => setIsAIResumeGraderOpen(false)}
        student={student}
      />

      <AuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
        initialMode={authModalMode}
        onSuccessLogin={handleSuccessLogin}
        universities={universities}
        registeredUsers={registeredUsers}
        setRegisteredUsers={setRegisteredUsers}
      />

    </div>
  );
}
