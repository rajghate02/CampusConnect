#!/usr/bin/env python3
"""
CampusConnect - AI Team Matching & Recommendation Engine in Python
Calculates skill match scores, university alignment, experience weighting, and role suitability.
"""
import sys
import json

def calculate_match_score(applicant_skills, required_skills, applicant_uni, target_uni, applicant_exp):
    score = 0.0
    matched_skills = []
    missing_skills = []

    req_set = set(s.lower() for s in required_skills)
    app_set = set(s.lower() for s in applicant_skills)

    for skill in required_skills:
        s_lower = skill.lower()
        if s_lower in app_set:
            matched_skills.append(skill)
        else:
            # Check partial match (e.g. react in reactjs)
            found = False
            for app_s in app_set:
                if s_lower in app_s or app_s in s_lower:
                    matched_skills.append(f"{skill} (related: {app_s})")
                    found = True
                    break
            if not found:
                missing_skills.append(skill)

    if req_set:
        skill_coverage = len(matched_skills) / len(req_set)
        score += skill_coverage * 60.0 # 60% weight on skill match
    else:
        score += 50.0

    # University bonus
    if applicant_uni.lower() == target_uni.lower():
        score += 20.0 # 20% weight on same campus/university synergy
    else:
        score += 10.0 # Cross-university collaboration value

    # Experience bonus (projects count)
    score += min(applicant_exp * 4.0, 20.0) # up to 20% weight on project count

    match_percentage = min(int(round(score)), 99)

    return {
        "match_percentage": match_percentage,
        "matched_skills": matched_skills,
        "missing_skills": missing_skills,
        "recommendation": "High Synergy Match" if match_percentage >= 80 else ("Good Fit" if match_percentage >= 60 else "Potential Candidate")
    }

def main():
    try:
        if len(sys.argv) > 1:
            input_data = json.loads(sys.argv[1])
        else:
            input_data = json.load(sys.stdin)

        applicant_skills = input_data.get("applicant_skills", [])
        required_skills = input_data.get("required_skills", [])
        applicant_uni = input_data.get("applicant_uni", "MUJ")
        target_uni = input_data.get("target_uni", "MUJ")
        applicant_exp = input_data.get("applicant_exp", 2)

        result = calculate_match_score(applicant_skills, required_skills, applicant_uni, target_uni, applicant_exp)
        print(json.dumps({"status": "success", "data": result}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))

if __name__ == "__main__":
    main()
