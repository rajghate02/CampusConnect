#!/usr/bin/env python3
"""
CampusConnect - Student Resume ATS & Portfolio Grader in Python
Analyzes student profiles, project descriptions, skills, and formats into ATS recommendation metrics.
"""
import sys
import json

def grade_resume(profile_data):
    skills = profile_data.get("skills", [])
    projects = profile_data.get("projects", [])
    bio = profile_data.get("bio", "")
    hackathons = profile_data.get("hackathons", [])
    github = profile_data.get("github", "")

    score = 40 # Base score

    feedback = []

    if len(skills) >= 5:
        score += 15
        feedback.append("Good skill density (5+ technical skills tagged).")
    else:
        feedback.append("Add at least 5 key technical skills to increase search visibility.")

    if len(projects) >= 2:
        score += 20
        feedback.append("Strong project showcase (2+ full projects linked).")
    elif len(projects) == 1:
        score += 10
        feedback.append("Add 1 more project or research paper to boost your portfolio impact.")
    else:
        feedback.append("No projects found! Add at least 1 project with GitHub & live demo link.")

    if hackathons and len(hackathons) > 0:
        score += 15
        feedback.append("Hackathon participation demonstrates initiative and team collaboration.")

    if github and "github.com" in github:
        score += 10
        feedback.append("GitHub profile linked.")

    total_score = min(score, 98)

    bullet_improvements = [
        "Quantify project achievements: e.g., 'Built a Python resource search engine that reduced retrieval time by 40%'.",
        "Highlight tech stack upfront in project titles for recruiter readability.",
        "Add university leadership or club coordinator roles to demonstrate soft skills."
    ]

    return {
        "ats_score": total_score,
        "rating": "Strong Portfolio" if total_score >= 80 else ("Moderate" if total_score >= 60 else "Needs Improvement"),
        "feedback": feedback,
        "suggested_bullet_improvements": bullet_improvements
    }

def main():
    try:
        if len(sys.argv) > 1:
            input_data = json.loads(sys.argv[1])
        else:
            input_data = json.load(sys.stdin)

        result = grade_resume(input_data)
        print(json.dumps({"status": "success", "data": result}))
    except Exception as e:
        print(json.dumps({"status": "error", "message": str(e)}))

if __name__ == "__main__":
    main()
